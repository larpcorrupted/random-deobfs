#!/usr/bin/env python3
"""Luaq v2.x deobfuscator.

    python tool/deobf.py in.lua -o out.lua [--workdir DIR] [--reuse-session] [--max-runs N]

The protected script is executed inside real Luau against a Roblox-style mock
(the loader's anti-tamper therefore sees a faithful environment; its remote
session handshake is relayed to the endpoint the loader itself names).  The
VM's instruction stream of the user program is traced, every executed
fused instruction is interpreted symbolically from the VM's *own* handler code
(so nothing about opcodes is hard-coded), branches not taken are explored by
offline replays, and the resulting control-flow graph is structured back into
Lua source.

Exit status: 0 on success, 2 when the sample is not a recognised Luaq layout,
3 when the user program could not be recovered.
"""
import argparse
import io
import json
import os
import sys
import tempfile
import time

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)

from luaq import prepare, capture, trace, lift, explore, decompile, gen, sweep  # noqa: E402


class Result:
    def __init__(self):
        self.ok = False
        self.status = 'failed'
        self.source = None
        self.reason = ''
        self.notes = []
        self.stats = {}


def _assemble(parts):
    if len(parts) > 1:
        wrapped = []
        for i, p_ in enumerate(parts):
            body = '\n'.join(('  ' + l) if l else l for l in p_.rstrip('\n').split('\n'))
            wrapped.append('-- chunk %d\ndo\n%s\nend\n' % (i + 1, body))
        parts = wrapped
    return '\n'.join(parts)


def _forced_differentials(model, workdir, log):
    """Replay-with-flips differential: for every exploration run that reached new code, run the
    test variant of the deobfuscated source (branch conditions routed through ``__BRF``) with the
    same decisions inverted and compare the event logs.  Returns (verified instruction set, results)."""
    from luaq import validate
    nat = getattr(model, 'natural', set())
    runs = [r for r in getattr(model, 'flip_runs', []) if (r.get('exec') or r['new']) - nat]
    if not runs:
        return set(), []
    gen.TEST_HOOKS = True
    try:
        parts = []
        for root in model.roots:
            text = decompile.decompile_root(model, root, [])
            if text:
                parts.append(text)
    finally:
        gen.TEST_HOOKS = False
    if not parts:
        return set(), []
    hooked = _assemble(parts)
    verified, results = set(), []
    t_start = time.time()
    for r in runs[:16]:
        if time.time() - t_start > 150:
            log('  forced differentials: time budget exhausted')
            break
        path = os.path.join(workdir, r['name'] + '.txt')
        try:
            d = validate.differential_forced(hooked, path, model.keep, workdir, r['flips'], 'plainf',
                                             orig_cut=r.get('cut', False))
        except Exception as e:
            results.append({'run': r['name'], 'error': repr(e)})
            continue
        ok = d['identical'] or d['prefix_equal']
        results.append({'run': r['name'], 'identical': bool(ok), 'orig_events': d['orig_events'],
                        'new_events': d['new_events'], 'first_diff': d['first_diff'],
                        'detail': [[x[:140] for x in part] for part in (d['detail'] or [])]})
        log('  forced differential %s: %s (%d/%d events)' % (r['name'], 'identical' if ok else 'DIFFERENT',
                                                            d['orig_events'], d['new_events']))
        if ok:
            verified |= r.get('exec', r['new'])
    return verified, results


def deobfuscate(src, workdir, reuse_session=False, max_runs=40, log=lambda s: None):
    res = Result()
    t0 = time.time()
    try:
        det = prepare.detect(src)
    except prepare.Unsupported as e:
        res.reason = 'unsupported: %s' % e
        return res
    res.stats['variant'] = det['variant']
    if det['variant'] != 'A':
        res.reason = ('variant %s (%s) is not supported by this version (no recovered VM model)'
                      % (det['variant'], det['reason']))
        return res
    try:
        inst, info, vm, roles = prepare.instrument(src)
    except Exception as e:  # structure unknown
        res.reason = 'VM structure not recognised: %r' % (e,)
        return res
    res.stats['vm'] = info
    os.makedirs(workdir, exist_ok=True)
    sess = os.path.join(workdir, 'session.json')
    try:
        if reuse_session and os.path.exists(sess):
            out, rc, killed, dt = capture.replay(inst, workdir, 'base', prelude=info.get('prelude', ''))
            orig_killed = killed
            log('replayed stored session (%.1fs)' % dt)
        else:
            cap = capture.capture(inst, workdir, prelude=info.get('prelude', ''))
            out = cap['out']
            orig_killed = (cap.get('run2') or {}).get('killed')
            res.stats['capture'] = {k: cap[k] for k in ('drm', 'run2') if k in cap}
            log('captured: %s' % cap.get('run2'))
    except capture.DrmError as e:
        res.reason = 'DRM handshake failed: %s' % e
        return res
    run = trace.parse_run(out)
    if not orig_killed and any('OPCAP reached' in l for l in run.stdout):
        orig_killed = 'op-cap'          # the harness aborted the (non-terminating) program
    res.stats['orig_killed'] = orig_killed
    if not run.done:
        res.notes.append('the instrumented program did not run to completion')
    model = lift.Model(vm, roles)
    model.add_run(run)
    res.stats['roots'] = list(model.roots)
    if not model.roots:
        res.reason = 'no user program found in the VM trace'
        return res
    model.natural = {(pid, y) for pid, pm in model.protos.items() for y in pm.instrs}
    # static sweep: decode every instruction reachable from the entry of every user proto with the VM's
    # own decoder (nothing of the program runs); it only ever adds instructions to the model
    try:
        sw_src, _swinfo, _v, _r = prepare.instrument(src, sweep=True)
        its, added = sweep.sweep(sw_src, workdir, model, base_prelude=info.get('prelude', ''), log=log)
        model.swept = {(pid, y) for pid, pm in model.protos.items() for y in pm.instrs} - model.natural
        res.stats['sweep'] = {'iterations': its, 'decoded': len(model.swept)}
    except Exception as e:      # the sweep must never cost the dynamic result
        log('  sweep failed: %r' % (e,))
        res.stats['sweep'] = {'error': repr(e)}
        model.swept = set()
    n = explore.explore(inst, workdir, model, log=log, max_runs=max_runs, base_prelude=info.get('prelude', ''))
    res.stats['explore_runs'] = n
    if info.get('closure_hook'):
        explore.exercise_closures(inst, workdir, model, log=log, base_prelude=info.get('prelude', ''))
    # the forced runs reach code the first sweep never saw: its own undecoded successors are swept too
    sw_src = locals().get('sw_src')
    if sw_src is not None and 'error' not in res.stats.get('sweep', {}):
        try:
            have = {(pid, y) for pid, pm in model.protos.items() for y in pm.instrs}
            its2, added2 = sweep.sweep(sw_src, workdir, model, base_prelude=info.get('prelude', ''), log=log,
                                       budget=300)
            new = {(pid, y) for pid, pm in model.protos.items() for y in pm.instrs} - have
            model.swept = set(getattr(model, 'swept', set())) | new
            res.stats['sweep']['second'] = {'iterations': its2, 'decoded': len(new)}
        except Exception as e:      # never costs the result
            log('  second sweep failed: %r' % (e,))
    explore.force_consts(inst, workdir, model, log=log, base_prelude=info.get('prelude', ''))
    res.stats['interp_failures'] = dict(model.stats)
    notes = []
    parts = []
    for root in model.roots:
        text = decompile.decompile_root(model, root, notes)
        if text:
            parts.append(text)
    if not parts:
        res.reason = 'user chunk could not be lifted'
        return res
    res.source = _assemble(parts)
    res.notes += sorted(set(notes))
    res.ok = True
    # ---- validation: syntax, residue, differential execution in the same mock
    from luaq import validate
    ok_c, msg = validate.compile_ok(res.source, workdir)
    res.stats['compile'] = ok_c
    if not ok_c:
        res.stats['compile_msg'] = msg
    res.stats['residue'] = validate.residue(res.source)
    try:
        d = validate.differential(res.source, out, model.keep, workdir, orig_cut=bool(orig_killed))
        res.stats['differential'] = {k: d[k] for k in ('identical', 'orig_events', 'new_events',
                                                       'first_diff', 'rc', 'killed', 'prefix_equal')}
        if d['prefix_equal']:
            res.notes.append('the program does not terminate in the mock (original run cut: %s; deobfuscated run: %s): '
                             'the event logs are identical up to event %s (original %d events, deobfuscated %d)' % (
                                 orig_killed, d['killed'] or 'completed', d['first_diff'], d['orig_events'],
                                 d['new_events']))
        if d['orig_events'] == 0 and d['new_events'] == 0:
            res.notes.append('the program produces no observable event in the mock: the differential is vacuous '
                             '(syntax/residue checks and the lifted structure are the only evidence)')
        if d['detail']:
            res.stats['diff_detail'] = [[x[:160] for x in part] for part in d['detail']]
    except Exception as e:  # validation must never crash the tool
        res.stats['differential'] = {'identical': False, 'error': repr(e)}
    for marker, what in (('unresolved', 'unresolved values'), ('never executed', 'code never executed in the mock'),
                         ('uninterpreted', 'uninterpreted VM instructions')):
        cnt = res.source.count(marker)
        if cnt:
            res.notes.append('%d occurrence(s) of %s in the output' % (cnt, what))
    natural = getattr(model, 'natural', set())
    exercised = {k for k, v in getattr(model, 'origin', {}).items() if v == 'exercise'}
    allkeys = {(pid, y) for pid in model.keep if pid in model.protos for y in model.protos[pid].instrs}
    beyond = allkeys - natural - exercised          # decoded, but not executed by the natural run
    fi = len(beyond)
    res.stats['forced_instrs'] = fi
    if fi:
        try:
            verified, fres = _forced_differentials(model, workdir, log)
        except Exception as e:      # validation must never crash the tool
            verified, fres = set(), [{'error': repr(e)}]
        res.stats['forced_differential'] = fres
        ok_ = beyond & verified
        left = beyond - verified
        static_only = left & getattr(model, 'swept', set())
        res.stats['forced_unverified'] = len(left)
        res.stats['static_only'] = len(static_only)
        if ok_:
            res.notes.append('%d of %d instruction(s) beyond the natural run were checked by forced-branch '
                             'differential runs (identical event logs)' % (len(ok_), fi))
        if left:
            res.notes.append('%d instruction(s) beyond the natural run are not covered by the differential '
                             'execution (%d of them decoded statically only: no replay ever executed them)' % (
                                 len(left), len(static_only)))
    ei = getattr(model, 'exercised_instrs', 0)
    res.stats['exercised_instrs'] = ei
    if ei:
        res.notes.append('%d instruction(s) belong to closures the program never called: they were executed once '
                         'with a mock argument, so they are not covered by the differential execution' % ei)
    hard = [n for n in res.notes if 'unresolved' in n or 'uninterpreted' in n or 'never executed' in n
            or 'undefined variable' in n]
    unverified = [n for n in res.notes if 'not covered by the differential' in n]
    dstat = res.stats.get('differential', {})
    diff_ok = dstat.get('identical') is True or dstat.get('prefix_equal') is True
    if ok_c and not res.stats['residue'] and diff_ok and not hard:
        # 'static': nothing is missing or unresolved, but some decoded instructions were never executed by a
        # replay (decoded by the static sweep only / executed once with a dummy argument)
        res.status = 'static' if unverified else 'ok'
    else:
        res.status = 'partial'
    res.stats['secs'] = round(time.time() - t0, 1)
    return res


def main(argv=None):
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument('input')
    ap.add_argument('-o', '--output', required=True)
    ap.add_argument('--workdir', help='scratch directory (default: a temp directory)')
    ap.add_argument('--reuse-session', action='store_true', help='replay a stored DRM session offline')
    ap.add_argument('--max-runs', type=int, default=40, help='budget of branch-exploration replays')
    ap.add_argument('--report', help='write a JSON report here')
    ap.add_argument('-v', '--verbose', action='store_true')
    a = ap.parse_args(argv)
    src = io.open(a.input, encoding='utf-8', errors='replace').read()
    wd = a.workdir or tempfile.mkdtemp(prefix='luaq_')
    log = (lambda s: print(s, file=sys.stderr)) if a.verbose else (lambda s: None)
    res = deobfuscate(src, wd, reuse_session=a.reuse_session, max_runs=a.max_runs, log=log)
    if a.report:
        io.open(a.report, 'w', encoding='utf-8').write(json.dumps(
            {'ok': res.ok, 'status': res.status, 'reason': res.reason, 'notes': res.notes, 'stats': res.stats}, indent=1, default=str))
    if not res.ok:
        print('deobf: FAILED: %s' % res.reason, file=sys.stderr)
        return 2 if res.reason.startswith('unsupported') else 3
    io.open(a.output, 'w', encoding='utf-8', newline='\n').write(res.source)
    for n in res.notes:
        print('note: %s' % n, file=sys.stderr)
    return 0


def _run_big_stack(argv=None):
    """The structurer recurses once per nested conditional: a long straight-line script (hundreds of
    consecutive ``if`` blocks) needs far more than the default recursion limit and C stack."""
    import threading
    sys.setrecursionlimit(400000)
    threading.stack_size(128 * 1024 * 1024)
    box = []
    th = threading.Thread(target=lambda: box.append(main(argv)))
    th.start()
    th.join()
    return box[0] if box else 3


if __name__ == '__main__':
    sys.exit(_run_big_stack())
