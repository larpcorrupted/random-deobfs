import subprocess, sys, os, re, binascii

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
HOST_TPL = os.path.join(ROOT, 'tool', 'host_template.luau')
LUAU = os.path.join(ROOT, 'work', 'luau-bin', 'luau.exe')

def run(sample_path, outdir, timeout=120):
    os.makedirs(outdir, exist_ok=True)
    with open(sample_path, 'rb') as fh:
        raw = fh.read()
    safe = set('abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789 \t{}[]()<>,.;:=+-*/%^#~_@$&|!?`\'')
    esc = []
    for b in raw:
        c = chr(b)
        if c in safe:
            esc.append(c)
        else:
            esc.append('\\%03d' % b)
    src_literal = '"' + ''.join(esc) + '"'
    host_src = HOST_TPL_READ.replace('__SRC__', src_literal)
    host_path = os.path.join(outdir, 'host.luau')
    with open(host_path, 'w', newline='\n') as fh:
        fh.write(host_src)
    p = subprocess.run([LUAU, host_path], capture_output=True, text=True,
                       encoding='utf-8', errors='replace', timeout=timeout)
    lines = p.stdout.splitlines()
    hexbuf = []
    logs = []
    collecting = None
    for line in lines:
        if line.startswith('@DUMP '):
            collecting = line.strip()
        elif line.startswith('@HEX '):
            hexbuf.append(line[5:])
        elif line.startswith('@LOG'):
            if collecting:
                name = collecting.split()
                data = binascii.unhexlify(''.join(hexbuf))
                dn = os.path.join(outdir, f"dump_{name[1]}_{name[2]}.luau")
                with open(dn, 'wb') as fh:
                    fh.write(data)
                logs.append(f"DUMPED {dn} len={len(data)}")
                collecting = None; hexbuf = []
        elif line.startswith('@L '):
            logs.append(line[3:])
        elif line.startswith('@END'):
            break
    with open(os.path.join(outdir, 'host.log'), 'w', encoding='utf-8') as fh:
        fh.write('\n'.join(logs))
    if p.stderr.strip():
        with open(os.path.join(outdir, 'stderr.txt'), 'w', encoding='utf-8') as fh:
            fh.write(p.stderr)
    return logs

if __name__ == '__main__':
    with open(HOST_TPL) as fh:
        HOST_TPL_READ = fh.read()
    logs = run(sys.argv[1], sys.argv[2])
    for l in logs:
        print(l[:300])
