import subprocess, sys, os, re, binascii

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
LUAU = os.path.join(ROOT, 'work', 'luau-bin', 'luau.exe')

SAFE = set('abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789 \t{}[]()<>,.;:=+-*/%^#~_@$&|!?`\'')

def escape(raw):
    esc = []
    for b in raw:
        c = chr(b)
        esc.append(c if c in SAFE else '\\%03d' % b)
    return '"' + ''.join(esc) + '"'

def run(sample_path, outdir, template, timeout=180):
    os.makedirs(outdir, exist_ok=True)
    with open(sample_path, 'rb') as fh:
        raw = fh.read()
    with open(template) as fh:
        tpl = fh.read()
    host_src = tpl.replace('__SRC__', escape(raw))
    host_path = os.path.join(outdir, 'host.luau')
    with open(host_path, 'w', newline='\n') as fh:
        fh.write(host_src)
    p = subprocess.run([LUAU, host_path], capture_output=True, text=True,
                       encoding='utf-8', errors='replace', timeout=timeout)
    hexes = {}
    cur_tag, cur_len, buf = None, None, []
    logs = []
    def flush():
        nonlocal cur_tag
        if cur_tag is not None:
            data = binascii.unhexlify(''.join(cur_tag[2]))
            fn = os.path.join(outdir, 'cap_%s.bin' % re.sub(r'[^\w#]', '_', cur_tag[0]))
            with open(fn, 'wb') as fh:
                fh.write(data)
            logs.append(f"CAPTURED {os.path.basename(fn)} len={len(data)}")
            cur_tag = None

    cur_tag = None
    for line in p.stdout.splitlines():
        if line.startswith('@HEX '):
            flush()
            _, tag, ln = line.split(' ', 2)
            cur_tag = [tag, int(ln), []]
        elif line.startswith('@H '):
            cur_tag[2].append(line[3:])
        elif line.startswith('@LOG'):
            flush()
        elif line.startswith('@L '):
            logs.append(line[3:])
        elif line.startswith('@END'):
            flush()
            break
    with open(os.path.join(outdir, 'host.log'), 'w', encoding='utf-8') as fh:
        fh.write('\n'.join(logs))
    if p.stderr.strip():
        with open(os.path.join(outdir, 'stderr.txt'), 'w', encoding='utf-8') as fh:
            fh.write(p.stderr)
    return logs

if __name__ == '__main__':
    logs = run(sys.argv[1], sys.argv[2], sys.argv[3])
    for l in logs[:50]:
        print(l[:250])
