"""Assemble the full decompilation pipeline for the user program."""
from . import shape, gen, opt, inline, render, naming, spill


def decompile_root(model, root_sig, notes=None):
    """Return Lua source for the user chunk rooted at proto ``root_sig``."""
    notes = notes if notes is not None else []
    alloc = gen.Alloc()
    fg = gen.FuncGen(model, root_sig, alloc=alloc, notes=notes)
    if not fg.ok:
        return None
    ir, params = fg.build_ir()
    import os as _os0
    if _os0.environ.get('LUAQ_DUMP_IR0'):
        import pprint as _pp0
        with open(_os0.environ['LUAQ_DUMP_IR0'], 'w', encoding='utf-8') as _fh0:
            _pp0.pprint(ir, stream=_fh0, width=160)
    _trace = _os0.environ.get('LUAQ_TRACE_PASS')
    if _trace:
        # debug: after which pass does a pattern disappear from the IR?
        _orig = {}
        for _modname, _mod in (('opt', opt), ('inline', inline), ('shape', shape)):
            for _fn in dir(_mod):
                _f = getattr(_mod, _fn)
                if callable(_f) and not _fn.startswith('_') and _fn not in ('walk_e', 'walk_b', 'map_block', 'walk_e_shallow'):
                    def _wrap(*a, _f=_f, _n=_modname + '.' + _fn, **k):
                        r = _f(*a, **k)
                        hit = _trace in repr(r)
                        print('PASS', _n, 'has' if hit else 'MISSING', flush=True)
                        return r
                    _orig[(_mod, _fn)] = _f
                    setattr(_mod, _fn, _wrap)
        print('PASS build_ir', 'has' if _trace in repr(ir) else 'MISSING')
    ir = opt.unbox(ir)
    ir = opt.drop_nil_inits(ir)
    ir = opt.split_vars(ir)
    for _ in range(3):
        ir = shape.hoist_branch_copies(ir)
        ir = shape.scalarize_tables(ir)
        ir = shape.coalesce_loop_copies(ir)
        ir = opt.propagate(ir)
        ir = inline.inline_all(ir)
        ir = opt.unbox(ir)
    for _ in range(3):
        ir = opt.short_circuit(ir)
        ir = inline.inline_all(ir)
    for _ in range(3):
        ir = opt.simplify_packs(ir)
        ir = shape.fold_constructors(ir)
        ir = inline.inline_all(ir)
        ir = opt.fold_setlist(ir)
        ir = opt.unpack_pack(ir)
        ir = opt.method_calls(ir)
        ir = inline.inline_all(ir)
        ir = opt.short_circuit(ir)
        ir = opt.redundant_conds(ir)
        ir = opt.split_vars(ir)
        ir = opt.propagate(ir)
        ir = inline.inline_all(ir)
    ir = opt.drop_nil_inits(ir)
    ir = shape.fold_constructors(ir)
    ir = inline.inline_all(ir)
    ir = opt.method_calls(ir)
    ir = opt.recover_forin(ir)
    ir = shape.recover_forin_exits(ir)
    ir = inline.inline_all(ir)
    ir = opt.unpack_pack(ir)
    ir = opt.clean_conditions(ir)
    ir = opt.numeric_for(ir)
    ir = opt.flip_comparisons(ir)
    ir = opt.flatten_guards(ir)
    ir = opt.strip_tail_continue(ir)
    ir = opt.strip_tail_return(ir)
    ir = shape.recover_forin_exits(ir)
    ir = opt.mask_unresolved(ir)
    ir = shape.tidy(ir)
    ir = opt.numeric_for(ir)              # (tidy turns `while true do if not C then break end` into `while C`)
    ir = opt.propagate(ir)
    ir = inline.inline_all(ir)
    # the copies removed above expose more `v = X; if X then v = Y end` (and/or) patterns
    for _ in range(2):
        ir = opt.short_circuit(ir)
        ir = shape.hoist_branch_copies(ir)
        ir = shape.coalesce_loop_copies(ir)
        ir = opt.propagate(ir)
        ir = inline.inline_all(ir)
        ir = opt.unbox(ir)
    ir = opt.flip_comparisons(ir)
    import os as _os
    if _os.environ.get('LUAQ_DUMP_IR'):
        import pprint as _pp
        with open(_os.environ['LUAQ_DUMP_IR'], 'w', encoding='utf-8') as _fh:
            _pp.pprint(ir, stream=_fh, width=160)
    ir = naming.rename(ir)
    # Lua allows 200 active locals: declare every variable at its scope first and only spill
    # (fields of one table) when the scoped count still exceeds the limit
    declared = render.declare_vars(ir, set(params))
    if _too_many_locals(declared, params):
        ir = spill.spill_locals(ir, set(params))
        declared = render.declare_vars(ir, set(params))
    ir = declared
    for name in sorted(_undefined_vars(ir, set(params))):
        notes.append('undefined variable %s in the output (decompiler bug or lost definition)' % name)
    out = []
    render.render_block(ir, 0, None, out)
    return '\n'.join(out) + '\n'


def _too_many_locals(ir, params):
    """True if the function (or any closure in it) would exceed ~170 simultaneously active locals."""
    worst = [spill.max_active(ir, params)]

    def f(e):
        if e[0] == 'func':
            worst.append(spill.max_active(list(e[2]), e[1]))
    opt.walk_b(ir, f)
    return max(worst) > 170


def _undefined_vars(ir, params):
    """Variables used where no enclosing block declares them (real lexical scoping: a `local`
    is visible to the later statements of its own block and of the blocks nested in it)."""
    bad = set()

    def expr(e, scope):
        def f(x):
            if x[0] == 'var':
                if not any(x[1] in sc for sc in scope):
                    bad.add(x[1])
            elif x[0] == 'func':
                block(x[2], scope + [set(x[1])])
        opt.walk_e_shallow(e, f)

    def block(stmts, scope):
        sc = set()
        scope = scope + [sc]
        for s in stmts:
            t = s[0]
            if t in ('local', 'callres'):
                expr(s[2], scope)
                sc.add(s[1])
            elif t == 'decl':
                sc.update(s[1])
            elif t == 'multi':
                expr(s[2], scope)
                sc.update(s[1])
            elif t == 'massign':
                expr(s[2], scope)
                for n_ in s[1]:
                    if not any(n_ in x for x in scope):
                        bad.add(n_)
            elif t == 'assign':
                if s[1][0] == 'var':
                    if not any(s[1][1] in x for x in scope):
                        bad.add(s[1][1])
                else:
                    expr(s[1], scope)
                expr(s[2], scope)
            elif t == 'callstmt':
                expr(s[1], scope)
            elif t == 'if':
                expr(s[1], scope)
                block(s[2], scope)
                block(s[3], scope)
            elif t == 'while':
                head = s[1]
                inner = set()
                if head[0] == 'forin':
                    for x in head[2]:
                        expr(x, scope)
                    inner.update(head[1])
                else:
                    expr(head, scope)
                block(s[2], scope + [inner])
            elif t == 'return':
                for v in s[1]:
                    expr(v, scope)

    block(ir, [set(params)])
    return bad
