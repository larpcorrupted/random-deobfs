"""Generate IR (and Lua source) for one lifted function and, recursively, its closures.

Registers are split into webs (def-use connected components) so that the many
reuses of one VM register become separate Lua variables.
"""
import collections

from . import cfg, structure, emit
from .emit import negate, is_ident


def captured_tids(obj, out=None):
    """Ids of box tables captured by closures inside a symbolic structure."""
    out = set() if out is None else out
    if isinstance(obj, tuple) and obj:
        if obj[0] == 'closure' and len(obj) > 2 and obj[2] and obj[2][0] == 'tbl':
            for it in obj[2][1]:
                if isinstance(it, tuple) and it and it[0] == 'tbl' and len(it) > 3:
                    out.add(it[3])
        for x in obj:
            if isinstance(x, (tuple, list)):
                captured_tids(x, out)
    elif isinstance(obj, list):
        for x in obj:
            captured_tids(x, out)
    return out


TEST_HOOKS = False      # emit `__BRF(key, cond)` around branch conditions (forced-branch differential)


import os as _os
_DBG_HOLES = bool(_os.environ.get('LUAQ_DEBUG_HOLES'))

class UF:
    def __init__(self):
        self.p = {}

    def find(self, x):
        self.p.setdefault(x, x)
        while self.p[x] != x:
            self.p[x] = self.p[self.p[x]]
            x = self.p[x]
        return x

    def union(self, a, b):
        ra, rb = self.find(a), self.find(b)
        if ra != rb:
            self.p[rb] = ra


class Alloc:
    """Program-wide unique variable names."""

    def __init__(self):
        self.n = 0

    def new(self, prefix='v'):
        self.n += 1
        return '%s%d' % (prefix, self.n)


class FuncGen:
    def __init__(self, model, sig, alloc=None, capnames=None, notes=None, parent=None):
        self.model = model
        self.sig = sig
        self.pm = model.protos[sig]
        self.alloc = alloc or Alloc()
        self.fid = self.alloc.new('f')
        self.capnames = capnames or {}
        self.notes = notes if notes is not None else []
        self.parent = parent
        pm = self.pm
        nodes = cfg.build_nodes(pm)
        ent_src = pm.entry or getattr(pm, 'entry_sw', None)       # (protos only ever seen by the sweep)
        entry = ent_src.most_common(1)[0][0] if ent_src else None
        self.ok = entry is not None and entry in nodes
        if not self.ok:
            return
        self.nodes, self.entry = cfg.contract(nodes, entry)
        if self.entry not in self.nodes:
            self.ok = False
            return
        self.g = structure.Graph(self.nodes, self.entry)
        self.tree = structure.structure(self.g)
        self.live_in, self.live_out, self.uses, self.defs = emit.liveness(self.g, self.nodes)
        self._webs()
        # promote weak (spread-result) registers that have no older value to clobber
        promoted = False
        for y, nd in self.nodes.items():
            for r, ex in list(nd.weak.items()):
                if r in self.live_out.get(y, ()) and r not in self.reach_in[y] and r not in nd.defs:
                    nd.defs[r] = ex
                    promoted = True
        if promoted:
            self.live_in, self.live_out, self.uses, self.defs = emit.liveness(self.g, self.nodes)
            self._webs()

    # ------------------------------------------------------------------ webs
    def _webs(self):
        g = self.g
        uf = UF()
        entry_regs = sorted(self.live_in.get(self.entry, set()))
        zr = getattr(self.pm, 'param_regs', None)
        if zr is not None:
            # the proto lists its parameter registers in argument order (register numbers are
            # permuted, so sorting them would swap arguments); unused parameters keep their slot
            order = list(zr)
            entry_regs = order + [r for r in entry_regs if r not in order]
        self.params = entry_regs
        reach_in = {y: collections.defaultdict(set) for y in self.nodes}
        for r in entry_regs:
            reach_in[self.entry][r].add(('entry', r))
        changed = True
        while changed:
            changed = False
            for y in g.order:
                cur = reach_in[y]
                for p in g.pred.get(y, []):
                    if p not in self.nodes:
                        continue
                    for r, ds in reach_in[p].items():
                        if r in self.defs[p]:
                            ds = {(p, r)}
                        if not ds <= cur[r]:
                            cur[r] |= ds
                            changed = True
                # registers defined in p but absent from reach_in[p]
                for p in g.pred.get(y, []):
                    if p not in self.nodes:
                        continue
                    for r in self.defs[p]:
                        if (p, r) not in cur[r]:
                            cur[r].add((p, r))
                            changed = True
        self.reach_in = reach_in
        self.use_def = {}
        for y in self.nodes:
            for r in self.uses[y]:
                ds = set(reach_in[y].get(r, set()))
                if r in self.nodes[y].loopdefs:
                    ds.add((y, r))            # loop-carried: the body's own def reaches its use
                if not ds:
                    ds = {('undef', r)}
                ds = sorted(ds, key=str)
                for d in ds[1:]:
                    uf.union(ds[0], d)
                self.use_def[(y, r)] = ds[0]
        self.uf = uf
        self.webname = {}

    def lvname(self, gid, j):
        return 'lv%s_%d_%d' % (self.fid[1:], gid, j)

    def cname(self, y, cid):
        # named after the instruction, not the node: the segments of a split instruction share its call results
        return 'c%s_%d_%d' % (self.fid[1:], y % cfg.SEG, cid)

    def web_var(self, defsite):
        root = self.uf.find(defsite)
        nm = self.webname.get(root)
        if nm is None:
            nm = self.alloc.new('v')
            self.webname[root] = nm
        return nm

    def use_var(self, y, r):
        d = self.use_def.get((y, r))
        if d is None:
            return self.alloc.new('v') if False else 'undef%d' % r
        return self.web_var(d)

    def def_var(self, y, r):
        return self.web_var((y, r))

    def param_names(self):
        return [self.web_var(('entry', r)) for r in self.params]

    # ---------------------------------------------------------- expr lowering
    def lower(self, e, y):
        t = e[0]
        if t in ('num', 'str', 'bool'):
            return ('lit', e[1])
        if t == 'nil':
            return ('lit', None)
        if t == 'reg':
            return ('var', self.use_var(y, e[1]))
        if t == 'const':
            v = self.pm.const(e[1])
            # a missing entry in the (lazily decoded, nil-skipping) pool means the constant is nil -- but only
            # when the VM really fetched it; otherwise it was simply never decoded
            if v is None and str(e[1]) not in self.pm.fetched                     and (self.sig, y % cfg.SEG) not in getattr(self.model, 'natural', ()):
                # no replay executed this instruction and the pool has no entry: nil, or simply never decoded
                self.notes.append('constant rendered as nil without evidence (instruction decoded statically only)')
            return ('lit', v)
        if t == 'glob':
            k = self.lower(e[1], y)
            if k[0] == 'lit' and (k[1] is None or k[1] == 'nil'):
                # a global named nil does not exist: the name constant was never decoded
                self.notes.append('unresolved value global-name constant')
                return ('unknown', 'global-name constant')
            if k[0] == 'lit' and is_ident(k[1]):
                return ('glob', k[1])
            return ('index', ('glob', '_G'), k)
        if t == 'upv':
            n = e[1]
            if n in self.capnames:
                return self.capnames[n]
            return ('var', 'up%d' % n)
        if t == 'idx':
            key = self.lower(e[2], y)
            if key == ('lit', None) and e[2][0] == 'const':
                self.notes.append('unresolved value index-key constant')
                key = ('unknown', 'key constant')
            return ('index', self.lower(e[1], y), key)
        if t == 'callres':
            return ('var', self.cname(y, e[1]))
        if t == 'lvar':
            return ('var', self.lvname(e[1], e[2]))
        if t == 'rres':
            return ('var', self.cname(y, 1000 + e[1]))
        if t == 'pack':
            return ('var', self.cname(y, 2000 + e[1]))
        if t == 'nth':
            return ('index', ('var', self.cname(y, 2000 + e[1])), ('lit', e[2]))
        if t == 'packn':
            return ('index', ('var', self.cname(y, 2000 + e[1])), ('lit', 'n'))
        if t == 'mnth':
            return ('index', self.lower(e[1], y), ('lit', e[2]))
        if t == 'bin':
            return ('bin', e[1], self.lower(e[2], y), self.lower(e[3], y))
        if t == 'un':
            return ('un', e[1], self.lower(e[2], y))
        if t == 'tbl':
            arr = list(e[1])
            rest = []
            nums = {}
            for k, v in (e[2] if len(e) > 2 else []):
                lk = self.lower(k, y)
                if lk[0] == 'lit' and isinstance(lk[1], (int, float)) and not isinstance(lk[1], bool)                         and float(lk[1]).is_integer() and lk[1] >= 1:
                    nums[int(lk[1])] = v
                else:
                    rest.append((k, v))
            # `T[1] = a; T[2] = b` is the array part: positional items (also required when an
            # open tail follows, since a positional item would override `[1] = a`)
            while len(arr) + 1 in nums:
                arr.append(nums.pop(len(arr) + 1))
            rest.extend((('num', k), v) for k, v in sorted(nums.items()))     # sparse numeric keys
            items = [self.lower(x, y) for x in arr]
            for k, v in rest:
                items.append(('kv', self.lower(k, y), self.lower(v, y)))
            if len(e) > 4:
                items.append(('unpack', self.lower(e[4], y)))
            return ('table', items)
        if t == 'unpack':
            if e[1][0] == 'free':
                # the only table a handler unpacks from outside the VM state is the call's vararg pack
                self.uses_vararg = True
                return ('vararg',)
            return ('unpack', self.lower(e[1], y))
        if t == 'vararg':
            return ('vararg',)
        if t == 'closure':
            return self.lower_closure(e, y)
        if t == 'data':
            return ('unknown', 'data')
        self.notes.append('unresolved value %s' % (e[1] if len(e) > 1 and isinstance(e[1], str) else t))
        return ('unknown', e[1] if len(e) > 1 and isinstance(e[1], str) else t)

    def cap_expr(self, it, y):
        """Expression (in the parent) naming the cell captured by a closure slot."""
        if it[0] == 'reg':
            return ('index', ('var', self.use_var(y, it[1])), ('lit', 1))
        if it[0] == 'tbl' and len(it) > 3:
            tid = it[3]
            nd = self.nodes.get(y)
            if nd:
                pools = [nd.defs]
                for op in nd.ops:
                    if op[0] == 'forin':
                        pools.append(op[5])
                for pool in pools:
                    for r, ex in pool.items():
                        if ex[0] == 'tbl' and len(ex) > 3 and ex[3] == tid:
                            return ('index', ('var', self.def_var(y, r)), ('lit', 1))
            return ('unknown', 'cell')
        if it[0] == 'upvslot':
            n = it[2]
            if n in self.capnames:
                return self.capnames[n]
            return ('var', 'up%d' % n)
        return ('unknown', 'cap:%s' % it[0])

    def site_child(self, k, y):
        """Proto of closure ``k`` created by the instruction at ``y``, from the run's create/enter
        markers.  A fused instruction may create several closures: they are told apart by their
        rank in creation order, which is the order of appearance of their ``closure`` expressions."""
        kids = self.model.links.get((self.sig, y % cfg.SEG))
        if not kids:
            return None
        ins = self.pm.instrs.get(y % cfg.SEG)
        ks = []

        def scan(x):
            if isinstance(x, tuple):
                if len(x) > 2 and x[0] == 'closure' and isinstance(x[1], int) and x[1] not in ks:
                    ks.append(x[1])
                for z in x:
                    scan(z)
            elif isinstance(x, list):
                for z in x:
                    scan(z)
        scan(ins.effects if ins else [])
        if k not in ks:
            return None
        if len(ks) == 1 and len(kids) >= 1:
            return kids.get(0)
        return kids.get(ks.index(k))

    def lower_closure(self, e, y):
        k = e[1]
        ch = self.pm.children
        child = ch[k - 1] if 0 < k <= len(ch) else None
        if child is None or child not in self.model.protos:
            alt = self.model.child_by_index.get((self.sig, k))      # exact: the k-th child of this very proto
            if alt is None:
                alt = self.site_child(k, y)
            if alt is not None and alt in self.model.protos:
                child = alt
        if child is None or child not in self.model.protos:
            if _DBG_HOLES:
                import sys
                print('HOLE no-child sig=%s y=%s k=%s child=%s links=%s' % (self.sig, y, k, child,
                      self.model.links.get((self.sig, y % cfg.SEG))), file=sys.stderr)
            return ('func', ['...'], [('comment', 'closure body was never executed')], [])
        ctbl = e[2]
        items = ctbl[1] if ctbl and ctbl[0] == 'tbl' else []
        capnames = {}
        for n, it in enumerate(items, start=1):
            capnames[n] = self.cap_expr(it, y)
        fg = FuncGen(self.model, child, alloc=self.alloc, capnames=capnames,
                     notes=self.notes, parent=self)
        if not fg.ok:
            if _DBG_HOLES:
                import sys
                print('HOLE fg-not-ok sig=%s y=%s k=%s child=%s' % (self.sig, y, k, child), file=sys.stderr)
            return ('func', ['...'], [('comment', 'closure body was never executed')], [])
        ir, params = fg.build_ir()
        return ('func', params, ir, [])

    # ---------------------------------------------------------- node lowering
    def lower_call(self, op, y):
        callee = self.lower(op[1], y)
        args = [self.lower(a, y) for a in op[2]]
        if len(args) == 1 and args[0][0] == 'unpack' and args[0][1][0] == 'table':
            args = list(args[0][1][1])
        if callee[0] == 'index' and callee[2][0] == 'lit' and is_ident(callee[2][1]) \
                and args and args[0] == callee[1]:
            return ('mcall', callee[1], callee[2][1], args[1:])
        return ('call', callee, args)

    def lower_op(self, op, y):
        t = op[0]
        if t == 'call':
            if (len(op) > 4 and op[4]) or op[3] in getattr(self, '_packs_used', ()):
                # results are packed (table.pack); the plain result is the first element
                pk = self.cname(y, 2000 + op[3])
                return [('callres', pk, ('call', ('index', ('glob', 'table'), ('lit', 'pack')), [self.lower_call(op, y)])),
                        ('callres', self.cname(y, op[3]), ('index', ('var', pk), ('lit', 1)))]
            return [('callres', self.cname(y, op[3]), self.lower_call(op, y))]
        if t == 'forin':
            explist, nvars, gid, bops, bdefs = op[1], op[2], op[3], op[4], op[5]
            names = [self.lvname(gid, j) for j in range(nvars)]
            body = []
            bbox = {}
            tids_b = set()
            for ex in bdefs.values():
                captured_tids(ex, tids_b)
            for r, ex in bdefs.items():
                if ex[0] == 'tbl' and len(ex) > 3 and ex[3] in tids_b:
                    bbox[ex[3]] = (r, ex)
            done_b = set()
            for sub in bops:
                need = captured_tids(sub)
                pend = [bbox[t] for t in need if t in bbox and t not in done_b]
                if pend:
                    body.extend(self.order_defs(pend, y))
                    done_b.update(need)
                body.extend(self.lower_op(sub, y))
            live = set(self.live_out.get(y, set())) | set(self.uses.get(y, set()))
            tids = set()

            def scan(e):
                if isinstance(e, tuple) and e:
                    if e[0] == 'closure' and e[2] and e[2][0] == 'tbl':
                        for it in e[2][1]:
                            if it[0] == 'tbl' and len(it) > 3:
                                tids.add(it[3])
                    for x in e:
                        if isinstance(x, (tuple, list)):
                            scan(x) if isinstance(x, tuple) else [scan(z) for z in x]
            for ex in bdefs.values():
                scan(ex)
            for sub in bops:
                for part in sub:
                    if isinstance(part, (tuple, list)):
                        scan(part) if isinstance(part, tuple) else [scan(z) for z in part]
            for r, ex in bdefs.items():
                if ex[0] == 'tbl' and len(ex) > 3 and ex[3] in tids:
                    live.add(r)
            body.extend(self.order_defs([(r, ex) for r, ex in bdefs.items()
                                         if r in live and not (ex[0] == 'tbl' and len(ex) > 3 and ex[3] in done_b)], y))
            return [('while', ('forin', names, [('unpack', self.lower(explist, y))]), body)]
        if t == 'whileloop':
            cond, gid, bops, bdefs = op[1], op[2], op[3], op[4]
            body = []
            for sub in bops:
                body.extend(self.lower_op(sub, y))
            live = set(self.live_out.get(y, set())) | set(self.uses.get(y, set()))
            body.extend(self.order_defs([(r, ex) for r, ex in bdefs.items() if r in live], y))
            return [('while', self.lower(cond, y), body)]
        if t == 'read':
            return [('callres', self.cname(y, 1000 + op[1]), self.lower(op[2], y))]
        if t == 'setidx':
            return [('assign', ('index', self.lower(op[1], y), self.lower(op[2], y)), self.lower(op[3], y))]
        if t == 'settail':
            # SETLIST with an open tail: every value of the pack lands in T[v], T[v+1], ...
            tb = self.lower(op[1], y)
            pk = self.lower(op[3], y)
            return [('callstmt', ('call', ('index', ('glob', 'table'), ('lit', 'move')),
                                  [pk, ('lit', 1), ('index', pk, ('lit', 'n')), ('lit', op[2]), tb]))]
        if t == 'setglob':
            k = self.lower(op[1], y)
            tgt = ('glob', k[1]) if k[0] == 'lit' and is_ident(k[1]) else ('index', ('glob', '_G'), k)
            return [('assign', tgt, self.lower(op[2], y))]
        if t == 'setupv':
            n = op[1]
            return [('assign', self.capnames.get(n, ('var', 'up%d' % n)), self.lower(op[2], y))]
        if t == 'cond':
            inner = self.lower_op(op[2], y)
            cond = None
            for c, pol in op[1]:
                ce = self.lower(c, y)
                ce = ce if pol else negate(ce)
                cond = ce if cond is None else ('bin', 'and', cond, ce)
            return [('if', cond, inner, [])]
        return [('comment', 'unsupported op %s' % t)]

    def lower_node(self, y, with_defs=True):
        nd = self.nodes[y]
        out = []
        if nd.kind == 'broken':
            out.append(('comment', 'uninterpreted instruction at pc %d (%s)' % (y, nd.err)))
            self.notes.append('uninterpreted instruction at pc %d: %s' % (y, nd.err))
            return out
        # the results of a call that a later expression of this node reads as a pack are packed whatever the call op says
        used_packs = set()

        def scan_packs(x):
            if isinstance(x, tuple):
                if len(x) >= 2 and x[0] in ('pack', 'packn', 'nth', 'mnth') and isinstance(x[1], int):
                    used_packs.add(x[1])
                for z in x:
                    scan_packs(z)
            elif isinstance(x, list):
                for z in x:
                    scan_packs(z)
        for op_ in nd.ops:
            scan_packs(op_)
        for e_ in nd.defs.values():
            scan_packs(e_)
        saved_packs = getattr(self, '_packs_used', ())
        self._packs_used = used_packs
        try:
            return self._lower_node_inner(y, nd, with_defs, out)
        finally:
            self._packs_used = saved_packs

    def _lower_node_inner(self, y, nd, with_defs, out):
        box_defs = {}
        if True:        # (also in a returning node: the cells its closures capture must exist)
            tids_all = set()
            for e in nd.defs.values():
                captured_tids(e, tids_all)
            for op in nd.ops:               # (a cell captured only by a closure that an op uses is a box too)
                captured_tids(op, tids_all)
            for r, e in nd.defs.items():
                if e[0] == 'tbl' and len(e) > 3 and e[3] in tids_all:
                    box_defs[e[3]] = (r, e)
        emitted_boxes = set()
        for op in nd.ops:
            need = captured_tids(op)
            pend = [box_defs[t] for t in need if t in box_defs and t not in emitted_boxes]
            if pend:
                out.extend(self.order_defs(pend, y))
                emitted_boxes.update(t for t in need if t in box_defs)
            out.extend(self.lower_op(op, y))
        if with_defs:
            live = set(self.live_out.get(y, set()))
            # boxes captured by a closure created in this node must exist as variables
            tids = set()

            def scan(e):
                if isinstance(e, tuple) and e:
                    if e[0] == 'closure' and e[2] and e[2][0] == 'tbl':
                        for it in e[2][1]:
                            if it[0] == 'tbl' and len(it) > 3:
                                tids.add(it[3])
                    for x in e:
                        if isinstance(x, (tuple, list)):
                            scan(x) if isinstance(x, tuple) else [scan(z) for z in x]
            for e in nd.defs.values():
                scan(e)
            for r, e in nd.defs.items():
                if e[0] == 'tbl' and len(e) > 3 and e[3] in tids:
                    live.add(r)
            defs = [(r, e) for r, e in nd.defs.items()
                    if r in live and r not in nd.loopdefs
                    and not (e[0] == 'tbl' and len(e) > 3 and e[3] in emitted_boxes)]
            # boxes (captured cells) must exist before the closures that capture them
            defs.sort(key=lambda it: 0 if (it[1][0] == 'tbl' and len(it[1]) > 3) else 1)
            out.extend(self.order_defs(defs, y))
        return out

    def order_defs(self, defs, y):
        """Defs are a parallel assignment from entry state; webs make clobbering impossible,
        so a plain ordered assignment is correct."""
        out = []
        for r, e in defs:
            if e[0] == 'free':
                # a register loaded straight from a name outside the VM state: the call's vararg pack (VARARG)
                self.uses_vararg = True
                ex = ('table', [('vararg',)])
            else:
                ex = self.lower(e, y)
            tgt = self.def_var(y, r)
            if ex == ('var', tgt):
                continue
            out.append(('assign', ('var', tgt), ex))
        return out

    # ------------------------------------------------------------ structuring
    def exit_var(self, header):
        """Flag variable recording which exit of the loop with this header was taken."""
        names = self.__dict__.setdefault('_exit_vars', {})
        if header not in names:
            names[header] = self.alloc.new('exit')
        return names[header]

    def cond_expr(self, y):
        nd = self.nodes[y]
        ce = self.lower(nd.cond[0], y)
        pol = nd.cond[1]
        return ce if pol else negate(ce)

    def gen_tree(self, tree):
        out = []
        for t in tree:
            k = t[0]
            if k == 'node':
                out.extend(self.lower_node(t[1]))
            elif k == 'ret':
                y = t[1]
                out.extend(self.lower_node(y, with_defs=False))
                nd = self.nodes[y]
                vals = []
                for ex in nd.exits:
                    if ex.kind == 'ret':
                        vals = [self.lower(v, y) for v in ex.val]
                        break
                out.append(('return', vals))
            elif k == 'if':
                y = t[1]
                out.extend(self.lower_node(y))
                cond = self.cond_expr(y)
                nd_ = self.nodes[y]
                if TEST_HOOKS and nd_.j is not None:
                    # test variant: the branch decision goes through the replay's force table
                    cond = ('call', ('glob', '__BRF'), [('lit', '%d:%d:%d' % (self.sig, y % cfg.SEG, nd_.j)), cond])
                tb = self.gen_tree(t[2])
                fb = self.gen_tree(t[3])
                if not tb and fb:
                    out.append(('if', negate(cond), fb, []))
                else:
                    out.append(('if', cond, tb, fb))
            elif k == 'loop':
                body = self.gen_tree(t[2])
                if len(t) > 3 and t[3]:
                    out.append(('assign', ('var', self.exit_var(t[1])), ('lit', 0)))
                out.append(('while', ('lit', True), body))
            elif k == 'break_flag':
                out.append(('assign', ('var', self.exit_var(t[1])), ('lit', t[2])))
                out.append(('break',))
            elif k == 'loopexit':
                flag = ('var', self.exit_var(t[1]))
                tail = self.gen_tree(t[3])
                for kk, sub in reversed(t[2]):
                    tail = [('if', ('bin', '==', flag, ('lit', kk)), self.gen_tree(sub), tail)]
                out.extend(tail)
            elif k == 'break':
                out.append(('break',))
            elif k == 'continue':
                out.append(('continue',))
            elif k == 'break_to':
                out.append(('comment', 'jump to pc %d' % t[1]))
            elif k == 'unreached':
                out.append(('comment', 'code at pc %s was never executed' % (t[1],)))
        return out

    def build_ir(self):
        from . import post
        ir = self.gen_tree(self.tree)
        params = self.param_names()
        if getattr(self, 'uses_vararg', False) and '...' not in params:
            params = list(params) + ['...']
        return ir, params
