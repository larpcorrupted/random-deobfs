"""CFG analysis and structuring: dominators, post-dominators, natural loops and a
region-based conversion of the graph into nested ('seq'|'if'|'loop'|...) trees.

The tree nodes (tuples):
  ('node', y)                       straight-line body of CFG node y
  ('if', y, taken_tree, fall_tree)  conditional node y (cond taken -> taken_tree)
  ('loop', header_y, body_tree)     while-true loop; body uses ('break',) / ('continue',)
  ('break',)  ('continue',)
  ('ret', y)                        node y ends in return
  ('unreached', y)                  successor that was never executed
  ('seq', [trees])
"""
import collections


class Graph:
    def __init__(self, nodes, entry):
        self.nodes = nodes
        self.entry = entry
        self.succ = {}
        self.pred = collections.defaultdict(list)
        for y, n in nodes.items():
            ss = []
            for s in n.succ:
                if s not in ss:
                    ss.append(s)
            self.succ[y] = [s for s in ss if s in nodes]
            for s in ss:
                if s in nodes:
                    self.pred[s].append(y)
        self.order = self._rpo()
        self.idom = self._dominators()
        self.ipdom = self._postdominators()
        self.loops = self._loops()

    # ------------------------------------------------------------- orderings
    def _rpo(self):
        seen = set()
        post = []

        def dfs(y):
            stack = [(y, iter(self.succ.get(y, [])))]
            seen.add(y)
            while stack:
                v, it = stack[-1]
                for s in it:
                    if s not in seen:
                        seen.add(s)
                        stack.append((s, iter(self.succ.get(s, []))))
                        break
                else:
                    post.append(v)
                    stack.pop()
        dfs(self.entry)
        post.reverse()
        return post

    def _dominators(self):
        idom = {self.entry: self.entry}
        index = {y: i for i, y in enumerate(self.order)}

        def intersect(a, b):
            while a != b:
                while index[a] > index[b]:
                    a = idom[a]
                while index[b] > index[a]:
                    b = idom[b]
            return a
        changed = True
        while changed:
            changed = False
            for y in self.order:
                if y == self.entry:
                    continue
                preds = [p for p in self.pred[y] if p in idom]
                if not preds:
                    continue
                new = preds[0]
                for p in preds[1:]:
                    new = intersect(new, p)
                if idom.get(y) != new:
                    idom[y] = new
                    changed = True
        return idom

    def _postdominators(self):
        EXIT = ('exit',)
        rsucc = collections.defaultdict(list)    # reversed graph successors = preds
        nodes = list(self.nodes) + [EXIT]
        rpred = collections.defaultdict(list)    # preds in reversed graph = succs here
        for y in self.nodes:
            ss = self.succ.get(y, [])
            if not ss:
                rsucc[EXIT].append(y)
                rpred[y].append(EXIT)
            for s in ss:
                rsucc[s].append(y)
                rpred[y].append(s)
        # RPO on reversed graph from EXIT
        seen = set([EXIT])
        post = []
        stack = [(EXIT, iter(rsucc[EXIT]))]
        while stack:
            v, it = stack[-1]
            for s in it:
                if s not in seen:
                    seen.add(s)
                    stack.append((s, iter(rsucc[s])))
                    break
            else:
                post.append(v)
                stack.pop()
        post.reverse()
        index = {y: i for i, y in enumerate(post)}
        ipd = {EXIT: EXIT}

        def intersect(a, b):
            while a != b:
                while index[a] > index[b]:
                    a = ipd[a]
                while index[b] > index[a]:
                    b = ipd[b]
            return a
        changed = True
        while changed:
            changed = False
            for y in post:
                if y == EXIT:
                    continue
                preds = [p for p in rpred[y] if p in ipd]
                if not preds:
                    continue
                new = preds[0]
                for p in preds[1:]:
                    new = intersect(new, p)
                if ipd.get(y) != new:
                    ipd[y] = new
                    changed = True
        self.EXIT = EXIT
        return ipd

    def dominates(self, a, b):
        while True:
            if a == b:
                return True
            nb = self.idom.get(b)
            if nb is None or nb == b:
                return False
            b = nb

    def _loops(self):
        """Natural loops: header -> set of body nodes."""
        loops = {}
        for y in self.order:
            for s in self.succ.get(y, []):
                if self.dominates(s, y):      # back edge y -> s
                    body = loops.setdefault(s, {s})
                    stack = [y]
                    while stack:
                        v = stack.pop()
                        if v not in body:
                            body.add(v)
                            stack.extend(p for p in self.pred[v] if p in self.nodes)
        return loops


MAX_COPIES = 40


def structure(g):
    """Convert graph into a nested tree."""
    ctx = {'loops': [], 'visiting': set(), 'count': {}}

    def region(y, stop, loopctx, entering=False):
        """Emit tree for nodes starting at y until reaching `stop` (exclusive).  ``entering``: this call expands
        the body of the loop headed by y (any other arrival at the header is a `continue`)."""
        out = []
        first = True
        while y is not None and y != stop:
            if loopctx and y == loopctx[-1][0] and not (entering and first):
                out.append(('continue',))
                return out
            first = False
            if y not in g.nodes:
                out.append(('unreached', y))
                break
            # loop header handling
            if y in g.loops and (not loopctx or loopctx[-1][0] != y):
                body_nodes = g.loops[y]
                exits = set()
                for v in body_nodes:
                    for s in g.succ.get(v, []):
                        if s not in body_nodes:
                            exits.add(s)
                # the loop continues after the (unique or dominant) exit
                after = None
                if exits:
                    # choose exit with most predecessors inside the loop (the while-exit)
                    after = sorted(exits, key=lambda e: (-sum(1 for p in g.pred[e] if p in body_nodes), e))[0]
                extras = {}
                inner = region(y, None, loopctx + [(y, body_nodes, after, extras)], True)
                out.append(('loop', y, inner, dict(extras)))
                if extras:
                    # other exits of the loop: a flag records which one was taken, the code that
                    # follows each exit is emitted after the loop (up to the common join)
                    join = g.ipdom.get(y)
                    if join == g.EXIT or join in body_nodes:
                        join = None
                    branches = [(k, region(t_, join, loopctx))
                                for t_, k in sorted(extras.items(), key=lambda kv: kv[1])]
                    main = region(after, join, loopctx) if after is not None else []
                    out.append(('loopexit', y, branches, main))
                    y = join
                    continue
                y = after
                continue
            # leaving the loop?
            if loopctx:
                lh, lbody, lafter, lextras = loopctx[-1]
                if y == lh and len(out) > 0 or (y == lh and loopctx[-1][0] == y and out and False):
                    out.append(('continue',))
                    return out
                if lafter is not None and y == lafter:
                    out.append(('break',))
                    return out
                if y not in lbody and y != lafter:
                    # leaving the loop to a node other than the chosen exit: set the exit flag, leave
                    out.append(('break_flag', lh, lextras.setdefault(y, len(lextras) + 1)))
                    return out
            # a join that the structurer cannot recognise is expanded once per path to it; a node that was
            # already expanded this many times is not copied again (the output says where it jumps to)
            ctx['count'][y] = ctx['count'].get(y, 0) + 1
            if ctx['count'][y] > MAX_COPIES:
                out.append(('break_to', y))
                break
            nd = g.nodes[y]
            ss = g.succ.get(y, [])
            if nd.kind == 'ret' or not ss:
                out.append(('ret', y) if nd.kind == 'ret' else ('node', y))
                if nd.kind != 'ret':
                    # a successor that was never decoded: the function does not end here, its code is unknown
                    missing = [s for s in (nd.succ or []) if s not in g.nodes]
                    if missing:
                        out.append(('unreached', missing[0]))
                break
            if nd.kind == 'cond' and len(nd.succ) == 2:
                taken, fall = nd.succ[0], nd.succ[1]
                join = g.ipdom.get(y)
                if join == g.EXIT:
                    join = None
                if loopctx:
                    # a join outside the loop means the branches leave/continue the loop
                    lh, lbody, lafter, lextras = loopctx[-1]
                    if join is not None and (join not in lbody or join == lh):
                        join = None
                if y in ctx['visiting']:
                    # a cycle that is no natural loop (irreducible flow): do not expand it again
                    out.append(('break_to', y))
                    break
                ctx['visiting'].add(y)
                try:
                    t_tree = region(taken, join, loopctx) if taken != join else []
                    f_tree = region(fall, join, loopctx) if fall != join else []
                finally:
                    ctx['visiting'].discard(y)
                out.append(('if', y, t_tree, f_tree))
                if join is None:
                    break
                y = join
                continue
            out.append(('node', y))
            nxt = ss[0] if ss else None
            if loopctx:
                lh, lbody, lafter, lextras = loopctx[-1]
                if nxt == lh:
                    out.append(('continue',))
                    return out
            y = nxt
        return out

    tree = region(g.entry, None, [])
    return tree
