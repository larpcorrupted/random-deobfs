"""Static model of a Luaq (variant A) VM extracted from its own source.

The dispatch loop is a binary decision tree over a state word ``g``.  Some
leaves ("step nodes") fill the operand table; others ("exec leaves") compute
``p = (c1 + c2*M) % mod`` from the instruction's opcode word ``M`` and select a
handler body with a second decision tree over ``p``.  All of that is recovered
from the AST, so renamed variables / reshuffled trees do not matter.
"""
from . import luaparse as lp


def _eq_const(cond, var):
    """If cond is `var == <number>` (either order) return the number."""
    if cond[0] == 'Bin' and cond[1] == '==':
        a, b = cond[2], cond[3]
        if a == ('Name', var) and b[0] == 'Number':
            return b[1]
        if b == ('Name', var) and a[0] == 'Number':
            return a[1]
    return None


def _collect_cases(block, var, out):
    """Collect {const: body} for `if var == const then body` anywhere in a
    binary decision tree (descending through comparison nodes)."""
    for s in block:
        t = s[0]
        if t == 'If':
            for cond, b in s[1]:
                c = _eq_const(cond, var)
                if c is not None:
                    out[c] = b
                else:
                    _collect_cases(b, var, out)
            if s[2] is not None:
                _collect_cases(s[2], var, out)
        elif t == 'Do':
            _collect_cases(s[1], var, out)


def _count_ifs(node):
    n = [0]

    def f(x):
        if x[0] == 'If':
            n[0] += 1
    lp.walk(node, f)
    return n[0]


def find_dispatch_loop(ast):
    """Return (loop_node, g_name, flag_name) for the main dispatch loop."""
    best = [None, -1]

    def visit(n):
        if n[0] == 'While' and n[1][0] == 'Name' and n[2]:
            first = n[2][0]
            if first[0] == 'Do' and first[1]:
                first = first[1][0]
            if first[0] == 'Local' and len(first[1]) == 1 and first[2] \
                    and first[2][0][0] in ('Bin', 'Paren'):
                score = _count_ifs(n)
                if score > best[1]:
                    best[0], best[1] = n, score
    lp.walk(ast, visit)
    if best[0] is None:
        raise ValueError('dispatch loop not found in AST')
    loop = best[0]
    first = loop[2][0]
    if first[0] == 'Do':
        first = first[1][0]
    return loop, first[1][0], loop[1][1]


class Leaf:
    __slots__ = ('gid', 'body', 'pvar', 'formula', 'cases')

    def __init__(self, gid, body):
        self.gid = gid
        self.body = body
        self.pvar = None
        self.formula = None
        self.cases = None


def _strip_paren(e):
    while e[0] == 'Paren':
        e = e[1]
    return e


def parse_exec_leaf(gid, body):
    """If body starts with `local p = (...) % mod` build a Leaf with cases."""
    if not body:
        return None
    s0 = body[0]
    if s0[0] != 'Local' or len(s0[1]) != 1 or not s0[2]:
        return None
    e = _strip_paren(s0[2][0])
    if e[0] != 'Bin' or e[1] != '%':
        return None
    mod = _strip_paren(e[3])
    if mod[0] != 'Number':
        return None
    leaf = Leaf(gid, body)
    leaf.pvar = s0[1][0]
    leaf.formula = (_strip_paren(e[2]), mod[1])
    cases = {}
    _collect_cases(body[1:], leaf.pvar, cases)
    leaf.cases = cases
    return leaf


def eval_formula(expr, mod, M):
    """Evaluate an arithmetic AST over the single free variable (opcode word)."""
    def ev(e):
        e = _strip_paren(e)
        t = e[0]
        if t == 'Number':
            return float(e[1])
        if t == 'Name':
            return float(M)
        if t == 'Bin':
            a, b = ev(e[2]), ev(e[3])
            op = e[1]
            if op == '+':
                return a + b
            if op == '-':
                return a - b
            if op == '*':
                return a * b
            if op == '%':
                return a % b
            if op == '/':
                return a / b
        if t == 'Un' and e[1] == '-':
            return -ev(e[2])
        raise ValueError('unsupported formula node %r' % (t,))
    return int(ev(expr) % mod)


def find_step_fn(ast):
    """Name of the VM's generic-`for` step helper: a one-parameter local function that calls
    ``P[1](P[2], P[3])`` (iterator, state, control).  Its exact shape is polymorphic, this call is not."""
    found = []

    def has_triple_call(fn, p):
        hit = []

        def v(n):
            if n[0] == 'Call' and n[1][0] == 'Index' and n[1][1] == ('Name', p) and n[1][2] == ('Number', 1)                     and len(n[2]) == 2 and all(a[0] == 'Index' and a[1] == ('Name', p) for a in n[2])                     and n[2][0][2] == ('Number', 2) and n[2][1][2] == ('Number', 3):
                hit.append(1)
        lp.walk(fn[3], v)
        return bool(hit)

    def visit(n):
        if n[0] == 'LocalFunction' and n[2][0] == 'Function' and len(n[2][1]) == 1:
            if has_triple_call(n[2], n[2][1][0]):
                found.append(n[1])
    lp.walk(ast, visit)
    return found[0] if len(found) == 1 else None


# ---------------------------------------------------------------------------------------------------------------
# Luaq 2.5: every opcode has its own case of the dispatch tree.  A case is
#     if <op> ~= K or <rec> ~= B or <pc> ~= E or <rec>[1] ~= <op> then <kill> end
#     do <prologue: decode the operands into locals / the operand table, remap them> <semantics> end
#     <state> = ...; continue
# The prologue is VM bookkeeping; the semantics read the decoded operands.  The tool runs the semantics
# symbolically with the operand values a probe records right after the prologue.
# ---------------------------------------------------------------------------------------------------------------
OPV_BASE = 90000          # operand locals are reported under the keys OPV_BASE + 1, + 2, ... of the operand row


class HBody(list):
    """Semantic statements of a 2.5 handler; `oplocals` are bound to the recorded operand values, `opaque` are
    prologue locals (VM bookkeeping) the semantics cannot meaningfully read."""
    oplocals = ()
    opaque = ()
    roles = None
    gid = None


def _or_chain(e, out):
    e = _strip_paren(e)
    if e[0] == 'Bin' and e[1] == 'or':
        _or_chain(e[2], out)
        _or_chain(e[3], out)
    else:
        out.append(e)
    return out


def _integrity(s):
    """The integrity test opening a 2.5 handler case -> dict(op=, rec=, pairs=[(n1, n2)]) or None."""
    if s[0] != 'If' or len(s[1]) != 1 or s[2] is not None:
        return None
    cl = _or_chain(s[1][0][0], [])
    if len(cl) < 3 or not all(c[0] == 'Bin' and c[1] == '~=' for c in cl):
        return None
    op = rec = None
    pairs = []
    for c in cl:
        a, b = _strip_paren(c[2]), _strip_paren(c[3])
        if a[0] == 'Name' and b[0] == 'Number':
            op = a[1]
        elif b[0] == 'Name' and a[0] == 'Number':
            op = b[1]
        elif a[0] == 'Index' and a[1][0] == 'Name' and a[2] == ('Number', 1) and b[0] == 'Name':
            rec = a[1][1]
        elif b[0] == 'Index' and b[1][0] == 'Name' and b[2] == ('Number', 1) and a[0] == 'Name':
            rec = b[1][1]
        elif a[0] == 'Name' and b[0] == 'Name':
            pairs.append((a[1], b[1]))
    if op is None or rec is None:
        return None
    return dict(op=op, rec=rec, pairs=pairs, kill=s[1][0][1])


def _local_names(st):
    if st[0] == 'Local':
        return list(st[1])
    if st[0] == 'LocalFunction':
        return [st[1]]
    return []


def _is_clear_loop(st, alias):
    # for v = #alias, K, -1 do alias[v] = nil end
    return (st[0] == 'NumFor' and _strip_paren(st[2]) == ('Un', '#', ('Name', alias))
            and len(st[5]) == 1 and st[5][0][0] == 'Assign' and st[5][0][1][0][0] == 'Index'
            and st[5][0][1][0][1] == ('Name', alias))


def _has_call(e):
    found = []
    lp.walk(e, lambda n: found.append(1) if n[0] in ('Call', 'Method') else None)
    return bool(found)


def _is_remap(st, q):
    """`X = q[X]` / `do local w = A[k]; w[i] = q[w[i]] ... end` (operand remapping through the table q)."""
    if st[0] == 'Assign' and len(st[1]) == len(st[2]) >= 1:
        return all(v[0] == 'Index' and v[1] == ('Name', q) and v[2] == t for t, v in zip(st[1], st[2]))
    if st[0] == 'If' and st[2] is None and all(not _has_call(c) and blk and all(_is_remap(x, q) for x in blk)
                                               for c, blk in st[1]):
        return True              # `if d ~= 0 then d = q[d] end` (optional operand)
    if st[0] == 'Do' and st[1]:
        # a block that only rewrites operand entries through q (locals, loops and tests allowed, no calls)
        seen = []

        def chk(b):
            for x in b:
                if x[0] == 'Assign' and all(t[0] == 'Index' for t in x[1])                         and all(v[0] == 'Index' and v[1] == ('Name', q) for v in x[2]):
                    seen.append(1)
                    continue
                if x[0] == 'Local' and q not in x[1] and not any(_has_call(e) for e in x[2]):
                    continue
                if x[0] == 'NumFor' and chk(x[5]):
                    continue
                if x[0] == 'If' and x[2] is None and all(not _has_call(c) and chk(blk) for c, blk in x[1]):
                    continue
                if x[0] == 'Do' and chk(x[1]):
                    continue
                return False
            return True
        return chk(st[1]) and bool(seen)
    return False


def split_handler25(blk, outer_ops):
    """Split the Do-block of a 2.5 handler: returns dict(oplocals, alias, boundary, opaque) or None when the
    block has no decode prologue (its statements are all semantics)."""
    # the remap step: `local q, s; if C then q, s = .. else q, s = R() end; j = s`
    k = None
    for i in range(len(blk) - 2):
        st = blk[i]
        if st[0] == 'Local' and len(st[1]) == 2 and not st[2] and blk[i + 1][0] == 'If' \
                and blk[i + 2][0] == 'Assign' and len(blk[i + 2][1]) == 1 and blk[i + 2][1][0][0] == 'Name' \
                and blk[i + 2][2] == [('Name', st[1][1])]:
            k = i
            break
    if k is None:
        return None
    q = blk[k][1][0]
    b = k + 3
    while b < len(blk) and _is_remap(blk[b], q):
        b += 1
    # bindings at the boundary, in declaration order
    binding = {}
    oplocals = []
    alias = None
    for i in range(0, b):
        st = blk[i]
        if i == 0 and st[0] == 'Local' and not st[2]:
            for n in st[1]:
                binding[n] = 'op'
            continue
        if st[0] == 'Local' and len(st[1]) == 1 and len(st[2]) == 1 and st[2][0][0] == 'Name' \
                and st[2][0][1] in outer_ops and i + 1 < len(blk) and _is_clear_loop(blk[i + 1], st[1][0]):
            binding[st[1][0]] = 'alias'
            continue
        for n in _local_names(st):
            binding[n] = 'opaque'
    if blk and blk[0][0] == 'Local' and not blk[0][2]:
        oplocals = [n for n in blk[0][1] if binding.get(n) == 'op']
    aliases = [n for n, v in binding.items() if v == 'alias']
    alias = aliases[-1] if aliases else None
    opaque = [n for n, v in binding.items() if v == 'opaque']
    return dict(oplocals=oplocals, alias=alias, boundary=b, opaque=opaque, remap=q, bound=binding)


def _destructured(body, name):
    """Number of leading `local x = name[k]` statements of a handler body."""
    n = 0
    for st in body:
        if st[0] == 'Local' and len(st[1]) == 1 and len(st[2]) == 1 and st[2][0][0] == 'Index' \
                and st[2][0][1] == ('Name', name) and st[2][0][2][0] == 'Number':
            n += 1
        elif n:
            break
    return n


class VMModel:
    def __init__(self, ast):
        self.step_fn = find_step_fn(ast)
        self.loop, self.gname, self.flag = find_dispatch_loop(ast)
        gcases = {}
        _collect_cases(self.loop[2], self.gname, gcases)
        self.leaves = {}
        self.steps = {}
        self.v25 = False
        n25 = sum(1 for b in gcases.values() if len(b) >= 2 and _integrity(b[0]) and b[1][0] == 'Do')
        if n25 >= 16:
            self._init25(gcases)
            return
        for gid, body in gcases.items():
            lf = parse_exec_leaf(gid, body)
            if lf and lf.cases:
                self.leaves[gid] = lf
            else:
                self.steps[gid] = body

    # ------------------------------------------------------------------ 2.5
    def _init25(self, gcases):
        from collections import Counter
        self.v25 = True
        integ = {}
        for gid, body in gcases.items():
            if len(body) >= 2 and body[1][0] == 'Do':
                it = _integrity(body[0])
                if it:
                    integ[gid] = it
                    continue
            self.steps[gid] = body
        # opcode word / instruction record: the names every integrity test uses
        self.opname = Counter(i['op'] for i in integ.values()).most_common(1)[0][0]
        self.recname = Counter(i['rec'] for i in integ.values()).most_common(1)[0][0]
        # pc: the fetch step saves `B, E = rec, pc`; the integrity test compares the live pc with E
        saved = {}
        for body in self.steps.values():
            for st in body:
                if st[0] == 'Assign' and len(st[1]) == len(st[2]) >= 2 and ('Name', self.recname) in st[2]:
                    for t, v in zip(st[1], st[2]):
                        if t[0] == 'Name' and v[0] == 'Name':
                            saved[t[1]] = v[1]
        pcs = Counter()
        for it in integ.values():
            for a, b in it['pairs']:
                if self.recname in (a, b):
                    continue
                if saved.get(b) == a:
                    pcs[a] += 1
                elif saved.get(a) == b:
                    pcs[b] += 1
        # operand table(s): `local alias = U` followed by the clearing loop
        outer = Counter()
        for gid in integ:
            blk = gcases[gid][1][1]
            for i, st in enumerate(blk[:-1]):
                if st[0] == 'Local' and len(st[1]) == 1 and len(st[2]) == 1 and st[2][0][0] == 'Name' \
                        and _is_clear_loop(blk[i + 1], st[1][0]):
                    outer[st[2][0][1]] += 1
        self.opstable = outer.most_common(1)[0][0] if outer else None
        if not pcs:
            # fallback: `local r = pc - 1` (cache key of the instruction) in the prologues
            for gid in integ:
                for st in gcases[gid][1][1][:12]:
                    if st[0] == 'Local' and len(st[2]) == 1 and st[2][0][0] == 'Bin' and st[2][0][1] == '-' \
                            and st[2][0][2][0] == 'Name' and st[2][0][3] == ('Number', 1):
                        pcs[st[2][0][2][1]] += 1
        self.pcname = pcs.most_common(1)[0][0] if pcs else None
        # proto: the instruction cache lookup `local c = P.<field>[r]`
        protos = Counter()
        for gid in integ:
            for st in gcases[gid][1][1][:12]:
                if st[0] == 'Local' and len(st[2]) == 1 and st[2][0][0] == 'Index' and st[2][0][1][0] == 'Index' \
                        and st[2][0][1][1][0] == 'Name' and st[2][0][2][0] == 'Name':
                    protos[st[2][0][1][1][1]] += 1
        self.protoname = protos.most_common(1)[0][0] if protos else None
        self.h25 = {}
        regs = Counter()
        splits = {}
        for gid in integ:
            blk = gcases[gid][1][1]
            sp = split_handler25(blk, {self.opstable} if self.opstable else set())
            splits[gid] = sp
            if sp is None:
                continue
            ops = set(n for n, v in sp['bound'].items() if v == 'op')

            def f(n, ops=ops):
                if n[0] == 'Index' and n[1][0] == 'Name' and n[2][0] == 'Name' and n[2][1] in ops:
                    regs[n[1][1]] += 1
            lp.walk(blk[sp['boundary']:], f)
        self.regname = regs.most_common(1)[0][0] if regs else None
        from . import symexec
        for gid in integ:
            blk = gcases[gid][1][1]
            sp = splits[gid]
            hb = HBody(blk[sp['boundary']:] if sp else blk)
            hb.gid = gid
            hb.split = sp
            hb.block = blk
            bound = sp['bound'] if sp else {}

            def role(name):
                if name is None:
                    return None
                return ('__shadowed_' + name) if name in bound else name
            alias = sp['alias'] if sp else None
            a2 = self.opstable if self.opstable and self.opstable not in bound else None
            hb.oplocals = tuple(sp['oplocals']) if sp else ()
            hb.opaque = tuple(sp['opaque']) if sp else ()
            r = symexec.Roles(role(self.regname), alias or a2, role(self.protoname), role(self.pcname),
                              role(self.flag))
            r.a2 = a2
            hb.roles = r
            self.h25[gid] = hb
            self.leaves[gid] = hb

    def roles_of(self, body):
        from . import symexec
        if isinstance(body, HBody):
            return body.roles
        key = id(body)
        cache = self.__dict__.setdefault('_roles', {})
        if key not in cache:
            r = symexec.handler_roles(body)
            r2s = symexec.handler_roles(body, scoped=True)
            if r is not None and r2s is not None and r2s.u is not None and r2s.a is not None and r2s.a != r.a \
                    and _destructured(body, r2s.a) >= 6:
                # `local v = i[1] ... local i = i[25]`: the handler unpacks its operand table into locals and finally
                # rebinds the table's own name; only the lexical analysis sees that `i` is the operand table
                r = r2s
            if r is None or r.u is None or r.a is None:
                # a nested scope that reuses a role name (closure parameter, `for F = ...` loop variable) hides it
                # from the plain scan: the lexical one sees where the name is really free
                r2 = symexec.handler_roles(body, scoped=True)
                if r2 is not None and (r is None or (r2.u is not None and r2.a is not None)):
                    r = r2
            if r is not None and r.pc is None:
                r.pc = self._majority_pc()
            cache[key] = r
        return cache[key]

    def _majority_pc(self):
        from collections import Counter
        if self.v25:
            return self.pcname
        mp = self.__dict__.get('_mpc')
        if mp is None:
            from . import symexec
            c = Counter()
            for lf in self.leaves.values():
                for b in list(lf.cases.values())[:60]:
                    r = symexec.handler_roles(b)
                    if r is not None and r.pc:
                        c[r.pc] += 1
            mp = self.__dict__['_mpc'] = (c.most_common(1)[0][0] if c else None)
        return mp

    def handler(self, gid, M):
        """Return (p, body) for exec leaf gid and opcode word M, or None."""
        lf = self.leaves.get(gid)
        if not lf:
            return None
        if self.v25:
            return gid, lf
        p = eval_formula(lf.formula[0], lf.formula[1], M)
        return p, lf.cases.get(p)
