"""Lift traced VM instructions of the user protos into a per-proto model.

For every executed exec-leaf row we interpret the handler symbolically
(:mod:`symexec`) and store the effect list per (proto, pc).  Observed pc
transitions per invocation give the control-flow edges.  Several runs (the
baseline plus branch-forcing replays) can be merged into one model.
"""
import collections

from . import symexec, trace

# Strings that only occur in the Luaq loader's own protos (session handshake,
# integrity/capsule logic).  Used to separate the loader chain from user code.
LOADER_MARKERS = (
    'buildId', 'sessionId', 'challengeTag', 'expiresAt', 'responseTag', 'ciphertext',
    'LUAQ_', 'Luaq ', 'capability', 'JSONEncode', 'JSONDecode',
    'raw-indexed-v1', 'RequestAsync', 'EncodingService', 'ComputeStringHash',
)


class Instr:
    __slots__ = ('y', 'M', 'g', 'A', 'effects', 'width', 'err', 'count')

    def __init__(self, y, M, g, A, effects, err=None):
        self.y, self.M, self.g, self.A = y, M, g, A
        self.effects = effects
        self.err = err
        self.width = None
        self.count = 0
        if effects:
            for e in effects:
                if e[0] == 'pc' and e[1][0] == 'rel':
                    self.width = e[1][1]
                    break


class ProtoModel:
    def __init__(self, sig):
        self.sig = sig
        self.consts = {}            # merged constant pool: str(index) -> value
        self.const_field = None
        self.fetched = set()        # constant indexes (as str) that an executed instruction fetched
        self.children = []          # child signatures (index = closure operand)
        self.fields = {}
        self.instrs = {}            # y -> Instr
        self.edges = collections.defaultdict(collections.Counter)   # y -> {next_y: n}
        self.entry = collections.Counter()    # first y per invocation
        self.entry_sw = collections.Counter() # same, seen by a static sweep only (the sweep starts every call at the real entry)
        self.nparams = None
        self.param_regs = None      # registers receiving the call arguments, in argument order
        self.invocations = 0

    def const(self, k):
        return self.consts.get(str(k))

    def absorb_data(self, data, param_field=None, const_hint=None):
        pr = trace.param_regs(data, param_field)
        if pr is not None:
            self.param_regs = pr
        roles = trace.proto_fields(data)
        cf = roles.get('consts')
        if self.const_field and self.const_field in data:
            cf = self.const_field            # the field is chosen once per proto: later runs
        if const_hint and const_hint in data:
            cf = const_hint                  # the field name is the same in every proto of a sample
        if cf:                               # decode more entries but may rank fields differently
            self.const_field = cf
            pool = data[cf]
            # 'nil' is the placeholder of a constant that has not been decoded yet
            if isinstance(pool, list):
                for i, v in enumerate(pool):
                    if v is not None and v != 'nil':
                        self.consts[str(i + 1)] = v
            else:
                for k, v in pool.items():
                    if v is not None and v != 'nil':
                        self.consts[k] = v
        if roles.get('children'):
            self.children = [(c.get('__sig') if c else None) for c in trace.children_of(data, roles)]
        self.fields = {k: v for k, v in data.items() if isinstance(v, (int, float)) and not isinstance(v, bool)}


def is_loader_proto(data):
    roles = trace.proto_fields(data)
    pool = data.get(roles.get('consts')) if roles.get('consts') else None
    vals = list(pool.values()) if isinstance(pool, dict) else (pool or [])
    for v in vals:
        if isinstance(v, str) and any(m in v for m in LOADER_MARKERS):
            return True
    return False


def select_user_protos(run):
    """Return (roots, all_user_ids).  Roots = protos first seen after the
    session was opened that are not children of another proto and not loader code;
    all_user_ids additionally includes every descendant of a root."""
    open_at = run.open_at or 0
    cand = [pid for pid, at in sorted(run.first_seen.items(), key=lambda kv: kv[1])
            if at >= open_at and pid in run.protos]
    child_sigs = set()
    for pid, d in run.protos.items():
        for ch in trace.children_of(d):
            if ch and ch.get('__sig') is not None:
                child_sigs.add(ch['__sig'])
    roots = [pid for pid in cand if pid not in child_sigs and not is_loader_proto(run.protos[pid])]
    if run.open_at is None:
        # no remote session (Luaq 2.5): the VM first runs its own runtime (environment checks), which then makes a
        # closure of the program's main proto -- a proto that is not one of the creator's own children
        kids = {pid: {(c or {}).get('__sig') for c in trace.children_of(d)} for pid, d in run.protos.items()}
        try:
            links = run.closure_links(lambda p: False)
        except Exception:
            links = []
        foreign = []
        for cp, _cy, _od, callee in links:
            if cp in run.protos and callee in run.protos and callee not in kids.get(cp, ()) \
                    and callee not in child_sigs and callee not in foreign:
                foreign.append(callee)
        if foreign:
            roots = sorted(foreign, key=lambda p: run.first_seen.get(p, 0))
    # descendants
    keep = set(roots)
    stack = list(roots)
    while stack:
        pid = stack.pop()
        d = run.protos.get(pid)
        if not d:
            continue
        for ch in trace.children_of(d):
            s = ch.get('__sig') if ch else None
            if s is not None and s not in keep:
                keep.add(s)
                stack.append(s)
    return roots, keep


class Model:
    """Accumulates interpreted instructions over several runs."""

    def __init__(self, vm, roles):
        symexec.STEP_FN = getattr(vm, 'step_fn', None)
        self.vm = vm
        self.roles = roles
        self.protos = {}
        self.links = {}             # (creator proto, creator pc) -> proto of the closure it creates
        self.child_by_index = {}    # (creator proto, child index) -> proto of that child (exact: no pc involved)
        self.stats = collections.Counter()
        self.nruns = 0
        self.roots = []
        self.keep = set()
        self.const_votes = collections.Counter()
        self.cfetch_seen = False    # the probe on constant fetches produced data (else: no evidence either way)

    @staticmethod
    def _badness(eff):
        txt = repr(eff)
        # a pc that stays symbolic (`pc + <something>` instead of a number) means the operand table was not
        # recognised: the jump target would be lost
        return (txt.count("'unkv'") + txt.count("'free'") + txt.count("'PROTO'") + 5 * txt.count("('unk',")
                + 5 * txt.count("('pcv',)"))

    def interpret_best(self, vm, body, A):
        """Interpret a handler with the sample-wide roles and with the roles this handler
        itself uses (the VM permutes variables between decode paths); keep the cleaner result."""
        cands = []
        if getattr(vm, 'v25', False):
            # (2.5) each handler names its own operands: only its own roles apply
            cands = [vm.roles_of(body)]
        elif self.roles is not None:
            cands.append(self.roles)
        hr = vm.roles_of(body)
        if hr is not None and (not cands or vars(hr) != vars(cands[0])):
            cands.append(hr)
        if not cands:
            cands.append(symexec.Roles(None, None, None, vm._majority_pc(), None))
        best, besterr = None, None
        for roles in cands:
            try:
                eff = symexec.interpret(body, roles, A)
            except symexec.Unsupported as e:
                besterr = besterr or str(e)
                continue
            except Exception as e:  # noqa
                besterr = besterr or 'crash:%r' % (e,)
                continue
            score = self._badness(eff)
            if best is None or score < best[0]:
                best = (score, eff)
            if score == 0:
                break
        if best is not None:
            return best[1], None
        return None, besterr or 'uninterpretable'

    def add_run(self, run, restrict=None):
        self.nruns += 1
        vm = self.vm
        roots, keep = select_user_protos(run)
        # closures created by user code are user code (their parent's JSON need not nest them)
        _lp = {}

        def _is_loader(pid):
            r_ = _lp.get(pid)
            if r_ is None:
                r_ = _lp[pid] = pid in run.protos and is_loader_proto(run.protos[pid])
            return r_
        links = run.closure_links(_is_loader)
        grew = True
        while grew:
            grew = False
            for cp, cy, od, callee in links:
                if cp in keep and callee not in keep and callee in run.protos:
                    keep.add(callee)
                    grew = True
        for cp, cy, od, callee in links:
            if cp in keep and callee in keep:
                self.links.setdefault((cp, cy), {}).setdefault(od, callee)
        for cp, idx, callee in run.index_links:
            if (cp in keep or cp in self.keep) and (callee in keep or callee in self.keep):
                self.child_by_index.setdefault((cp, idx), callee)
        for pid_, k_ in run.cfetch:
            self.cfetch_seen = True
            self.protos.setdefault(pid_, ProtoModel(pid_)).fetched.add(str(k_))
        bodies = {callee for cp_, _cy, _od, callee in links if cp_ in keep or cp_ in self.keep}
        for kids in self.links.values():
            bodies.update(kids.values())
        for r in roots:
            # (a static sweep first sees every closure body of the program, and a replay with forced branches
            # may create closures the first run never did: a proto that is the body of a closure is no chunk)
            if r not in self.roots and r not in bodies and not getattr(run, 'sweep', False):
                self.roots.append(r)
        self.keep |= keep
        want = keep if restrict is None else restrict
        pfield = getattr(vm, 'param_field', None)
        if not pfield or not any(pfield in d for d in run.protos.values()):
            pfield = trace.guess_param_field(run.protos)
        # the constant pool is the same field in every proto of the sample: a vote over all protos is more
        # reliable than the data shape of a single, mostly undecoded proto
        votes = self.const_votes
        for d_ in run.protos.values():
            f_ = trace.proto_fields(d_).get('consts')
            if f_:
                votes[f_] += 1
        hint = votes.most_common(1)[0][0] if votes else None
        for pid in keep | self.keep:        # (a later run decodes more of the pool of protos the first run found)
            d = run.protos.get(pid)
            if d is not None:
                pmx = self.protos.setdefault(pid, ProtoModel(pid))
                if hint and pmx.const_field and pmx.const_field != hint and hint in d:
                    pmx.const_field = None; pmx.consts = {}       # an earlier run guessed the wrong field
                pmx.absorb_data(d, pfield, hint)
        last_by_inv = {}
        for r in run.rows:
            pid = r['id']
            if pid is None or pid not in want:
                continue
            if r['g'] not in vm.leaves or r['M'] is None:
                continue
            pm = self.protos.setdefault(pid, ProtoModel(pid))
            y = r['y']
            ins = pm.instrs.get(y)
            if (ins is None or ins.M != r['M'] or (ins.A is None and r['A'] is not None)
                    or (ins.err and r['A'] is not None and ins.A != r['A'])):
                h = vm.handler(r['g'], r['M'])
                body = h[1] if h else None
                err = None
                effects = None
                if body is None:
                    err = 'no handler'
                else:
                    effects, err = self.interpret_best(vm, body, r['A'])
                    if err:
                        self.stats['unsupported:' + err] += 1
                ins = Instr(y, r['M'], r['g'], r['A'], effects, err)
                pm.instrs[y] = ins
            ins.count += 1
            key = (self.nruns, r['inv'])
            prev = last_by_inv.get(key)
            if prev is None or prev[0] != pid:
                if not getattr(run, 'sweep', False):
                    pm.entry[y] += 1
                else:
                    pm.entry_sw[y] += 1
                pm.invocations += 1
            elif not getattr(run, 'sweep', False):
                pm.edges[prev[1]][y] += 1          # (a sweep redirects the pc: its row order is not control flow)
            last_by_inv[key] = (pid, y)
        # absolute pc assignments seen by a sweep (hashed jumps): the dispatch loop adds 1
        for spid, sy, sv in getattr(run, 'sweep_pc', ()):
            spm = self.protos.get(spid)
            if spm is not None and sy in spm.instrs:
                spm.edges[sy][sv + 1] += 1
