"""A compact Lua 5.x / Luau-subset tokenizer and parser.

AST nodes are tuples whose first element is the node tag.

Expressions:
  ('Nil',) ('True',) ('False',) ('Vararg',)
  ('Number', value) ('String', value)         (String value is ``bytes``-like str, latin-1)
  ('Name', id)
  ('Index', obj, key)                          obj.key / obj[key]
  ('Call', fn, [args])
  ('Method', obj, name, [args])
  ('Function', [params], is_vararg, block)
  ('Bin', op, lhs, rhs)   ('Un', op, e)
  ('Table', [(kind, k, v)...])                 kind in 'arr' | 'key'
  ('Paren', e)
Statements:
  ('Local', [names], [exprs])        ('Assign', [targets], [exprs])
  ('CAssign', op, target, expr)      ('CallStmt', callexpr)
  ('Do', block)  ('While', cond, block)  ('Repeat', block, cond)
  ('If', [(cond, block)...], else_block_or_None)
  ('NumFor', var, a, b, c_or_None, block)  ('GenFor', [names], [exprs], block)
  ('LocalFunction', name, func)  ('FuncStmt', target_expr, func)
  ('Return', [exprs])  ('Break',)  ('Continue',)  ('Goto', name)  ('Label', name)
A block is a Python list of statements.
"""
import re

KEYWORDS = frozenset(
    'and break do else elseif end false for function goto if in local nil not or '
    'repeat return then true until while'.split())

_TOKEN_RE = re.compile(r'''
    (?P<ws>[ \t\r\n]+)
  | (?P<lcomment>--\[(?P<lceq>=*)\[)
  | (?P<comment>--[^\n]*)
  | (?P<lstring>\[(?P<lseq>=*)\[)
  | (?P<number>0[xX][0-9a-fA-F_]*(?:\.[0-9a-fA-F_]*)?(?:[pP][+-]?\d+)?
       |0[bB][01_]+
       |(?:\d[\d_]*\.?[\d_]*|\.\d[\d_]*)(?:[eE][+-]?\d+)?)
  | (?P<name>[A-Za-z_][A-Za-z_0-9]*)
  | (?P<str>["'])
  | (?P<op>\.\.\.|\.\.=|//=|\.\.|==|~=|<=|>=|//|::|\+=|-=|\*=|/=|%=|\^=|->|[-+*/%^\#<>=(){}\[\];:,.&|~])
''', re.X)


class LuaSyntaxError(Exception):
    pass


_ESC = {'n': '\n', 't': '\t', 'r': '\r', 'a': '\a', 'b': '\b', 'f': '\f',
        'v': '\v', '\\': '\\', '"': '"', "'": "'", '\n': '\n'}


def _read_short_string(src, i, q):
    out = []
    n = len(src)
    while i < n:
        c = src[i]
        if c == q:
            return ''.join(out), i + 1
        if c == '\\':
            i += 1
            c = src[i]
            if c in _ESC:
                out.append(_ESC[c])
                i += 1
            elif c.isdigit():
                j = i
                while j < n and j < i + 3 and src[j].isdigit():
                    j += 1
                out.append(chr(int(src[i:j]) & 0xFF))
                i = j
            elif c == 'x':
                out.append(chr(int(src[i + 1:i + 3], 16)))
                i += 3
            elif c == 'z':
                i += 1
                while i < n and src[i] in ' \t\r\n':
                    i += 1
            elif c == 'u':
                j = src.index('}', i)
                cp = int(src[i + 2:j], 16)
                out.append(chr(cp).encode('utf-8').decode('latin-1'))
                i = j + 1
            else:
                out.append(c)
                i += 1
        elif c == '\n':
            raise LuaSyntaxError('unfinished string')
        else:
            out.append(c)
            i += 1
    raise LuaSyntaxError('unfinished string')


def tokenize(src, offsets=None):
    """Return list of (kind, value) with kind in name/kw/num/str/op/eof.
    If ``offsets`` is a list, (start, end) source offsets per token are appended."""
    toks = []
    i = 0
    n = len(src)
    match = _TOKEN_RE.match
    ntok = 0
    while i < n:
        if offsets is not None and len(toks) > ntok:
            offsets.append((tok_start, i))
            ntok = len(toks)
        tok_start = i
        m = match(src, i)
        if not m:
            raise LuaSyntaxError('bad char %r at %d' % (src[i], i))
        k = m.lastgroup
        if k == 'lceq':
            k = 'lcomment'
        if k == 'lseq':
            k = 'lstring'
        if k == 'ws' or k == 'comment':
            i = m.end()
        elif k == 'lcomment':
            close = ']' + m.group('lceq') + ']'
            j = src.find(close, m.end())
            if j < 0:
                raise LuaSyntaxError('unfinished long comment')
            i = j + len(close)
        elif k == 'lstring':
            close = ']' + m.group('lseq') + ']'
            j = src.find(close, m.end())
            if j < 0:
                raise LuaSyntaxError('unfinished long string')
            s = src[m.end():j]
            if s.startswith('\r\n'):
                s = s[2:]
            elif s.startswith('\n'):
                s = s[1:]
            toks.append(('str', s))
            i = j + len(close)
        elif k == 'number':
            t = m.group(0).replace('_', '')
            if t[:2] in ('0x', '0X'):
                try:
                    v = float.fromhex(t) if ('.' in t or 'p' in t.lower()) else int(t, 16)
                except ValueError:
                    v = int(t, 16)
            elif t[:2] in ('0b', '0B'):
                v = int(t[2:], 2)
            elif re.fullmatch(r'\d+', t):
                v = int(t)
            else:
                v = float(t)
            toks.append(('num', v))
            i = m.end()
        elif k == 'name':
            w = m.group(0)
            toks.append(('kw' if w in KEYWORDS else 'name', w))
            i = m.end()
        elif k == 'str':
            s, i = _read_short_string(src, m.end(), m.group(0))
            toks.append(('str', s))
        else:
            toks.append(('op', m.group(0)))
            i = m.end()
    if offsets is not None and len(toks) > ntok:
        offsets.append((tok_start, i))
    toks.append(('eof', None))
    if offsets is not None:
        offsets.append((n, n))
    return toks


_BINPRI = {
    'or': (1, 1), 'and': (2, 2),
    '<': (3, 3), '>': (3, 3), '<=': (3, 3), '>=': (3, 3), '~=': (3, 3), '==': (3, 3),
    '|': (4, 4), '~': (5, 5), '&': (6, 6),
    '..': (9, 8), '+': (10, 10), '-': (10, 10),
    '*': (11, 11), '/': (11, 11), '//': (11, 11), '%': (11, 11),
    '^': (14, 13),
}
_UNPRI = 12


class Offsets(list):
    """Token offsets plus the token index at which each If-clause block starts."""
    bstarts = None
    sranges = None
    cranges = None


class Parser:
    def __init__(self, toks, track=False):
        self.t = toks
        self.i = 0
        self.track = track
        self.bstarts = {}
        self.sranges = {}           # id(Assign/CAssign node) -> (first token, token after the last)
        self.cranges = {}           # id(Call node) -> (first token, token after the last)

    # -- helpers
    def peek(self):
        return self.t[self.i]

    def next(self):
        tk = self.t[self.i]
        self.i += 1
        return tk

    def check(self, kind, val=None):
        tk = self.t[self.i]
        return tk[0] == kind and (val is None or tk[1] == val)

    def accept(self, kind, val=None):
        if self.check(kind, val):
            self.i += 1
            return True
        return False

    def expect(self, kind, val=None):
        if not self.check(kind, val):
            raise LuaSyntaxError('expected %s %r near token %d (%r)' % (
                kind, val, self.i, self.t[self.i]))
        tk = self.t[self.i]
        self.i += 1
        return tk[1]

    def kw(self, w):
        return self.check('kw', w)

    def op(self, w):
        return self.check('op', w)

    # -- blocks
    def block(self):
        stmts = []
        while True:
            tk = self.peek()
            if tk[0] == 'eof':
                break
            if tk[0] == 'kw' and tk[1] in ('end', 'else', 'elseif', 'until'):
                break
            if tk[0] == 'kw' and tk[1] == 'return':
                self.next()
                exprs = []
                tk2 = self.peek()
                if not (tk2[0] == 'eof' or (tk2[0] == 'kw' and tk2[1] in ('end', 'else', 'elseif', 'until'))
                        or (tk2[0] == 'op' and tk2[1] == ';')):
                    exprs = self.exprlist()
                self.accept('op', ';')
                stmts.append(('Return', exprs))
                break
            s = self.statement()
            if s is not None:
                stmts.append(s)
        return stmts

    def statement(self):
        st = self.i
        r = self._statement()
        if r is not None and r[0] in ('While', 'Local', 'Goto', 'Label') and self.track:
            r = r + ((st, self.i),)
        elif r is not None and self.track:
            self.sranges[id(r)] = (st, self.i)
        return r

    def _statement(self):
        tk = self.peek()
        k, v = tk
        if k == 'op' and v == ';':
            self.next()
            return None
        if k == 'op' and v == '::':
            self.next()
            name = self.expect('name')
            self.expect('op', '::')
            return ('Label', name)
        if k == 'kw':
            if v == 'if':
                return self.if_stmt()
            if v == 'while':
                self.next()
                c = self.expr()
                self.expect('kw', 'do')
                b = self.block()
                self.expect('kw', 'end')
                return ('While', c, b)
            if v == 'do':
                self.next()
                b = self.block()
                self.expect('kw', 'end')
                return ('Do', b)
            if v == 'for':
                return self.for_stmt()
            if v == 'repeat':
                self.next()
                b = self.block()
                self.expect('kw', 'until')
                c = self.expr()
                return ('Repeat', b, c)
            if v == 'function':
                self.next()
                target = ('Name', self.expect('name'))
                is_method = False
                while True:
                    if self.accept('op', '.'):
                        target = ('Index', target, ('String', self.expect('name')))
                    elif self.accept('op', ':'):
                        target = ('Index', target, ('String', self.expect('name')))
                        is_method = True
                        break
                    else:
                        break
                f = self.funcbody(is_method)
                return ('FuncStmt', target, f)
            if v == 'local':
                self.next()
                if self.accept('kw', 'function'):
                    name = self.expect('name')
                    f = self.funcbody(False)
                    return ('LocalFunction', name, f)
                names = [self.expect('name')]
                self._skip_type()
                while self.accept('op', ','):
                    names.append(self.expect('name'))
                    self._skip_type()
                exprs = []
                if self.accept('op', '='):
                    exprs = self.exprlist()
                return ('Local', names, exprs)
            if v == 'break':
                self.next()
                return ('Break',)
            if v == 'goto':
                self.next()
                return ('Goto', self.expect('name'))
        if k == 'name' and v == 'continue':
            # Luau `continue` (contextual keyword): only a statement if followed by a block end
            nxt = self.t[self.i + 1]
            if not (nxt[0] == 'op' and nxt[1] in ('=', '.', '[', '(', ':', ',')) and not nxt[0] == 'str':
                self.next()
                return ('Continue',)
        # expression statement / assignment
        e = self.suffixedexp()
        tk = self.peek()
        if tk[0] == 'op' and tk[1] in ('=', ','):
            targets = [e]
            while self.accept('op', ','):
                targets.append(self.suffixedexp())
            self.expect('op', '=')
            exprs = self.exprlist()
            return ('Assign', targets, exprs)
        if tk[0] == 'op' and tk[1] in ('+=', '-=', '*=', '/=', '//=', '%=', '^=', '..='):
            self.next()
            rhs = self.expr()
            return ('CAssign', tk[1][:-1], e, rhs)
        if e[0] not in ('Call', 'Method'):
            raise LuaSyntaxError('syntax error near token %d (%r)' % (self.i, self.peek()))
        return ('CallStmt', e)

    def _skip_type(self):
        # Luau type annotation `: T` after a local name (best-effort)
        if self.op(':'):
            self.next()
            depth = 0
            while True:
                tk = self.peek()
                if tk[0] == 'eof':
                    break
                if tk[0] == 'op' and tk[1] in ('(', '{', '<'):
                    depth += 1
                elif tk[0] == 'op' and tk[1] in (')', '}', '>'):
                    if depth == 0:
                        break
                    depth -= 1
                elif depth == 0 and (tk[0] == 'op' and tk[1] in (',', '=', ';')
                                     or (tk[0] == 'kw' and tk[1] in ('in', 'then', 'do'))):
                    break
                self.next()

    def if_stmt(self):
        self.expect('kw', 'if')
        clauses = []
        cranges = []
        t0 = self.i
        c = self.expr()
        cranges.append((t0, self.i))
        self.expect('kw', 'then')
        bs = self.i
        blk = self.block()
        self.bstarts[id(blk)] = bs
        clauses.append((c, blk))
        els = None
        while True:
            if self.accept('kw', 'elseif'):
                t0 = self.i
                c = self.expr()
                cranges.append((t0, self.i))
                self.expect('kw', 'then')
                bs = self.i
                blk = self.block()
                self.bstarts[id(blk)] = bs
                clauses.append((c, blk))
            elif self.accept('kw', 'else'):
                bs = self.i
                els = self.block()
                self.bstarts[id(els)] = bs
                self.expect('kw', 'end')
                break
            else:
                self.expect('kw', 'end')
                break
        if self.track:
            return ('If', clauses, els, cranges)
        return ('If', clauses, els)

    def for_stmt(self):
        self.expect('kw', 'for')
        n1 = self.expect('name')
        if self.accept('op', '='):
            a = self.expr()
            self.expect('op', ',')
            b = self.expr()
            c = None
            if self.accept('op', ','):
                c = self.expr()
            self.expect('kw', 'do')
            blk = self.block()
            self.expect('kw', 'end')
            return ('NumFor', n1, a, b, c, blk)
        names = [n1]
        while self.accept('op', ','):
            names.append(self.expect('name'))
        self.expect('kw', 'in')
        exprs = self.exprlist()
        self.expect('kw', 'do')
        blk = self.block()
        self.expect('kw', 'end')
        return ('GenFor', names, exprs, blk)

    def funcbody(self, is_method):
        self.expect('op', '(')
        params = ['self'] if is_method else []
        vararg = False
        if not self.op(')'):
            while True:
                if self.accept('op', '...'):
                    vararg = True
                    break
                params.append(self.expect('name'))
                self._skip_type()
                if not self.accept('op', ','):
                    break
        self.expect('op', ')')
        if self.accept('op', ':'):
            self._skip_type_ret()
        body = self.block()
        self.expect('kw', 'end')
        return ('Function', params, vararg, body)

    def _skip_type_ret(self):
        depth = 0
        while True:
            tk = self.peek()
            if tk[0] == 'eof':
                break
            if tk[0] == 'op' and tk[1] in ('(', '{', '<'):
                depth += 1
            elif tk[0] == 'op' and tk[1] in (')', '}', '>'):
                depth -= 1
            elif depth <= 0 and tk[0] in ('kw', 'name') and tk[1] not in ('nil', 'string', 'number', 'boolean', 'any'):
                break
            self.next()
            if depth <= 0:
                break

    # -- expressions
    def exprlist(self):
        es = [self.expr()]
        while self.accept('op', ','):
            es.append(self.expr())
        return es

    def primaryexp(self):
        tk = self.next()
        k, v = tk
        if k == 'name':
            return ('Name', v)
        if k == 'op' and v == '(':
            e = self.expr()
            self.expect('op', ')')
            if e[0] in ('Call', 'Method', 'Vararg'):
                return ('Paren', e)       # parentheses truncate multiple values
            return e
        raise LuaSyntaxError('unexpected symbol %r at token %d' % (tk, self.i))

    def suffixedexp(self):
        st = self.i
        e = self.primaryexp()
        while True:
            tk = self.peek()
            k, v = tk
            if k == 'op' and v == '.':
                self.next()
                e = ('Index', e, ('String', self.expect('name')))
            elif k == 'op' and v == '[':
                self.next()
                key = self.expr()
                self.expect('op', ']')
                e = ('Index', e, key)
            elif k == 'op' and v == ':':
                self.next()
                name = self.expect('name')
                e = ('Method', e, name, self.callargs())
            elif (k == 'op' and v in ('(', '{')) or k == 'str':
                e = ('Call', e, self.callargs())
                if self.track:
                    self.cranges[id(e)] = (st, self.i)
            else:
                return e

    def callargs(self):
        tk = self.peek()
        if tk[0] == 'str':
            self.next()
            return [('String', tk[1])]
        if tk[0] == 'op' and tk[1] == '{':
            return [self.table()]
        self.expect('op', '(')
        if self.accept('op', ')'):
            return []
        args = self.exprlist()
        self.expect('op', ')')
        return args

    def table(self):
        self.expect('op', '{')
        items = []
        while not self.op('}'):
            tk = self.peek()
            if tk[0] == 'op' and tk[1] == '[':
                self.next()
                k = self.expr()
                self.expect('op', ']')
                self.expect('op', '=')
                items.append(('key', k, self.expr()))
            elif tk[0] == 'name' and self.t[self.i + 1] == ('op', '='):
                self.next()
                self.next()
                items.append(('key', ('String', tk[1]), self.expr()))
            else:
                items.append(('arr', None, self.expr()))
            if not (self.accept('op', ',') or self.accept('op', ';')):
                break
        self.expect('op', '}')
        return ('Table', items)

    def simpleexp(self):
        tk = self.peek()
        k, v = tk
        if k == 'num':
            self.next()
            return ('Number', v)
        if k == 'str':
            self.next()
            return ('String', v)
        if k == 'kw':
            if v == 'nil':
                self.next()
                return ('Nil',)
            if v == 'true':
                self.next()
                return ('True',)
            if v == 'false':
                self.next()
                return ('False',)
            if v == 'function':
                self.next()
                return self.funcbody(False)
            if v == 'if':  # Luau if-expression
                self.next()
                c = self.expr()
                self.expect('kw', 'then')
                a = self.expr()
                els = None
                if self.accept('kw', 'elseif'):
                    # rewrite elseif chain as nested ifexp
                    self.i -= 1
                    self.t[self.i] = ('kw', 'if')
                    els = self.simpleexp()
                else:
                    self.expect('kw', 'else')
                    els = self.expr()
                return ('IfExp', c, a, els)
        if k == 'op' and v == '...':
            self.next()
            return ('Vararg',)
        if k == 'op' and v == '{':
            return self.table()
        return self.suffixedexp()

    def expr(self, limit=0):
        tk = self.peek()
        if (tk[0] == 'kw' and tk[1] == 'not') or (tk[0] == 'op' and tk[1] in ('-', '#', '~')):
            self.next()
            e = self.expr(_UNPRI)
            left = ('Un', tk[1], e)
        else:
            left = self.simpleexp()
        while True:
            tk = self.peek()
            op = tk[1] if tk[0] in ('op', 'kw') else None
            pri = _BINPRI.get(op) if op in _BINPRI and (tk[0] == 'op' or op in ('and', 'or')) else None
            if not pri or pri[0] <= limit:
                break
            self.next()
            right = self.expr(pri[1])
            left = ('Bin', op, left, right)
        return left


def parse(src, with_offsets=False):
    """Parse a chunk.  With ``with_offsets`` returns (ast, offsets) and While/Local
    statements carry a trailing (first_tok, end_tok) element."""
    offs = Offsets() if with_offsets else None
    p = Parser(tokenize(src, offs), track=with_offsets)
    b = p.block()
    if p.peek()[0] != 'eof':
        raise LuaSyntaxError('unexpected token %r at %d' % (p.peek(), p.i))
    if with_offsets:
        offs.bstarts = p.bstarts
        offs.sranges = p.sranges
        offs.cranges = p.cranges
    return (b, offs) if with_offsets else b


def walk(node, fn):
    """Pre-order walk over any AST structure (tuples / lists)."""
    if isinstance(node, tuple):
        if node and isinstance(node[0], str):
            if fn(node) is False:
                return
        for ch in node:
            if isinstance(ch, (tuple, list)):
                walk(ch, fn)
    elif isinstance(node, list):
        for ch in node:
            if isinstance(ch, (tuple, list)):
                walk(ch, fn)


# ---------------------------------------------------------------- unparser
_UNPARSE_PRI = {'or': 1, 'and': 2, '<': 3, '>': 3, '<=': 3, '>=': 3, '~=': 3, '==': 3,
                '|': 4, '~': 5, '&': 6, '..': 8, '+': 10, '-': 10, '*': 11, '/': 11,
                '//': 11, '%': 11, '^': 13}


def lua_quote(s):
    out = ['"']
    for ch in s:
        o = ord(ch)
        if ch == '"':
            out.append('\\"')
        elif ch == '\\':
            out.append('\\\\')
        elif ch == '\n':
            out.append('\\n')
        elif ch == '\r':
            out.append('\\r')
        elif ch == '\t':
            out.append('\\t')
        elif 32 <= o < 127:
            out.append(ch)
        else:
            out.append('\\%03d' % (o & 0xFF) if o < 256 else '\\u{%x}' % o)
    out.append('"')
    return ''.join(out)


def _num(v):
    if isinstance(v, float):
        if v == int(v) and abs(v) < 1e15:
            return str(int(v))
        return repr(v)
    return str(v)


def ue(e, parent=0):
    t = e[0]
    if t == 'Nil':
        return 'nil'
    if t == 'True':
        return 'true'
    if t == 'False':
        return 'false'
    if t == 'Vararg':
        return '...'
    if t == 'Number':
        return _num(e[1])
    if t == 'String':
        return lua_quote(e[1])
    if t == 'Name':
        return e[1]
    if t == 'Paren':
        return '(' + ue(e[1]) + ')'
    if t == 'Index':
        if e[2][0] == 'String' and re.fullmatch(r'[A-Za-z_]\w*', e[2][1]) and e[2][1] not in KEYWORDS:
            return ue(e[1], 99) + '.' + e[2][1]
        return ue(e[1], 99) + '[' + ue(e[2]) + ']'
    if t == 'Call':
        f = e[1]
        fs = ue(f, 99)
        if f[0] in ('Function', 'Table', 'String', 'Number', 'Bin', 'Un', 'Nil', 'True', 'False'):
            fs = '(' + fs + ')'
        return fs + '(' + ', '.join(ue(a) for a in e[2]) + ')'
    if t == 'Method':
        return ue(e[1], 99) + ':' + e[2] + '(' + ', '.join(ue(a) for a in e[3]) + ')'
    if t == 'Bin':
        p = _UNPARSE_PRI[e[1]]
        s = ue(e[2], p) + ' ' + e[1] + ' ' + ue(e[3], p + 1)
        return '(' + s + ')' if p < parent else s
    if t == 'Un':
        s = e[1] + ('' if e[1] != 'not' else ' ') + ue(e[2], 12)
        return '(' + s + ')' if parent > 12 else s
    if t == 'IfExp':
        return 'if %s then %s else %s' % (ue(e[1]), ue(e[2]), ue(e[3]))
    if t == 'Table':
        items = []
        for kind, k, v in e[1]:
            if kind == 'arr':
                items.append(ue(v))
            elif k[0] == 'String' and re.fullmatch(r'[A-Za-z_]\w*', k[1]) and k[1] not in KEYWORDS:
                items.append('%s = %s' % (k[1], ue(v)))
            else:
                items.append('[%s] = %s' % (ue(k), ue(v)))
        return '{' + ', '.join(items) + '}'
    if t == 'Function':
        ps = list(e[1]) + (['...'] if e[2] else [])
        body = ub(e[3], 1)
        return 'function(' + ', '.join(ps) + ')\n' + body + '\nend'
    raise ValueError('cannot unparse expr %r' % (t,))


def ub(block, ind=0, step='  '):
    pad = step * ind
    lines = []
    for s in block:
        lines.append(us(s, ind, step))
    return '\n'.join(lines)


def us(s, ind=0, step='  '):
    pad = step * ind
    t = s[0]
    if t == 'Local':
        r = pad + 'local ' + ', '.join(s[1])
        if s[2]:
            r += ' = ' + ', '.join(ue(x) for x in s[2])
        return r
    if t == 'Assign':
        return pad + ', '.join(ue(x) for x in s[1]) + ' = ' + ', '.join(ue(x) for x in s[2])
    if t == 'CAssign':
        return pad + '%s %s= %s' % (ue(s[2]), s[1], ue(s[3]))
    if t == 'CallStmt':
        return pad + ue(s[1])
    if t == 'Do':
        return pad + 'do\n' + ub(s[1], ind + 1, step) + '\n' + pad + 'end'
    if t == 'While':
        return pad + 'while ' + ue(s[1]) + ' do\n' + ub(s[2], ind + 1, step) + '\n' + pad + 'end'
    if t == 'Repeat':
        return pad + 'repeat\n' + ub(s[1], ind + 1, step) + '\n' + pad + 'until ' + ue(s[2])
    if t == 'If':
        parts = []
        for i, (c, b) in enumerate(s[1]):
            parts.append(pad + ('if ' if i == 0 else 'elseif ') + ue(c) + ' then\n' + ub(b, ind + 1, step))
        if s[2] is not None:
            parts.append(pad + 'else\n' + ub(s[2], ind + 1, step))
        return '\n'.join(parts) + '\n' + pad + 'end'
    if t == 'NumFor':
        r = pad + 'for %s = %s, %s' % (s[1], ue(s[2]), ue(s[3]))
        if s[4] is not None:
            r += ', ' + ue(s[4])
        return r + ' do\n' + ub(s[5], ind + 1, step) + '\n' + pad + 'end'
    if t == 'GenFor':
        return (pad + 'for %s in %s do\n' % (', '.join(s[1]), ', '.join(ue(x) for x in s[2]))
                + ub(s[3], ind + 1, step) + '\n' + pad + 'end')
    if t == 'LocalFunction':
        f = s[2]
        ps = list(f[1]) + (['...'] if f[2] else [])
        return pad + 'local function %s(%s)\n%s\n%send' % (s[1], ', '.join(ps), ub(f[3], ind + 1, step), pad)
    if t == 'FuncStmt':
        f = s[2]
        ps = list(f[1]) + (['...'] if f[2] else [])
        return pad + 'function %s(%s)\n%s\n%send' % (ue(s[1]), ', '.join(ps), ub(f[3], ind + 1, step), pad)
    if t == 'Return':
        return pad + 'return' + (' ' + ', '.join(ue(x) for x in s[1]) if s[1] else '')
    if t == 'Break':
        return pad + 'break'
    if t == 'Continue':
        return pad + 'continue'
    if t == 'Goto':
        return pad + 'goto ' + s[1]
    if t == 'Label':
        return pad + '::' + s[1] + '::'
    raise ValueError('cannot unparse stmt %r' % (t,))
