"""luaq: generic deobfuscation toolkit for Luaq v2.x protected Lua scripts."""

__version__ = "0.1"
