"""Branch exploration by offline replay with forced decisions.

The DRM session of a capture can be replayed deterministically, so each extra
run costs about a second.  A run may invert the first evaluation of selected
pc-moving conditions (``__FORCE``); the union of all runs gives the code on both
sides of the branches that the natural run did not take.
"""
import collections

from . import capture, cfg, trace
from .sweep import _nodes as _cached_nodes


def _cond_nodes(model):
    """Yield (pid, y, j, node, observed_succ_set) for real conditional nodes."""
    for pid, pm in model.protos.items():
        nodes = _cached_nodes(pm)
        for y, nd in nodes.items():
            if nd.kind == 'cond' and nd.j is not None:
                obs = set(pm.edges.get(y % cfg.SEG, {}))
                yield pid, y % cfg.SEG, nd, obs


def missing_outcomes(model):
    """List (key, outcome) where outcome in {'taken','fall'} was never observed."""
    out = []
    for pid, y, nd, obs in _cond_nodes(model):
        if not obs:
            # a condition no replay ever evaluated (decoded by the static sweep only): it becomes a target
            # once a replay reaches it, so that the flips are stacked along the real path to it
            continue
        taken, fall = nd.succ[0], (nd.real_fall if nd.real_fall is not None else nd.succ[1])
        key = '%d:%d:%d' % (pid, y, nd.j)
        if taken not in obs:
            out.append((key, 'taken', pid, y))
        if fall not in obs and taken != fall:
            out.append((key, 'fall', pid, y))
    return out


def _target_known(model, m):
    """0 when the code behind the missing outcome is not decoded yet, 1 when a sweep already decoded it
    (the replay would then only validate it)."""
    key, outcome, pid, y = m
    pm = model.protos.get(pid)
    if pm is None:
        return 0
    cache = model.__dict__.setdefault('_node_cache', {})
    nodes = cache.get(pid)
    if nodes is None:
        nodes = cache[pid] = _cached_nodes(pm)
    nd = nodes.get(y)
    if nd is None or not nd.succ:
        return 0
    tgt = nd.succ[0] if outcome == 'taken' else (nd.real_fall if nd.real_fall is not None else nd.succ[1])
    return 1 if (isinstance(tgt, int) and tgt % cfg.SEG in pm.instrs) else 0


def force_prelude(flips):
    items = ', '.join('["%s"]=%d' % (k, n) for k, n in sorted(flips.items()))
    return '__FORCE = {%s}\n' % items


def _capped_before_exercise(run):
    for ln in run.stdout:
        if ln.startswith('=== CLOSURE EXERCISE'):
            return False
        if 'OPCAP reached' in ln:
            return True
    return False


def sandbox_prelude(keep):
    """Run the replay on dummies: the user protos' registers are inert, global writes are dropped and
    the closures the program creates are decoded by the driver instead of the program's own calls."""
    user = '__SWUSER = {%s}' % ','.join('[%d]=true' % p for p in sorted(keep))
    return (user + chr(10) + '__SWT = {}' + chr(10) + '__SWEEP = true' + chr(10) + '__SWNOREDIR = true' + chr(10)
            + '__OPMAX = 1500000' + chr(10) + '__WALL = 45' + chr(10) + '__SWBUDGET = 30' + chr(10))


def explore(inst_src, workdir, model, log=print, max_runs=40, timeout=40, base_prelude='', budget_secs=150,
            sandbox=False):
    """Grow ``model`` with replays that invert not-yet-seen branch outcomes.  With ``sandbox`` every
    replay (the baseline included) runs on dummies: no program logic executes, so a forced branch is
    never cut short by a runtime error of the mock."""
    done_sets = set()
    queue = collections.deque([{}])       # flip sets still to run (the baseline is already in)
    attempts = 0
    pending = set()
    seen_needs = {}
    # first schedule from the baseline
    base_missing = missing_outcomes(model)
    base_missing.sort(key=lambda m: _target_known(model, m))      # outcomes that lead to undecoded code first
    for key, outcome, pid, y in base_missing:
        fs = {key: 1}
        queue.append(fs)
        seen_needs[(key, outcome)] = fs
    if not sandbox:
        queue.popleft()                   # (a sandbox run starts with its own baseline)
    tried_keys = set()
    import time as _time
    t_start = _time.time()
    while queue and attempts < max_runs:
        if _time.time() - t_start > budget_secs:
            log('  explore: time budget exhausted after %d runs' % attempts)
            break
        fs = queue.popleft()
        sig = tuple(sorted(fs.items()))
        if sig in done_sets:
            continue
        done_sets.add(sig)
        attempts += 1
        before = set((pid, y) for pid, pm in model.protos.items() for y in pm.instrs)
        before_missing = set((k, o) for k, o, _, _ in missing_outcomes(model))
        name = ('sx%d' if sandbox else 'x%d') % attempts
        if sandbox:
            pre = base_prelude + sandbox_prelude(model.keep) + force_prelude(fs)
        else:
            # closures created on the forced path are exercised too (short budget): their bodies get traced
            pre = base_prelude + '__EXERCISE = true' + chr(10) + '__EXBUDGET = 5' + chr(10) + force_prelude(fs)
        out, rc, killed, dt = capture.replay(inst_src, workdir, name, prelude=pre, timeout=timeout)
        run = trace.parse_run(out)
        flipped = sum(1 for ln in run.stdout if ln.startswith('BRFLIP'))
        model.add_run(run)
        after_missing = missing_outcomes(model)
        newnodes = set((pid, y) for pid, pm in model.protos.items() for y in pm.instrs) - before
        model.forced_instrs = getattr(model, 'forced_instrs', 0) + len(newnodes)
        if not hasattr(model, 'origin'):
            model.origin = {}
        for key_ in newnodes:
            model.origin[key_] = tuple(sorted(fs.items()))
        if not hasattr(model, 'flip_runs'):
            model.flip_runs = []
        executed = {(r_['id'], r_['y']) for r_ in run.rows if r_['id'] in model.protos}
        model.flip_runs.append({'name': name, 'flips': dict(fs), 'new': set(newnodes), 'exec': executed,
                                'cut': bool(killed) or _capped_before_exercise(run)})
        log('  explore #%d flips=%s rc=%s flipped=%d rows=%d new_instrs=%d' % (
            attempts, dict(fs), rc, flipped, len(run.rows), len(newnodes)))
        for key, outcome, pid, y in after_missing:
            if (key, outcome) not in seen_needs:
                nfs = dict(fs)
                nfs[key] = 1
                seen_needs[(key, outcome)] = nfs
                queue.append(nfs)
    return attempts



def referenced_consts(pm, only=None):
    ks = set()

    def scan(e):
        if isinstance(e, tuple):
            if len(e) == 2 and e[0] == 'const' and isinstance(e[1], int):
                ks.add(e[1])
            for z in e:
                scan(z)
        elif isinstance(e, list):
            for z in e:
                scan(z)
    for y, ins in pm.instrs.items():
        if only is not None and y not in only:
            continue
        if ins.effects:
            scan(ins.effects)
    return ks


def force_consts(inst_src, workdir, model, log=print, base_prelude='', timeout=60):
    """Decode constants referenced by lifted instructions but never fetched at run time
    (e.g. the body of a loop that ran zero times).  The decode has to happen in a run where the
    proto exists, so the constants are grouped by the run that discovered their instructions
    (the natural run, a forced-branch replay or the closure exercise) and each group is
    requested in a replay with the same settings."""
    origin = getattr(model, 'origin', {})
    groups = {}
    for sig, pm in model.protos.items():
        if not pm.const_field:
            continue
        by_origin = collections.defaultdict(set)
        for y, ins in pm.instrs.items():
            by_origin[origin.get((sig, y), ())].add(y)
        for org, ys in by_origin.items():
            miss = sorted(k for k in referenced_consts(pm, ys) if str(k) not in pm.consts)
            if miss:
                groups.setdefault(org, {})[sig] = (pm.const_field, miss)
    total = 0
    runs = 0
    for gi, (org, want) in enumerate(sorted(groups.items(), key=lambda kv: str(kv[0]))):
        if gi >= 8:
            break
        items = []
        for sig, (field, ks) in want.items():
            items.append('[%d]={field="%s",%s}' % (sig, field, ','.join(str(k) for k in ks)))
            total += len(ks)
        prelude = base_prelude
        if org == 'exercise':
            prelude += '__EXERCISE = true' + chr(10)
        elif org:
            prelude += force_prelude(dict(org))
        prelude += '__WANTC = {%s}' % ','.join(items) + chr(10)
        out, rc, killed, dt = capture.replay(inst_src, workdir, 'xc%d' % gi if gi else 'xc', prelude=prelude, timeout=timeout)
        run = trace.parse_run(out)
        model.add_run(run)
        runs += 1
    if not runs:
        return 0
    left = 0
    for org, want in groups.items():
        for sig, (f, ks) in want.items():
            left += sum(1 for k in ks if str(k) not in model.protos[sig].consts)
    log('  force-consts: %d constants requested in %d run(s), %d still unknown (nil or never decodable)' % (total, runs, left))
    return runs


def exercise_closures(inst_src, workdir, model, log=print, base_prelude='', timeout=90):
    """Run every user closure that the program created but never called once, with a mock
    argument, so that its body is traced.  Returns the number of newly traced instructions."""
    before = set((pid, y) for pid, pm in model.protos.items() for y in pm.instrs)
    out, rc, killed, dt = capture.replay(inst_src, workdir, 'xe', prelude=base_prelude + '__EXERCISE = true' + chr(10),
                                         timeout=timeout)
    run = trace.parse_run(out)
    model.add_run(run)
    new = set((pid, y) for pid, pm in model.protos.items() for y in pm.instrs) - before
    model.exercised_instrs = getattr(model, 'exercised_instrs', 0) + len(new)
    if not hasattr(model, 'origin'):
        model.origin = {}
    for key_ in new:
        model.origin[key_] = 'exercise'
    ncl = sum(1 for ln in run.stdout if ln.startswith('--- CLOSURE') and ' done ' not in ln)
    log('  exercise: %d closure(s) called, %d new instruction(s), rc=%s killed=%s' % (ncl, len(new), rc, killed))
    return len(new)
