"""Make a goto-using (Lua 5.4 executor) Luaq sample loadable by Luau.

Luau has no goto.  The generated loaders only use the forward ``goto D`` ... ``::D::``
idiom where the label closes the innermost loop body, i.e. a ``continue``.  Every goto
is verified against that shape using the AST; if any goto does not fit, nothing is
rewritten and ``GotoError`` is raised (no silent miscompilation).
"""
from . import luaparse as lp


class GotoError(Exception):
    pass


def goto_to_continue(src):
    ast, offs = lp.parse(src, True)
    edits = []          # (start, end, replacement)
    problems = []

    def span(st):
        a, b = st[-1]
        return offs[a][0], offs[b - 1][1]

    def visit(block, loop_body):
        for i, st in enumerate(block):
            t = st[0]
            if t == 'Goto':
                if loop_body is None:
                    problems.append('goto %s outside a loop' % st[1])
                    continue
                if i != len(block) - 1:
                    problems.append('goto %s is not the last statement of its block' % st[1])
                    continue
                # label must close the innermost loop body
                idx = None
                for j, x in enumerate(loop_body):
                    if x[0] == 'Label' and x[1] == st[1]:
                        idx = j
                if idx is None or any(x[0] != 'Label' for x in loop_body[idx:]):
                    problems.append('label %s does not close the innermost loop' % st[1])
                    continue
                a, b = span(st)
                edits.append((a, b, 'continue'))
            elif t == 'Label':
                a, b = span(st)
                # swallow one directly following ';' (Luau rejects empty statements)
                if src[b:b + 1] == ';':
                    b += 1
                edits.append((a, b, ''))
            elif t in ('While',):
                visit(st[2], st[2])
            elif t == 'NumFor':
                visit(st[5], st[5])
            elif t == 'GenFor':
                visit(st[3], st[3])
            elif t == 'Repeat':
                visit(st[1], st[1])
            elif t == 'Do':
                visit(st[1], loop_body)
            elif t == 'If':
                for _, b in st[1]:
                    visit(b, loop_body)
                if st[2] is not None:
                    visit(st[2], loop_body)
            elif t in ('LocalFunction',):
                visit(st[2][3], None)
            elif t == 'FuncStmt':
                visit(st[2][3], None)

    visit(ast, None)
    funcs = []
    lp.walk(ast, lambda n: funcs.append(n) if n[0] == 'Function' else None)
    seen = set()
    for f in funcs:
        if id(f[3]) in seen:
            continue
        seen.add(id(f[3]))
        visit(f[3], None)
    if problems:
        raise GotoError('; '.join(sorted(set(problems))[:5]))
    # de-duplicate (functions reachable both from statements and from the walk)
    uniq = sorted(set(edits))
    out = []
    pos = 0
    for a, b, rep in uniq:
        if a < pos:
            continue
        out.append(src[pos:a])
        out.append(rep)
        pos = b
    out.append(src[pos:])
    return ''.join(out), len(uniq)
