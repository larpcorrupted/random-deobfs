"""Parse the text log produced by a captured run into structured data."""
import io
import json
import re

TR_RE = re.compile(r'^TR (\d+) id=(\S+) inv=(\S+) y=(\S+) M=(\S+) g=(\S+) A=(.*)$')


class Run:
    def __init__(self):
        self.rows = []          # exec/step rows: dicts n,id,inv,y,M,g,A
        self.protos = {}        # id -> parsed proto json
        self.first_seen = {}    # id -> op counter at first sight
        self.open_at = None     # op counter when the DRM open request was posted
        self.env = []           # (opn, line) ENV event lines (optional)
        self.stdout = []        # misc non-structured lines
        self.done = False
        self.sweep = False      # a static sweep run: consecutive rows are not control-flow edges
        self.sweep_pc = []      # (proto, pc, assigned absolute pc) reported by a sweep run
        self.cl_new = {}        # closure number -> (creator proto, creator pc, trace row counter)
        self.cl_enter = {}      # closure number -> trace row counter at its first call
        self.cfetch = set()     # (proto id, constant index) fetched by an executed instruction
        self.cl_child_seen = set()   # closures whose wrapper decoded a child (its id may never show up: no row)
        self.cl_child = {}      # closure number -> proto id of the child it decoded (exact)
        self.cl_index = {}      # closure number -> index of the child proto it runs inside its creator
        self.index_links = []   # (creator proto, child index, callee proto) filled by closure_links

    def closure_links(self, skip=None):
        """[(creator proto, creator pc, ordinal, callee proto)]: the callee is the proto of the first trace
        row after the closure's first call; the ordinal is the closure's rank among the closures created
        by the same execution of the creating instruction (a fused instruction may create several)."""
        import bisect
        ns = [r['n'] for r in self.rows]
        groups = {}
        links = []
        linked = set()
        idx_linked = set()
        self.index_links = []
        for k, (cp, cy, n0) in sorted(self.cl_new.items()):      # creation order
            ordinal = groups.get((cp, cy, n0), 0)
            groups[(cp, cy, n0)] = ordinal + 1
            en = self.cl_enter.get(k)
            idx = self.cl_index.get(k)
            need_site = (cp, cy, ordinal) not in linked
            need_idx = idx is not None and (cp, idx) not in idx_linked
            exact = self.cl_child.get(k)
            if exact is not None and (need_site or need_idx):
                links.append((cp, cy, ordinal, exact))
                linked.add((cp, cy, ordinal))
                if idx is not None:
                    idx_linked.add((cp, idx))
                    self.index_links.append((cp, idx, exact))
                continue
            if k in self.cl_child_seen:      # decoded a child that never ran: positions after it belong to other closures
                continue
            if en is None or not (need_site or need_idx):     # (a site that creates thousands of closures needs one link)
                continue
            i = bisect.bisect_right(ns, en)
            # VM-internal protos (anti-tamper stubs) may run first on entry: the body is the first
            # row of a proto that is neither the creator nor internal
            for j in range(i, min(i + 3000, len(self.rows))):
                pid = self.rows[j]['id']
                if pid is None or pid == cp or (skip is not None and skip(pid)):
                    continue
                links.append((cp, cy, ordinal, pid))
                linked.add((cp, cy, ordinal))
                if idx is not None:
                    idx_linked.add((cp, idx))
                    self.index_links.append((cp, idx, pid))
                break
        return links


def _num(x):
    try:
        return int(x)
    except ValueError:
        try:
            return float(x)
        except ValueError:
            return None


def parse_run(path):
    run = Run()
    seen_rows = set()
    with io.open(path, encoding='utf-8', errors='replace') as fh:
        for ln in fh:
            ln = ln.rstrip('\n')
            if ln.startswith('TR '):
                m = TR_RE.match(ln)
                if not m:
                    continue
                # a run cut by the op cap dumps its trace twice (at the cap and at the end)
                rn = int(m.group(1))
                if rn in seen_rows:
                    continue
                seen_rows.add(rn)
                try:
                    A = json.loads(m.group(7))
                except ValueError:
                    A = None
                run.rows.append(dict(
                    n=int(m.group(1)),
                    id=None if m.group(2) == 'nil' else int(m.group(2)),
                    inv=None if m.group(3) == 'nil' else int(m.group(3)),
                    y=_num(m.group(4)), M=_num(m.group(5)), g=_num(m.group(6)), A=A))
            elif ln.startswith('PROTOJSON id='):
                m = re.match(r'PROTOJSON id=(\d+) (\{.*\})$', ln)
                if m:
                    try:
                        run.protos[int(m.group(1))] = json.loads(m.group(2))
                    except ValueError:
                        pass
            elif ln.startswith('=== FIRST-SEEN PROTO'):
                m = re.search(r'id=(\d+) at=(\d+)', ln)
                if m:
                    run.first_seen[int(m.group(1))] = int(m.group(2))
            elif ln.startswith('MARK open'):
                m = re.search(r'at=(\d+)', ln)
                if m:
                    run.open_at = int(m.group(1))
            elif ln.startswith('SWEEPPROTO ') or ln.startswith('SWEEP FINISHED'):
                run.sweep = True
            elif ln.startswith('SWEEPPC '):
                parts = ln.split()
                try:
                    run.sweep_pc.append((int(parts[1]), int(parts[2]), int(float(parts[3]))))
                except (ValueError, IndexError):
                    pass
            elif ln.startswith('CFETCH '):
                parts = ln.split()
                try:
                    run.cfetch.add((int(parts[1]), int(float(parts[2]))))
                except (ValueError, IndexError):
                    pass
            elif ln.startswith('CLNEW '):
                parts = ln.split()
                try:
                    run.cl_new[int(parts[1])] = (int(parts[2]), int(parts[3]), int(parts[4]))
                    if len(parts) > 5 and parts[5] != 'nil':
                        run.cl_index[int(parts[1])] = int(float(parts[5]))
                except (ValueError, IndexError):
                    pass
            elif ln.startswith('CLCHILD '):
                parts = ln.split()
                try:
                    if parts[2] == '-':
                        run.cl_child_seen.add(int(parts[1]))
                    else:
                        run.cl_child.setdefault(int(parts[1]), int(parts[2]))
                except (ValueError, IndexError):
                    pass
            elif ln.startswith('CLENTER '):
                parts = ln.split()
                try:
                    run.cl_enter.setdefault(int(parts[1]), int(parts[2]))
                except (ValueError, IndexError):
                    pass
            elif ln.startswith('SAMPLE DONE'):
                run.done = True
            elif ln.startswith('ENV'):
                run.env.append(ln)
            else:
                run.stdout.append(ln)
    return run


def _is_proto_like(d):
    return isinstance(d, dict) and len(d) >= 12


def _printable(sv):
    return all(32 <= ord(c) < 127 or c in '\n\t' for c in sv)


def proto_fields(p):
    """Role detection by data shape (field names are renamed per sample).

    Returns dict(consts=<name>, children=<name>) where available.  The constant
    pool is the digit-keyed field whose values are mostly numbers/booleans or
    printable strings (the other digit-keyed string fields hold encrypted blobs).
    """
    roles = {}
    best = None
    for k, v in p.items():
        if not (isinstance(v, (dict, list)) and v):
            continue
        vals = list(v.values()) if isinstance(v, dict) else v
        keys = list(v.keys()) if isinstance(v, dict) else list(range(1, len(v) + 1))
        if not all(str(k_).isdigit() for k_ in keys):
            continue
        scal = [x for x in vals if isinstance(x, (str, int, float, bool)) or x is None]
        if len(scal) < 0.7 * len(vals):
            continue
        nstr = sum(1 for x in scal if isinstance(x, str))
        if nstr == 0 and not any(isinstance(x, (int, float)) and not isinstance(x, bool) for x in scal):
            continue
        good = sum(1 for x in scal if not isinstance(x, str) or _printable(x))
        if good < 0.5 * len(scal):
            continue
        # a pool of decode flags (`true`, 'nil' placeholders) carries no constants
        info = sum(1 for x in scal if (isinstance(x, str) and x != 'nil')
                   or (isinstance(x, (int, float)) and not isinstance(x, bool)))
        if info == 0:
            continue
        vals = scal
        cand = (info, len(vals), k)
        if best is None or cand[:2] > best[:2]:
            best = cand
    if best:
        roles['consts'] = best[2]
    for k, v in p.items():
        if isinstance(v, list) and v and all(_is_proto_like(x) for x in v):
            roles['children'] = k
        elif isinstance(v, dict) and v and all(str(kk).isdigit() for kk in v)                 and all(_is_proto_like(x) for x in v.values()):
            roles['children'] = k
    return roles


def _int_list(v):
    """The values of a 1..n ordered list/dict of distinct positive integers, else None."""
    if isinstance(v, dict):
        try:
            keys = sorted(int(k) for k in v)
        except ValueError:
            return None
        if keys != list(range(1, len(keys) + 1)):
            return None
        vals = [v[str(k)] for k in keys]
    elif isinstance(v, list):
        vals = v
    else:
        return None
    if not all(isinstance(x, int) and not isinstance(x, bool) and x > 0 for x in vals):
        return None
    if len(set(vals)) != len(vals):
        return None
    return list(vals)


def guess_param_field(protos):
    """Data-shape fallback: the one field that is an (often empty) list of distinct
    register numbers in every proto and non-empty in at least one."""
    names = set()
    for d in protos.values():
        names |= set(d)
    best = None
    for k in names:
        nonempty = 0
        ok = True
        for d in protos.values():
            if k not in d:
                continue
            v = d[k]
            if isinstance(v, (list, dict)) and not v:
                continue
            if _int_list(v) is None:
                ok = False
                break
            nonempty += 1
        if ok and nonempty and (best is None or nonempty > best[0]):
            best = (nonempty, k)
    return best[1] if best else None


def param_regs(data, field):
    """Ordered parameter registers of a proto dict, or None if unknown."""
    if not field or field not in data:
        return None
    v = data[field]
    if isinstance(v, (list, dict)) and not v:
        return []
    return _int_list(v)


def children_of(data, roles=None):
    """Child proto dicts in closure-index order (1-based index -> position-1)."""
    roles = roles or proto_fields(data)
    cf = roles.get('children')
    if not cf:
        return []
    v = data[cf]
    if isinstance(v, list):
        return list(v)
    n = max(int(k) for k in v)
    return [v.get(str(i)) for i in range(1, n + 1)]
