"""Control-flow graph construction from interpreted VM instructions.

Luaq scatters the instruction blocks of a function across the pc space and
connects them with explicit (hash-guarded) jumps, so layout order carries no
information; only edges do.  Each executed instruction becomes a node; pure
jump nodes and opaque predicates are contracted away.
"""
import collections

from . import symexec


def _depends_on_state(e):
    """Does expression e depend on registers / call results / memory?"""
    t = e[0]
    if t in ('reg', 'callres', 'rres', 'glob', 'upv', 'idx', 'const_dyn', 'vararg', 'upvslot', 'pack', 'nth', 'packn', 'mnth'):
        return True
    if t in ('bin',):
        return _depends_on_state(e[2]) or _depends_on_state(e[3])
    if t == 'un':
        return _depends_on_state(e[2])
    if t == 'tbl':
        return any(_depends_on_state(x) for x in e[1])
    return False


def _is_kill_call(ef):
    """The integrity-failure branch: a call through a free variable's method."""
    if ef[0] != 'call':
        return False
    c = ef[1]
    return c[0] == 'idx' and c[1][0] == 'free'


SPLIT_WEAK = {}
SPLIT_TOTAL = {}


class Exit:
    """One way out of an instruction."""
    __slots__ = ('guards', 'kind', 'val', 'j')

    def __init__(self, guards, kind, val, j=None):
        self.guards = guards      # list of (cond_expr, polarity)
        self.kind = kind          # 'rel' | 'abs' | 'ret' | 'fall'
        self.val = val
        self.j = j                # ordinal of the __BR-wrapped condition


def split_effects(effects):
    """Return (ops, defs, exits, opaque) for one instruction.

    ops   : ordered side-effect ops (call/setidx/setglob/setupv)
    defs  : {reg: expr} final register definitions (straight-line part)
    exits : list of Exit
    """
    ops = []
    defs = {}
    weak = {}
    exits = []
    opaque_conds = []

    def walk(effs, guards, pcrel):
        # returns True if control definitely leaves (ret / jmp)
        for e in effs:
            t = e[0]
            if t == 'set':
                if not guards:
                    defs[e[1]] = e[2]
                else:
                    ops.append(('condset', list(guards), e[1], e[2]))
            elif t in ('call', 'setidx', 'setglob', 'setupv', 'read', 'settail'):
                if guards:
                    ops.append(('cond', list(guards), e))
                else:
                    ops.append(e)
            elif t == 'forin':
                sub_ops, sub_defs, _x, _y = split_effects(e[3])
                ops.append(('forin', e[1], e[2], e[4], sub_ops, sub_defs))
            elif t == 'whileloop':
                sub_ops, sub_defs, _x, _y = split_effects(e[2])
                ops.append(('whileloop', e[1], e[3], sub_ops, sub_defs))
            elif t == 'setmulti':
                if not guards:
                    defs[e[1]] = ('mnth', e[2], 1)
                    for i in range(1, 16):
                        # the number of spread values is only known at run time: the extra
                        # registers are 'weak' defs, promoted later only where they cannot
                        # clobber a live older value
                        weak[e[1] + i] = ('mnth', e[2], i + 1)
            elif t == 'ret':
                exits.append(Exit(list(guards), 'ret', e[1]))
                return True
            elif t == 'pc':
                v = e[1]
                if v[0] == 'self':
                    exits.append(Exit(list(guards), 'self', None))     # the fused loop runs again
                    return True
                if v[0] == 'rel':
                    pcrel[0] += v[1]
                    # a leading advance is not a jump; remember it
                    pcrel[1] = True
                else:
                    # absolute pc assignment: the instruction may keep executing effects
                    # (e.g. a fused loop) before control actually leaves
                    exits.append(Exit(list(guards), 'abs', v))
            elif t == 'if':
                cond, th, el = e[1], e[2], e[3]
                jj = e[4] if len(e) > 4 else None
                # tamper check: then-branch only calls a kill function
                if th and all(_is_kill_call(x) or x[0] in ('set',) for x in th) and not el:
                    continue
                saved = pcrel[0]
                nex = len(exits)
                a = walk(th, guards + [(cond, True)], pcrel)
                pa = pcrel[0]
                pcrel[0] = saved
                b = walk(el, guards + [(cond, False)], pcrel) if el else False
                pb = pcrel[0]
                for ex_ in exits[nex:]:
                    if ex_.kind == 'abs' and ex_.j is None:
                        ex_.j = jj       # the branch hook that decides this conditional exit
                # if a branch changed pc (relative jump), record exits there
                if pa != saved:
                    exits.append(Exit(guards + [(cond, True)], 'rel', pa, jj))
                if el and pb != saved:
                    exits.append(Exit(guards + [(cond, False)], 'rel', pb, jj))
                if pa != saved or pb != saved:
                    # remaining (non-jumping) outcome falls through at saved pc
                    pass
                pcrel[0] = saved
                if a and b:
                    return True
            elif t == 'ret-in-if':
                return True
        return False

    pcrel = [0, False]
    base_adv = None
    # leading advance
    for e in effects:
        if e[0] == 'pc' and e[1][0] == 'rel':
            base_adv = e[1][1]
        break
    walk(effects, [], pcrel)
    defs.__dict__ if False else None
    SPLIT_WEAK[id(defs)] = weak
    SPLIT_TOTAL[id(defs)] = pcrel[0]      # all unconditional relative advances of the instruction
    return ops, defs, exits, base_adv


SEG = 1000000          # node-id offset of the follow-up segments of a split instruction


def _split_on_exit(effects):
    """A fused instruction whose last effect is `if C then <jump to constant pc> else <more
    micro-ops> end` is two nodes: the part up to the conditional exit and the rest.
    Returns (pre, cond, then_effects, else_effects, branch_id) or None."""
    if not effects:
        return None
    last = effects[-1]
    if last[0] != 'if':
        return None
    th, el = last[2], last[3]
    if not el or not th:
        return None
    if not any(x[0] == 'pc' and x[1][0] == 'num' for x in th):
        return None
    return effects[:-1], last[1], th, el, (last[4] if len(last) > 4 else None)


class Node:
    __slots__ = ('y', 'ops', 'defs', 'exits', 'adv', 'succ', 'cond', 'kind', 'err', 'ins', 'j', 'loopdefs', 'weak',
                 'real_fall', 'seg_next', 'seg_fall', 'total_adv')

    def __init__(self, y):
        self.y = y
        self.ops = []
        self.defs = {}
        self.exits = []
        self.adv = 0
        self.succ = []       # list of y (ordered: [taken, fall] for cond)
        self.cond = None     # (cond_expr, taken_polarity) for 2-way nodes
        self.kind = 'plain'
        self.err = None
        self.ins = None
        self.j = None
        self.loopdefs = set()
        self.weak = {}
        self.real_fall = None   # pc reached when the (split) instruction does not exit early
        self.seg_next = None    # id of the follow-up segment of a split instruction
        self.seg_fall = None    # fall-through pc of the last segment of a split instruction
        self.total_adv = None   # sum of the unconditional relative pc advances of the instruction


def build_nodes(pm):
    """Create Nodes for a ProtoModel (instrs, edges observed)."""
    nodes = {}
    for y, ins in pm.instrs.items():
        n = Node(y)
        n.ins = ins
        if ins.effects is None:
            n.err = ins.err or 'uninterpreted'
            n.kind = 'broken'
            nodes[y] = n
            continue
        segs = []
        seg = ins.effects
        while True:
            sp = _split_on_exit(seg)
            if sp is None:
                break
            pre, cond, th, el, jj = sp
            segs.append(pre + [('if', cond, th, [], jj)])
            seg = el
        segs.append(seg)
        adv0 = None
        for si, seg_e in enumerate(segs):
            nn = n if si == 0 else Node(y + si * SEG)
            if si:
                nn.ins = ins
            ops, defs, exits, adv = split_effects(seg_e)
            nn.ops, nn.defs, nn.exits = ops, defs, exits
            nn.weak = SPLIT_WEAK.pop(id(defs), {})
            nn.total_adv = SPLIT_TOTAL.pop(id(defs), None)
            for op in ops:
                if op[0] == 'forin':
                    nn.loopdefs |= set(op[5])
                elif op[0] == 'whileloop':
                    nn.loopdefs |= set(op[4])
            nn.adv = adv or 0
            if si == 0:
                adv0 = nn.adv
            if si + 1 < len(segs):
                nn.seg_next = y + (si + 1) * SEG
            nodes[y + si * SEG] = nn
        if len(segs) > 1:
            fall0 = y + adv0 + 1
            for si in range(len(segs)):
                nodes[y + si * SEG].seg_fall = fall0
    # successors & kinds
    for y, n in nodes.items():
        y0 = y % SEG                   # instruction this node belongs to
        if n.kind == 'broken':
            n.succ = list(pm.edges.get(y0, {}))
            continue
        fall = y + n.adv + 1
        if n.seg_fall is not None:
            fall = n.seg_fall
        rets = [e for e in n.exits if e.kind == 'ret']
        abss = [e for e in n.exits if e.kind == 'abs']
        rels = [e for e in n.exits if e.kind == 'rel']
        selfs = [e for e in n.exits if e.kind == 'self' and not e.guards]
        if selfs and not rets and not abss and not rels:
            n.kind = 'jmp'
            n.succ = [y0]             # back to the start of the same (looping) instruction
            continue
        if n.seg_next is not None:
            # conditional early exit of a split instruction: [exit target, rest of the instruction]
            exs = [e for e in abss if e.guards and e.val[0] == 'num']
            if len(exs) == 1:
                cond, pol = exs[0].guards[-1]
                n.kind = 'cond'
                n.j = exs[0].j
                n.cond = (cond, pol)
                n.succ = [int(exs[0].val[1]) + 1, n.seg_next]      # the dispatch loop adds 1 to the assigned pc
                n.real_fall = fall
                continue
        if n.seg_fall is not None and n.seg_next is None:
            taken_targets = set()
            for k_ in range(0, 64):
                nk = nodes.get(y0 + k_ * SEG)
                if nk is None:
                    break
                if nk.succ and nk.seg_next is not None:
                    taken_targets.add(nk.succ[0])
            obs = [t for t in pm.edges.get(y0, {}) if t not in taken_targets]
            n.kind = 'plain'
            n.succ = obs if (obs and fall not in obs) else [fall]
            continue
        if rets and not (abss or rels):
            n.kind = 'ret'
            n.succ = []
            continue
        if abss:
            # unconditional computed jump: successor(s) observed; a constant target needs no observation (the
            # dispatch loop adds 1 to the assigned pc), so a jump the trace never followed still has its edge
            n.kind = 'jmp'
            n.succ = list(pm.edges.get(y, {}))
            if not n.succ and len(abss) == 1 and not abss[0].guards and abss[0].val[0] == 'num'                     and float(abss[0].val[1]).is_integer():
                n.succ = [int(abss[0].val[1]) + 1]
            continue
        if rels:
            # conditional relative jump(s)
            conds = [e for e in rels if e.guards]
            if len(conds) == 1 and len(rels) == 1:
                e = conds[0]
                cond, pol = e.guards[-1]
                tgt = y + e.val + 1
                if not _depends_on_state(cond):
                    # opaque predicate: outcome is deterministic -> use observation
                    obs = list(pm.edges.get(y, {}))
                    n.kind = 'jmp'
                    n.succ = obs if obs else [fall]
                    n.cond = None
                else:
                    n.kind = 'cond'
                    n.j = e.j
                    # taken when cond has polarity `pol`
                    n.cond = (cond, pol)
                    n.succ = [tgt, fall]
                continue
            if len(rels) == 1 and not rels[0].guards:
                n.kind = 'jmp'
                n.succ = [y + rels[0].val + 1]
                continue
            n.kind = 'multi'
            n.succ = sorted({y + e.val + 1 for e in rels} | {fall})
            continue
        # plain instruction (may still contain a leading advance); when the trace shows that
        # control never reached the computed fall-through, the observed successor wins
        n.kind = 'plain'
        if n.total_adv is not None:
            fall = y + n.total_adv + 1
        obs = list(pm.edges.get(y, {}))
        n.succ = obs if (obs and fall not in obs) else [fall]
    import os as _os
    _dbs = _os.environ.get('LUAQ_DBG_SUCC')
    if _dbs:
        for y_, n_ in sorted(nodes.items()):
            if int(_dbs) in (n_.succ or []):
                print('DBGSUCC', getattr(pm, 'sig', ''), y_, n_.kind, n_.succ, n_.adv, n_.total_adv,
                      [(e.kind, e.val, len(e.guards)) for e in n_.exits], dict(pm.edges.get(y_ % SEG, {})),
                      repr(n_.ins.effects)[:600] if n_.ins is not None else None)
    _dbg = _os.environ.get('LUAQ_DBG_NODE')
    if _dbg and str(getattr(pm, 'sig', '')) == _dbg.split(':')[0]:
        for y_, n_ in sorted(nodes.items()):
            if str(y_ % SEG) == _dbg.split(':')[1]:
                print('DBGNODE', y_, n_.kind, n_.succ, n_.adv, n_.total_adv, [(e.kind, e.val) for e in n_.exits],
                      dict(pm.edges.get(y_ % SEG, {})))
    return nodes


def contract(nodes, entry):
    """Remove empty jump nodes (pure jumps / opaque predicates).

    A node is removable if kind == 'jmp' and it has no ops and no defs.
    Returns (nodes, entry) with edges redirected.
    """
    def empty(n):
        return n.kind == 'jmp' and not n.ops and not n.defs and len(n.succ) == 1

    def resolve(y, seen=None):
        seen = seen or set()
        while y in nodes and empty(nodes[y]) and y not in seen:
            seen.add(y)
            y = nodes[y].succ[0]
        return y

    for n in nodes.values():
        n.succ = [resolve(s) for s in n.succ]
    entry = resolve(entry)
    live = set()
    stack = [entry]
    while stack:
        y = stack.pop()
        if y in live or y not in nodes:
            continue
        live.add(y)
        stack.extend(nodes[y].succ)
    return {y: nodes[y] for y in live}, entry
