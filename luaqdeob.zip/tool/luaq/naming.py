"""Heuristic readable names for variables recovered from VM registers."""
import re
import collections

from . import opt
from .emit import is_ident, KEYWORDS

RESERVED = set(KEYWORDS) | {
    'game', 'workspace', 'script', 'math', 'string', 'table', 'os', 'task', 'print', 'warn',
    'error', 'pcall', 'xpcall', 'type', 'typeof', 'tostring', 'tonumber', 'pairs', 'ipairs',
    'next', 'select', 'unpack', 'require', 'wait', 'spawn', 'delay', 'tick', 'time', 'Instance',
    'Enum', 'Vector3', 'Vector2', 'CFrame', 'Color3', 'UDim2', 'UDim', 'Random', 'coroutine',
    'bit32', 'buffer', 'utf8', 'debug', 'getfenv', 'setfenv', 'loadstring', 'rawget', 'rawset',
    'setmetatable', 'getmetatable', 'assert', 'shared', 'plugin', '_G', '_VERSION', 'self',
}


def dl_has_def(defs, v):
    return bool(defs.get(v))


def lower_first(s):
    if not s:
        return s
    # keep acronym prefixes readable: "GUI" -> "gui", "HumanoidRootPart" -> "humanoidRootPart"
    m = re.match(r'^([A-Z]+)([A-Z][a-z].*)$', s)
    if m:
        return m.group(1).lower() + m.group(2)
    return s[0].lower() + s[1:]


def sanitize(s):
    s = re.sub(r'[^A-Za-z0-9_]', '', s)
    if not s:
        return None
    if s[0].isdigit():
        s = '_' + s
    return s


def base_name(expr):
    """Pick a descriptive base name from the defining expression."""
    t = expr[0]
    if t == 'mcall':
        meth = expr[2]
        if meth and meth[0].islower():
            meth = meth[0].upper() + meth[1:]          # deprecated lower-case Roblox API (getChildren, findFirstChild)
        args = expr[3]
        if meth in ('GetService',) and args and args[0][0] == 'lit' and isinstance(args[0][1], str):
            return sanitize(args[0][1]) or 'service'          # Roblox style: local Players = game:GetService("Players")
        if meth in ('WaitForChild', 'FindFirstChild', 'FindFirstDescendant', 'FindFirstAncestor',
                    'FindFirstChildOfClass', 'FindFirstChildWhichIsA', 'GetChildren') and args \
                and args[0][0] == 'lit' and isinstance(args[0][1], str):
            return lower_first(sanitize(args[0][1]) or 'child')
        if meth in ('Clone',):
            return 'clone'
        if meth in ('Connect', 'Once', 'ConnectAsync'):
            return 'connection'
        if meth in ('GetPropertyChangedSignal',):
            return 'signal'
        if meth.startswith('Get') and len(meth) > 3:
            return lower_first(sanitize(meth[3:]) or 'value')
        # UI / helper libraries: Window = Lib:MakeWindow{...}, Tab = Window:CreateTab(...), Toggle = Tab:AddToggle{...}
        m_ = re.match(r'^(Make|Create|Add|New|Build|Init|Load|Spawn|Register|Setup)([A-Z][A-Za-z0-9_]*)$', meth)
        if m_:
            return lower_first(sanitize(m_.group(2)) or 'value')
        if meth in ('Raycast',):
            return 'result'
        if meth in ('JSONDecode',):
            return 'data'
        if meth in ('HttpGet', 'HttpGetAsync'):
            return 'body'
        return None
    if t == 'call':
        f = expr[1]
        # loadstring(game:HttpGet(url))(): a module fetched from the web, named after the url
        if f[0] == 'call' and f[1] == ('glob', 'loadstring') and f[2]:
            a0 = f[2][0]
            url = None
            if a0[0] == 'mcall' and a0[2] in ('HttpGet', 'HttpGetAsync') and a0[3] and a0[3][0][0] == 'lit':
                url = a0[3][0][1]
            if isinstance(url, str):
                low = url.lower()
                if 'lib' in low or 'ui' in re.split(r'[^a-z]+', low) or low.endswith('ui.lua') or 'ui' in low.rsplit('/', 1)[-1]:
                    return 'Library'
                seg = [x for x in re.split(r'[/?#]', url) if x and '.' not in x]
                if seg:
                    return lower_first(sanitize(seg[-1].split('.')[0]) or 'module')
            return 'module'
        if f[0] == 'index' and f[1] == ('glob', 'Instance') and f[2] == ('lit', 'new'):
            a = expr[2]
            if a and a[0][0] == 'lit' and isinstance(a[0][1], str):
                return lower_first(sanitize(a[0][1]) or 'instance')
        if f[0] == 'index' and f[2][0] == 'lit' and f[2][1] == 'new' and f[1][0] == 'glob':
            return lower_first(f[1][1])
        if f[0] == 'glob':
            if f[1] in ('require',):
                return 'module'
            if f[1] in ('Instance',):
                return 'instance'
            return None
        return None
    if t == 'index':
        k = expr[2]
        if k[0] == 'lit' and isinstance(k[1], str) and is_ident(k[1]):
            if k[1] in ('Parent',):
                return 'parent'
            return lower_first(k[1])
        return None
    if t == 'glob':
        return lower_first(expr[1])
    if t == 'bin' and expr[1] in ('or', 'and'):
        # `a.Character or a.CharacterAdded:Wait()` is named like its first operand
        return base_name(expr[2]) or base_name(expr[3])
    if t == 'paren':
        return base_name(expr[1])
    if t == 'func':
        return 'callback'
    if t == 'table':
        return 'tbl'
    if t == 'lit':
        if isinstance(expr[1], str):
            return 'str'
        if isinstance(expr[1], (int, float)) and not isinstance(expr[1], bool):
            return 'num'
        return None
    return None


def _re(e, mapping):
    if not isinstance(e, tuple) or not e:
        return e
    t = e[0]
    if t == 'var':
        return ('var', mapping.get(e[1], e[1]))
    if t == 'index':
        return ('index', _re(e[1], mapping), _re(e[2], mapping))
    if t == 'call':
        return ('call', _re(e[1], mapping), [_re(a, mapping) for a in e[2]])
    if t == 'mcall':
        return ('mcall', _re(e[1], mapping), e[2], [_re(a, mapping) for a in e[3]])
    if t == 'bin':
        return ('bin', e[1], _re(e[2], mapping), _re(e[3], mapping))
    if t == 'un':
        return ('un', e[1], _re(e[2], mapping))
    if t == 'table':
        return ('table', [('kv', _re(i[1], mapping), _re(i[2], mapping)) if i[0] == 'kv' else _re(i, mapping) for i in e[1]])
    if t == 'unpack':
        return ('unpack', _re(e[1], mapping))
    if t == 'paren':
        return ('paren', _re(e[1], mapping))
    if t == 'forin':
        names = [mapping.get(x, x) for x in e[1]]
        while len(names) > 1 and names[-1] == '_' and not (len(e) > 3 and e[3] == 'num'):
            names.pop()                       # `for k, _ in t` -> `for k in t`
        return ('forin', names, [_re(x, mapping) for x in e[2]]) + tuple(e[3:])
    if t == 'func':
        return ('func', [mapping.get(p, p) for p in e[1]], _rename_stmts(e[2], mapping), e[3])
    return e


def _rename_stmts(block, mapping):
    out = []
    for s in block:
        t = s[0]
        if t in ('callres', 'local'):
            out.append((t, mapping.get(s[1], s[1]), _re(s[2], mapping)))
        elif t == 'assign':
            lhs = s[1]
            lhs = ('var', mapping.get(lhs[1], lhs[1])) if lhs[0] == 'var' else _re(lhs, mapping)
            out.append(('assign', lhs, _re(s[2], mapping)))
        elif t == 'callstmt':
            out.append(('callstmt', _re(s[1], mapping)))
        elif t == 'multi':
            out.append(('multi', [mapping.get(n_, n_) for n_ in s[1]], _re(s[2], mapping)))
        elif t == 'if':
            out.append(('if', _re(s[1], mapping), _rename_stmts(s[2], mapping), _rename_stmts(s[3], mapping)))
        elif t == 'while':
            out.append(('while', _re(s[1], mapping), _rename_stmts(s[2], mapping)))
        elif t == 'return':
            out.append(('return', [_re(v, mapping) for v in s[1]]))
        else:
            out.append(s)
    return out


_GENERIC = {'callback', 'tbl', 'num', 'str', 'val', 'tmp', 'value'}

# parameters of the callbacks of well-known Roblox signals (names from the API reference)
SIGNAL_PARAMS = {
    'Heartbeat': ('deltaTime',), 'RenderStepped': ('deltaTime',), 'PreRender': ('deltaTime',),
    'PostSimulation': ('deltaTime',), 'PreSimulation': ('deltaTime',), 'PreAnimation': ('deltaTime',),
    'Stepped': ('time', 'deltaTime'),
    'InputBegan': ('input', 'gameProcessedEvent'), 'InputEnded': ('input', 'gameProcessedEvent'),
    'InputChanged': ('input', 'gameProcessedEvent'), 'TouchStarted': ('touch', 'gameProcessedEvent'),
    'PlayerAdded': ('player',), 'PlayerRemoving': ('player',),
    'CharacterAdded': ('character',), 'CharacterRemoving': ('character',), 'CharacterAppearanceLoaded': ('character',),
    'ChildAdded': ('child',), 'ChildRemoved': ('child',), 'DescendantAdded': ('descendant',),
    'DescendantRemoving': ('descendant',), 'AncestryChanged': ('child', 'parent'),
    'Touched': ('otherPart',), 'TouchEnded': ('otherPart',),
    'FocusLost': ('enterPressed', 'inputThatCausedFocusLoss'), 'Chatted': ('message', 'recipient'),
    'HealthChanged': ('health',), 'StateChanged': ('oldState', 'newState'), 'Running': ('speed',),
    'Triggered': ('playerWhoTriggered',), 'TriggerEnded': ('playerWhoTriggered',),
    'PromptButtonHoldBegan': ('playerWhoTriggered',),
    'Activated': ('inputObject', 'clickCount'), 'MouseButton1Down': ('x', 'y'), 'MouseButton1Up': ('x', 'y'),
    'MouseButton2Down': ('x', 'y'), 'MouseButton2Up': ('x', 'y'), 'MouseEnter': ('x', 'y'), 'MouseLeave': ('x', 'y'),
    'MouseMoved': ('x', 'y'), 'Idled': ('time',), 'OnClientEvent': (), 'OnServerEvent': ('player',),
    'MoveToFinished': ('reached',), 'KeyframeReached': ('keyframeName',), 'Completed': ('playbackState',),
    'Equipped': ('mouse',), 'TextChanged': (), 'MessageReceived': ('textChatMessage',),
}


def _usage_hints(ir):
    """A name for a variable from the first place that gives it a role: `obj.Text = v` -> text,
    `{Title = v}` -> title, `signal.MouseButton1Click:Connect(v)` -> onMouseButton1Click."""
    hints = {}
    fdefs, _u = opt.collect(ir)

    def put(v, name):
        name = sanitize(name or '')
        if name and v not in hints and name not in KEYWORDS:
            hints[v] = name

    def f(e):
        t = e[0]
        if t == 'table':
            for it in e[1]:
                if it[0] == 'kv' and it[1][0] == 'lit' and isinstance(it[1][1], str) and is_ident(it[1][1])                         and it[2][0] == 'var':
                    put(it[2][1], lower_first(it[1][1]))
        elif t == 'mcall' and e[2] in ('Connect', 'Once', 'ConnectParallel') and e[3] and e[3][0][0] == 'var':
            obj = e[1]
            if obj[0] == 'index' and obj[2][0] == 'lit' and isinstance(obj[2][1], str) and is_ident(obj[2][1]):
                put(e[3][0][1], 'on' + obj[2][1])
        if t == 'mcall' and e[2] in ('Connect', 'Once', 'ConnectParallel', 'Wait') and e[3]                 and e[3][0][0] in ('func', 'var'):
            obj = e[1]
            fn = e[3][0]
            if fn[0] == 'var':
                # a local function connected by name: its single definition gives the parameters
                dl = fdefs.get(fn[1], [])
                fn = dl[0][2] if len(dl) == 1 and dl[0][0] in ('local', 'callres', 'assign') and dl[0][2][0] == 'func'                     else None
            if fn is not None and obj[0] == 'index' and obj[2][0] == 'lit' and obj[2][1] in SIGNAL_PARAMS:
                for pv, nm in zip(fn[1], SIGNAL_PARAMS[obj[2][1]]):
                    put(pv, nm)

    def walk(block):
        for st in block:
            if st[0] == 'assign' and st[1][0] == 'index' and st[1][2][0] == 'lit'                     and isinstance(st[1][2][1], str) and is_ident(st[1][2][1]) and st[2][0] == 'var':
                put(st[2][1], lower_first(st[1][2][1]))
            for x in st[1:]:
                if isinstance(x, list) and x and isinstance(x[0], tuple) and isinstance(x[0][0], str)                         and x[0][0] in ('callres', 'local', 'assign', 'callstmt', 'multi', 'if', 'while', 'return',
                                        'break', 'continue', 'comment'):
                    walk(x)
    opt.walk_b(ir, f)
    walk(ir)

    def fwalk(e):
        if e[0] == 'func':
            walk(e[2])
    opt.walk_b(ir, fwalk)
    return hints


def _owners(ir):
    """(owner, parent): the function each variable belongs to (0 = the chunk) and the function tree."""
    owner = {}
    parent = {0: None}
    counter = [0]
    occ = {}

    def dfn(n_, fid):
        owner.setdefault(n_, fid)
        occ.setdefault(n_, set()).add(fid)

    def blk(b, fid):
        for st in b:
            stmt(st, fid)

    def stmt(st, fid):
        t = st[0]
        if t in ('callres', 'local'):
            dfn(st[1], fid)
            expr(st[2], fid)
        elif t == 'assign':
            if st[1][0] == 'var':
                dfn(st[1][1], fid)
            else:
                expr(st[1], fid)
            expr(st[2], fid)
        elif t == 'multi':
            for n_ in st[1]:
                dfn(n_, fid)
            expr(st[2], fid)
        elif t == 'callstmt':
            expr(st[1], fid)
        elif t == 'if':
            expr(st[1], fid)
            blk(st[2], fid)
            blk(st[3], fid)
        elif t == 'while':
            c = st[1]
            if c[0] == 'forin':
                for n_ in c[1]:
                    dfn(n_, fid)
                for x in c[2]:
                    expr(x, fid)
            else:
                expr(c, fid)
            blk(st[2], fid)
        elif t == 'return':
            for x in st[1]:
                expr(x, fid)

    def expr(e, fid):
        if not isinstance(e, tuple) or not e:
            return
        if e[0] == 'var':
            occ.setdefault(e[1], set()).add(fid)
            return
        if e[0] == 'func':
            counter[0] += 1
            nf = counter[0]
            parent[nf] = fid
            for p_ in e[1]:
                if p_ != '...':
                    dfn(p_, nf)
            blk(e[2], nf)
            return
        for x in e[1:]:
            if isinstance(x, tuple):
                expr(x, fid)
            elif isinstance(x, list):
                for y in x:
                    if isinstance(y, tuple):
                        expr(y, fid)
    blk(ir, 0)
    # a variable belongs to the innermost function enclosing every place it occurs (definition or use)
    for nm, fids in occ.items():
        fids = set(fids) | ({owner[nm]} if nm in owner else set())
        chains = []
        for f_ in fids:
            ch = []
            while f_ is not None:
                ch.append(f_)
                f_ = parent.get(f_)
            chains.append(ch[::-1])
        lca = 0
        for i in range(min(len(c) for c in chains)):
            vals = {c[i] for c in chains}
            if len(vals) != 1:
                break
            lca = chains[0][i]
        owner[nm] = lca
    return owner, parent


def rename(ir):
    defs, uses = opt.collect(ir)
    # names used as globals anywhere must not be shadowed
    globs = set()
    opt.walk_b(ir, lambda e: globs.add(e[1]) if e[0] == 'glob' else None)
    forbidden = set(RESERVED) | globs
    owner, parent = _owners(ir)

    def anc(a, b):
        """a is b or one of b's enclosing functions"""
        while b is not None:
            if a == b:
                return True
            b = parent.get(b)
        return False
    used = collections.defaultdict(list)       # name -> owners of the variables already given that name

    def free(name, o):
        if name in forbidden or name in KEYWORDS:
            return False
        # two variables may share a name only when neither one's function encloses the other's (sibling closures)
        return all(not (anc(O, o) or anc(o, O)) for O in used.get(name, ()))
    # variables in definition order (stable)
    order = []
    seen = set()

    forin_kind = {}

    def f(e):
        if e[0] == 'var' and e[1] not in seen:
            seen.add(e[1])
            order.append(e[1])
        elif e[0] == 'forin':
            for k_, nm_ in enumerate(e[1]):
                forin_kind[nm_] = 'i' if (len(e) > 3 and e[3] == 'num') else ('k' if k_ == 0 else 'v')
                if nm_ not in seen:
                    seen.add(nm_)
                    order.append(nm_)
    d_l = []
    opt.walk_b_defs(ir, f, d_l)
    for n, _ in d_l:
        if n not in seen:
            seen.add(n)
            order.append(n)
    hints = _usage_hints(ir)
    mapping = {}
    for v in order:
        if not re.match(r'^(v|c|lv)\d+(_\d+)*$', v):
            forbidden.add(v)
    for v in order:
        if not re.match(r'^(v|c|lv)\d+(_\d+)*$', v):
            continue
        base = forin_kind.get(v)
        if base in ('k', 'v') and uses.get(v, 0) == 0 and not dl_has_def(defs, v):
            mapping[v] = '_'                 # unused generic-for variable
            continue
        dl = defs.get(v, [])
        if dl and base is None:
            # the most telling definition (`local humanoid = nil ... humanoid = char:WaitForChild("Humanoid")`)
            cands_ = [base_name(s_[2]) for s_ in dl if s_[0] in ('local', 'callres', 'assign')]
            good = [b_ for b_ in cands_ if b_ and b_ not in _GENERIC and b_ not in ('num', 'str', 'bool', 'flag')]
            base = good[0] if good else (cands_[0] if cands_ else None)
        if (base is None or base in _GENERIC) and v in hints:
            base = hints[v]
        if base is None:
            base = 'val' if v.startswith('v') else 'tmp'
        base = sanitize(base) or 'v'
        o = owner.get(v, 0)
        name = base
        k = 1
        while not free(name, o):
            k += 1
            name = '%s%d' % (base, k)
        used[name].append(o)
        mapping[v] = name
    return _rename_stmts(ir, mapping)
