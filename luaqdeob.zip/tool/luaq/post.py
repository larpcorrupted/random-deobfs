"""IR clean-up passes and text rendering.

IR statements:
  ('callres', name, expr)   local name = expr  (call result temp)
  ('assign', lhs, expr)     lhs = expr
  ('local', name, expr)     local name = expr
  ('decl', [names])         local a, b
  ('callstmt', expr)
  ('if', cond, then, else)  ('while', cond, body)
  ('return', [exprs])  ('break',)  ('continue',)  ('comment', text)
"""
import collections

from .emit import render_expr, negate


# ----------------------------------------------------------------- utilities
def walk_exprs(e, f):
    """Pre-order traversal over an IR expression."""
    f(e)
    t = e[0]
    if t == 'index':
        walk_exprs(e[1], f); walk_exprs(e[2], f)
    elif t == 'call':
        walk_exprs(e[1], f)
        for a in e[2]:
            walk_exprs(a, f)
    elif t == 'mcall':
        walk_exprs(e[1], f)
        for a in e[3]:
            walk_exprs(a, f)
    elif t == 'bin':
        walk_exprs(e[2], f); walk_exprs(e[3], f)
    elif t == 'un':
        walk_exprs(e[2], f)
    elif t == 'table':
        for it in e[1]:
            walk_exprs(it, f)
    elif t == 'unpack':
        walk_exprs(e[1], f)


def stmt_exprs(s):
    t = s[0]
    if t in ('callres', 'local', 'multi'):
        return [s[2]]
    if t == 'assign':
        return [s[1], s[2]]
    if t == 'callstmt':
        return [s[1]]
    if t == 'if':
        return [s[1]]
    if t == 'while':
        return [s[1]]
    if t == 'return':
        return list(s[1])
    return []


def sub_blocks(s):
    t = s[0]
    if t == 'if':
        return [s[2], s[3]]
    if t == 'while':
        return [s[2]]
    return []


def count_uses(block, counter, extra_exprs=()):
    for s in block:
        t = s[0]
        exprs = stmt_exprs(s)
        if t == 'assign' and s[1][0] == 'var':
            exprs = [s[2]]           # the assignment target is a def, not a use
        for e in exprs:
            walk_exprs(e, lambda x: counter.update([x[1]]) if x[0] == 'var' else None)
        for b in sub_blocks(s):
            count_uses(b, counter)


def is_trivial(e):
    return e[0] in ('lit', 'var', 'glob', 'upv', 'func')


_QUIET_LIBS = {'debug', 'string', 'table', 'math', 'os', 'coroutine', 'utf8', 'bit32', 'buffer', 'task'}


def is_quiet(e):
    """Trivial, or a standard-library member lookup (`debug.info`): evaluating it first or last makes
    no observable difference, so it never blocks moving another expression past it."""
    return is_trivial(e) or (e[0] == 'index' and e[1][0] == 'glob' and e[1][1] in _QUIET_LIBS
                             and e[2][0] == 'lit')


def first_eval_is(e, name):
    """True if `name` is the first non-trivial thing evaluated in expression e."""
    t = e[0]
    if t == 'var':
        return e[1] == name
    if t in ('lit', 'glob', 'upv', 'vararg', 'raw', 'unknown', 'func'):
        return False
    if t == 'index':
        if e[1] == ('var', name):
            return True
        if is_trivial(e[1]):
            return first_eval_is(e[2], name)
        return first_eval_is(e[1], name)
    if t == 'call':
        if e[1] == ('var', name):
            return True
        if is_quiet(e[1]):
            for a in e[2]:
                if first_eval_is(a, name):
                    return True
                if not is_trivial(a):
                    return False
            return False
        return first_eval_is(e[1], name)
    if t == 'mcall':
        if e[1] == ('var', name):
            return True
        if not is_trivial(e[1]):
            return first_eval_is(e[1], name)
        for a in e[3]:
            if first_eval_is(a, name):
                return True
            if not is_trivial(a):
                return False
        return False
    if t == 'bin':
        if first_eval_is(e[2], name):
            return True
        if is_trivial(e[2]) and e[1] not in ('and', 'or'):
            return first_eval_is(e[3], name)       # `a ~= x`: nothing observable happens before x
        return False
    if t == 'un':
        return first_eval_is(e[2], name)
    if t == 'table':
        for it in e[1]:
            parts = [it[1], it[2]] if it[0] == 'kv' else [it]
            for part in parts:
                if first_eval_is(part, name):
                    return True
                if not is_trivial(part):
                    return False
        return False
    if t in ('unpack', 'paren'):
        return first_eval_is(e[1], name)
    return False


def replace_var(e, name, repl):
    if e == ('var', name):
        return repl
    if isinstance(e, tuple) and e and isinstance(e[0], str):
        return tuple(replace_var(x, name, repl) if isinstance(x, tuple) else
                     ([replace_var(y, name, repl) if isinstance(y, tuple) else y for y in x]
                      if isinstance(x, list) else x) for x in e)
    return e


def has_call(e):
    found = []
    walk_exprs(e, lambda x: found.append(1) if x[0] in ('call', 'mcall') else None)
    return bool(found)


# -------------------------------------------------------------- temp inlining
def inline_temps(block, uses):
    out = []
    i = 0
    stmts = list(block)
    n = len(stmts)
    res = []
    for idx, s in enumerate(stmts):
        res.append(s)
    # recursive on sub-blocks first
    for k, s in enumerate(res):
        t = s[0]
        if t == 'if':
            res[k] = ('if', s[1], inline_temps(s[2], uses), inline_temps(s[3], uses))
        elif t == 'while':
            res[k] = ('while', s[1], inline_temps(s[2], uses))
    # now linear inlining
    changed = True
    while changed:
        changed = False
        for k, s in enumerate(res):
            if s[0] != 'callres':
                continue
            name, expr = s[1], s[2]
            u = uses.get(name, 0)
            if u == 0:
                if expr[0] in ('call', 'mcall'):
                    res[k] = ('callstmt', expr)
                else:
                    res[k] = ('comment', 'dead: ' + render_expr(expr))
                changed = True
                break
            if u == 1:
                # find next statement using the var; allow pure assigns in between
                j = k + 1
                while j < len(res):
                    sj = res[j]
                    uses_here = []
                    for e in stmt_exprs(sj):
                        walk_exprs(e, lambda x: uses_here.append(1) if x == ('var', name) else None)
                    if uses_here:
                        break
                    if sj[0] == 'assign' and sj[1][0] == 'var' and not has_call(sj[2]):
                        j += 1
                        continue
                    j = len(res)
                    break
                if j < len(res):
                    sj = res[j]
                    ok = False
                    if sj[0] in ('assign', 'local', 'callres'):
                        lhs_use = sj[0] == 'assign' and sj[1][0] != 'var'
                        rhs = sj[2]
                        if lhs_use:
                            ok = False
                            if first_eval_is(sj[1], name) or (is_trivial(sj[1]) and first_eval_is(rhs, name)):
                                ok = True
                        else:
                            ok = first_eval_is(rhs, name)
                        if ok:
                            if sj[0] == 'assign' and lhs_use:
                                res[j] = ('assign', replace_var(sj[1], name, expr), replace_var(sj[2], name, expr))
                            else:
                                res[j] = (sj[0], sj[1], replace_var(sj[2], name, expr)) if sj[0] != 'assign' else ('assign', sj[1], replace_var(sj[2], name, expr))
                    elif sj[0] in ('callstmt',):
                        ok = first_eval_is(sj[1], name)
                        if ok:
                            res[j] = ('callstmt', replace_var(sj[1], name, expr))
                    elif sj[0] == 'if':
                        ok = first_eval_is(sj[1], name)
                        if ok:
                            res[j] = ('if', replace_var(sj[1], name, expr), sj[2], sj[3])
                    elif sj[0] == 'return':
                        vals = sj[1]
                        ok = False
                        for v in vals:
                            if first_eval_is(v, name):
                                ok = True
                                break
                            if not is_trivial(v):
                                break
                        if ok:
                            res[j] = ('return', [replace_var(v, name, expr) for v in vals])
                    if ok:
                        del res[k]
                        changed = True
                        break
    return res
