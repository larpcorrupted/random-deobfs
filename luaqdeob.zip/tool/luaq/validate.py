"""Validation of a deobfuscated source.

1. syntax:       luau-compile must accept it;
2. residue:      no VM wrapper / encrypted payload markers left;
3. differential: original (VM, replayed session) and deobfuscated source run in the
   same mock; the user program's observable events (calls, property writes and reads,
   global accesses, arithmetic/string library calls) must match in order.
"""
import io
import os
import re
import subprocess

from . import capture, trace

RESIDUE = (re.compile(r'LUAQ'), re.compile(r'setmetatable\(\{[A-Za-z]=function'),
           re.compile(r'getfenv\(\)\s*or\s*_ENV'), re.compile(r'__metatable\s*=\s*false'))

# global names the VM / harness itself touches; not part of the user program
NOISE_G = {
    'setmetatable', 'getfenv', 'type', 'string', 'coroutine', 'bit32', 'tostring', 'table',
    'math', 'error', 'tonumber', 'pairs', 'pcall', 'rawequal', 'getmetatable', 'select', 'next',
    'setfenv', 'unpack', 'rawget', 'os', 'task', 'xpcall', 'buffer', 'debug', 'ipairs', 'utf8',
    '__OPANY', '__BR', '__BRF', 'typeof', 'request', 'http_request', 'http', 'require', 'loadstring',
    'load', '_G', '_ENV', 'rawset', 'assert', 'cloneref',
    'crypt',      # (Luaq 2.5) the VM verifies its instruction stream with the executor hash library
}


def compile_ok(src_text, workdir):
    p = os.path.join(workdir, 'check.lua')
    io.open(p, 'w', encoding='utf-8', newline='\n').write(src_text)
    exe = capture.find_luau('luau-compile')
    r = subprocess.run([exe, '--binary', p], capture_output=True)
    return r.returncode == 0, (r.stderr or b'').decode('utf-8', 'replace').strip()[:300]


def residue(src_text):
    return [r.pattern for r in RESIDUE if r.search(src_text)]


def run_plain(src_text, workdir, name='plain', timeout=45, prelude=''):
    # (the program's code runs from the start: virtual wall-clock time, like the VM run after its loader)
    h = capture.build_harness(src_text, False, extra_prelude='__VTIME_ON = true' + chr(10) + prelude)
    p = os.path.join(workdir, name + '.lua')
    io.open(p, 'w', encoding='utf-8', newline='').write(h)
    out = os.path.join(workdir, name + '.txt')
    rc, killed, dt = capture.run_luau(p, out, timeout=timeout)
    return out, rc, killed


_TAG = re.compile(r'^ENV(?:#(\d+))? (.*)$')


def events(path, pids=None):
    """Normalised event list.  With ``pids`` only events tagged with those protos
    (user code of the original VM run) are kept; without, untagged events."""
    ev = []
    with io.open(path, encoding='utf-8', errors='replace') as fh:
        for ln in fh:
            if ln.startswith('=== CLOSURE EXERCISE'):
                break                # synthetic calls of never-called closures: not part of the run
            if ln.startswith('OPCAP reached'):
                # the harness aborts a non-terminating original here: whatever the VM logs afterwards
                # (swallowed aborts, callbacks failing at once) is an artefact of the cap
                break
            if not ln.startswith('ENV'):
                continue
            m = _TAG.match(ln.rstrip('\n'))
            if not m:
                continue
            tag, body = m.group(1), m.group(2)
            if pids is not None:
                if tag is None or int(tag) not in pids:
                    continue
            else:
                if tag is not None:
                    continue
            if body.startswith('A '):
                continue              # library arithmetic log: dominated by VM-internal decoding
            if body.startswith('G '):
                if body[2:] in NOISE_G:
                    continue
            ev.append(body)
    return _drop_method_lookups(ev)


def _drop_method_lookups(ev):
    """`R Obj.Method` followed (before long) by `C Obj.Method(...)` is the lookup of a method that is then called.
    Lua 5.1 and the VM look the method up before evaluating the arguments, Luau after: the readable
    `obj:Method(args)` cannot reproduce both orders, and looking a method up has no effect, so it is not
    compared."""
    out = []
    n = len(ev)
    for i, e in enumerate(ev):
        if e.startswith('R '):
            name = e[2:]
            target = 'C ' + name + '('
            if any(ev[j].startswith(target) for j in range(i + 1, min(n, i + 60))):
                continue
        out.append(e)
    return out


def compare(orig_events, new_events):
    """Return (identical, first_diff_index, details)."""
    n = min(len(orig_events), len(new_events))
    for i in range(n):
        if orig_events[i] != new_events[i]:
            return False, i, (orig_events[max(0, i - 2):i + 3], new_events[max(0, i - 2):i + 3])
    if len(orig_events) != len(new_events):
        return False, n, (orig_events[n:n + 3], new_events[n:n + 3])
    return True, None, None


def prefix_verdict(a, b, idx, a_cut, b_cut, a_clean=False):
    """Both event lists agree up to ``idx``.  When a run was cut (op cap / timeout) the other one may
    legitimately continue; the last event of a timeout-killed run may be partially written and is
    ignored (``a_clean``: the original was cut at an exact marker, nothing partial)."""
    la = len(a) - (1 if (a_cut and not a_clean) else 0)
    lb = len(b) - (1 if b_cut else 0)
    # a cut run may end on the lookup of a method whose call the cut prevented (the VM looks methods up before
    # evaluating the arguments): such trailing lookups have no counterpart yet
    for _ in range(3):
        if a_cut and la > 0 and a[la - 1].startswith('R '):
            la -= 1
        if b_cut and lb > 0 and b[lb - 1].startswith('R '):
            lb -= 1
    if idx is None:
        return False
    if a_cut and not b_cut:
        return la > 0 and idx >= la and len(b) >= la
    if b_cut and not a_cut:
        return lb > 0 and idx >= lb and len(a) >= lb
    if a_cut and b_cut:
        return min(la, lb) > 0 and idx >= min(la, lb)
    return False


def differential(src_text, orig_run_path, user_pids, workdir, orig_cut=False):
    """Compare the event logs of the original (VM) run and of the deobfuscated source.

    ``orig_cut``: the original run was stopped by the harness (time / output cap / op cap of a
    looping program).  Then a deobfuscated run that reproduces all events of the original and goes
    on (it is faster than the VM), or that is itself cut at the same point, counts as ``prefix_equal`` -
    the strongest statement available for a program that does not terminate."""
    out, rc, killed = run_plain(src_text, workdir, timeout=20 if orig_cut else 45)
    a = events(orig_run_path, user_pids)
    b = events(out)
    same, idx, det = compare(a, b)
    prefix_equal = (not same) and prefix_verdict(a, b, idx, orig_cut, bool(killed), a_clean=has_cap_marker(orig_run_path))
    return {'identical': same, 'orig_events': len(a), 'new_events': len(b),
            'first_diff': idx, 'detail': det, 'rc': rc, 'killed': killed, 'prefix_equal': prefix_equal}


def differential_forced(src_text, orig_run_path, user_pids, workdir, flips, name, orig_cut=False):
    """Forced-branch differential: the VM replay ``orig_run_path`` ran with the branch decisions
    in ``flips`` inverted; the test variant of the deobfuscated source (branch conditions wrapped
    in ``__BRF``) is run with the same table, so both must still produce the same events."""
    from . import explore
    out, rc, killed = run_plain(src_text, workdir, name=name, timeout=12 if orig_cut else 30,
                                 prelude=explore.force_prelude(flips))
    a = events(orig_run_path, user_pids)
    b = events(out)
    same, idx, det = compare(a, b)
    prefix_equal = (not same) and prefix_verdict(a, b, idx, orig_cut, bool(killed), a_clean=has_cap_marker(orig_run_path))
    return {'identical': same, 'prefix_equal': prefix_equal, 'orig_events': len(a), 'new_events': len(b),
            'first_diff': idx, 'detail': det, 'rc': rc, 'killed': killed}


def has_cap_marker(path):
    with io.open(path, encoding='utf-8', errors='replace') as fh:
        for ln in fh:
            if ln.startswith('=== CLOSURE EXERCISE'):
                return False
            if ln.startswith('OPCAP reached'):
                return True
    return False
