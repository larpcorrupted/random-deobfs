"""Keep every function below Lua's limit of ~200 active locals.

Functions with more variables than ``limit`` keep the first ``limit // 2`` in locals; the
rest become fields of one table local (``spillN``), referenced lexically by closures.
"""


def _own_names(block, out):
    for s in block:
        t = s[0]
        if t in ('callres', 'local'):
            if s[1] not in out:
                out.append(s[1])
        elif t == 'assign' and s[1][0] == 'var':
            if s[1][1] not in out:
                out.append(s[1][1])
        elif t == 'multi':
            for n in s[1]:
                if n not in out and n != '_':
                    out.append(n)
        elif t == 'if':
            _own_names(s[2], out)
            _own_names(s[3], out)
        elif t == 'while':
            _own_names(s[2], out)


def _expr(e, spill, S, fn):
    if not isinstance(e, tuple) or not e:
        return e
    t = e[0]
    if t == 'var':
        if spill is not None and e[1] in spill:
            return ('index', ('var', S), ('lit', e[1]))
        return e
    if t == 'index':
        return ('index', _expr(e[1], spill, S, fn), _expr(e[2], spill, S, fn))
    if t == 'call':
        return ('call', _expr(e[1], spill, S, fn), [_expr(a, spill, S, fn) for a in e[2]])
    if t == 'mcall':
        return ('mcall', _expr(e[1], spill, S, fn), e[2], [_expr(a, spill, S, fn) for a in e[3]])
    if t == 'bin':
        return ('bin', e[1], _expr(e[2], spill, S, fn), _expr(e[3], spill, S, fn))
    if t == 'un':
        return ('un', e[1], _expr(e[2], spill, S, fn))
    if t == 'table':
        return ('table', [('kv', _expr(i[1], spill, S, fn), _expr(i[2], spill, S, fn)) if i[0] == 'kv'
                          else _expr(i, spill, S, fn) for i in e[1]])
    if t in ('unpack', 'paren'):
        return (t, _expr(e[1], spill, S, fn))
    if t == 'forin':
        return ('forin', e[1], [_expr(x, spill, S, fn) for x in e[2]]) + tuple(e[3:])
    if t == 'func':
        return fn(e)
    return e


def _stmts(block, spill, S, fn):
    out = []
    for s in block:
        t = s[0]
        if t in ('callres', 'local'):
            if spill is not None and s[1] in spill:
                out.append(('assign', ('index', ('var', S), ('lit', s[1])), _expr(s[2], spill, S, fn)))
            else:
                out.append((t, s[1], _expr(s[2], spill, S, fn)))
        elif t == 'assign':
            lhs = s[1]
            if lhs[0] == 'var':
                if spill is not None and lhs[1] in spill:
                    lhs = ('index', ('var', S), ('lit', lhs[1]))
            else:
                lhs = _expr(lhs, spill, S, fn)
            out.append(('assign', lhs, _expr(s[2], spill, S, fn)))
        elif t == 'multi':
            out.append(('multi', s[1], _expr(s[2], spill, S, fn)))
        elif t == 'callstmt':
            out.append(('callstmt', _expr(s[1], spill, S, fn)))
        elif t == 'if':
            out.append(('if', _expr(s[1], spill, S, fn), _stmts(s[2], spill, S, fn), _stmts(s[3], spill, S, fn)))
        elif t == 'while':
            out.append(('while', _expr(s[1], spill, S, fn), _stmts(s[2], spill, S, fn)))
        elif t == 'return':
            out.append(('return', [_expr(v, spill, S, fn) for v in s[1]]))
        else:
            out.append(s)
    return out


_COUNTER = [0]


def spill_locals(block, params=(), limit=150):
    # 1. nested closures first (each is its own scope)
    def deep(e):
        return ('func', e[1], spill_locals(list(e[2]), e[1], limit), e[3])
    block = _stmts(block, None, None, deep)
    own = []
    _own_names(block, own)
    own = [n for n in own if n not in params]
    if len(own) <= limit:
        return block
    keep = set(own[:limit // 2])
    spill = set(own) - keep
    _COUNTER[0] += 1
    S = 'spill%d' % _COUNTER[0]

    # 2. rewrite references (also inside the nested closures, which capture them lexically)
    def deep2(e):
        return ('func', e[1], _stmts(list(e[2]), spill, S, deep2), e[3])
    return [('local', S, ('table', []))] + _stmts(block, spill, S, deep2)


def max_active(block, params=()):
    """Largest number of simultaneously active locals in the function body ``block`` (scoped:
    a name declared inside an `if`/loop body is released when the body ends).  Closures are other
    functions and count separately.  Used to decide whether spilling is needed at all."""
    def forin_names(w):
        h = w[1]
        return len(h[1]) if h and h[0] == 'forin' else 0

    def active(b):
        cur, best = 0, 0
        for st in b:
            t = st[0]
            if t in ('local', 'callres'):
                cur += 1
            elif t in ('multi', 'decl'):
                cur += len(st[1])
            elif t == 'if':
                best = max(best, cur + max(active(st[2]), active(st[3])))
            elif t == 'while':
                best = max(best, cur + forin_names(st) + active(st[2]))
            best = max(best, cur)
        return best
    return len(tuple(params)) + active(block)
