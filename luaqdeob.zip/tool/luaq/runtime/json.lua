-- luau_json.lua: Roblox HttpService-compatible JSON encoder/decoder
-- (concatenated before the shim; defines globals __jsonencode/__jsondecode)

local function jsonesc(s)
	local out = s:gsub('[%c"\\]', function(c)
		if c == '"' then return '\\"' end
		if c == "\\" then return "\\\\" end
		if c == "\n" then return "\\n" end
		if c == "\r" then return "\\r" end
		if c == "\t" then return "\\t" end
		return string.format("\\u%04x", string.byte(c))
	end)
	return '"' .. out .. '"'
end

local function numfmt(v)
	if v ~= v or v == math.huge or v == -math.huge then return "null" end
	if v == math.floor(v) and math.abs(v) < 2 ^ 53 then
		return string.format("%.14g", v)
	end
	return string.format("%.14g", v)
end

local function enc(v, seen)
	local tv = type(v)
	if v == nil then return "null" end
	if tv == "boolean" then return tostring(v) end
	if tv == "number" then return numfmt(v) end
	if tv == "string" then return jsonesc(v) end
	if tv == "table" then
		if seen[v] then error("JSONEncode: circular reference", 2) end
		seen[v] = true
		local n = 0
		for _ in pairs(v) do n = n + 1 end
		local parts = {}
		if n > 0 and #v == n then
			for i = 1, n do parts[i] = enc(v[i], seen) end
			seen[v] = nil
			return "[" .. table.concat(parts, ",") .. "]"
		end
		local allint = true
		for k in pairs(v) do
			if type(k) ~= "number" or k % 1 ~= 0 then allint = false break end
		end
		if allint and n > 0 then
			for i = 1, n do parts[i] = enc(v[i], seen) end
			seen[v] = nil
			return "[" .. table.concat(parts, ",") .. "]"
		end
		for k, v2 in pairs(v) do
			parts[#parts + 1] = jsonesc(tostring(k)) .. ":" .. enc(v2, seen)
		end
		seen[v] = nil
		return "{" .. table.concat(parts, ",") .. "}"
	end
	return "null"
end

__jsonencode = function(v) return enc(v, {}) end

__jsondecode = function(s)
	local pos = 1
	local n = #s
	local function skip()
		while pos <= n do
			local c = s:sub(pos, pos)
			if c == " " or c == "\t" or c == "\n" or c == "\r" then
				pos = pos + 1
			else
				break
			end
		end
	end
	local escmap = { n = "\n", t = "\t", r = "\r", b = "\b", f = "\f", ['"'] = '"', ["\\"] = "\\", ["/"] = "/" }
	local function parse()
		skip()
		local c = s:sub(pos, pos)
		if c == "{" then
			pos = pos + 1
			local o = {}
			skip()
			if s:sub(pos, pos) == "}" then pos = pos + 1 return o end
			while true do
				skip()
				local kmatch = s:match('^"([^"\\]*)"', pos)
				if not kmatch then error("JSONDecode: bad object key at " .. pos) end
				pos = pos + #kmatch + 2
				local k = kmatch:gsub("\\u(%x%x%x%x)", function(h) return utf8.char(tonumber(h, 16)) end)
				k = k:gsub("\\(.)", function(e2) return escmap[e2] or e2 end)
				skip()
				pos = pos + 1
				local v = parse()
				o[k] = v
				skip()
				c = s:sub(pos, pos)
				pos = pos + 1
				if c == "}" then return o end
			end
		elseif c == "[" then
			pos = pos + 1
			local a = {}
			skip()
			if s:sub(pos, pos) == "]" then pos = pos + 1 return a end
			while true do
				a[#a + 1] = parse()
				skip()
				c = s:sub(pos, pos)
				pos = pos + 1
				if c == "]" then return a end
			end
		elseif c == '"' then
			local m = s:match('^"([^"\\]*)"', pos)
			if not m then error("JSONDecode: bad string at " .. pos) end
			pos = pos + #m + 2
			local v = m:gsub("\\u(%x%x%x%x)", function(h) return utf8.char(tonumber(h, 16)) end)
			v = v:gsub("\\(.)", function(e2) return escmap[e2] or e2 end)
			return v
		elseif s:sub(pos, pos + 3) == "true" then
			pos = pos + 4
			return true
		elseif s:sub(pos, pos + 4) == "false" then
			pos = pos + 5
			return false
		elseif s:sub(pos, pos + 3) == "null" then
			pos = pos + 4
			return nil
		else
			local v = s:match("^%-?%d+%.?%d*[eE]?[-+]?%d*", pos)
			if not v then error("JSONDecode: invalid input at " .. pos) end
			pos = pos + #v
			return tonumber(v)
		end
	end
	return parse()
end
