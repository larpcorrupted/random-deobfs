-- Mock of the executor `crypt` library (Luaq >= 2.5 checks that a native hash exists and works).
-- Pure Luau, bit32 based.  Hashes return lower-case hex like the common executors do.
do
	local band, bor, bxor, bnot = bit32.band, bit32.bor, bit32.bxor, bit32.bnot
	local rrotate, rshift, lshift = bit32.rrotate, bit32.rshift, bit32.lshift
	local K256 = {
		0x428a2f98, 0x71374491, 0xb5c0fbcf, 0xe9b5dba5, 0x3956c25b, 0x59f111f1, 0x923f82a4, 0xab1c5ed5,
		0xd807aa98, 0x12835b01, 0x243185be, 0x550c7dc3, 0x72be5d74, 0x80deb1fe, 0x9bdc06a7, 0xc19bf174,
		0xe49b69c1, 0xefbe4786, 0x0fc19dc6, 0x240ca1cc, 0x2de92c6f, 0x4a7484aa, 0x5cb0a9dc, 0x76f988da,
		0x983e5152, 0xa831c66d, 0xb00327c8, 0xbf597fc7, 0xc6e00bf3, 0xd5a79147, 0x06ca6351, 0x14292967,
		0x27b70a85, 0x2e1b2138, 0x4d2c6dfc, 0x53380d13, 0x650a7354, 0x766a0abb, 0x81c2c92e, 0x92722c85,
		0xa2bfe8a1, 0xa81a664b, 0xc24b8b70, 0xc76c51a3, 0xd192e819, 0xd6990624, 0xf40e3585, 0x106aa070,
		0x19a4c116, 0x1e376c08, 0x2748774c, 0x34b0bcb5, 0x391c0cb3, 0x4ed8aa4a, 0x5b9cca4f, 0x682e6ff3,
		0x748f82ee, 0x78a5636f, 0x84c87814, 0x8cc70208, 0x90befffa, 0xa4506ceb, 0xbef9a3f7, 0xc67178f2,
	}

	local function preprocess(msg)
		local len = #msg
		local bits = len * 8
		msg = msg .. "\128" .. string.rep("\0", (55 - len) % 64)
		local hi = math.floor(bits / 4294967296)
		local lo = bits % 4294967296
		msg = msg .. string.char(
			band(rshift(hi, 24), 255), band(rshift(hi, 16), 255), band(rshift(hi, 8), 255), band(hi, 255),
			band(rshift(lo, 24), 255), band(rshift(lo, 16), 255), band(rshift(lo, 8), 255), band(lo, 255))
		return msg
	end

	local function sha256(msg)
		msg = preprocess(msg)
		local H = { 0x6a09e667, 0xbb67ae85, 0x3c6ef372, 0xa54ff53a, 0x510e527f, 0x9b05688c, 0x1f83d9ab, 0x5be0cd19 }
		local w = {}
		for chunk = 1, #msg, 64 do
			for i = 0, 15 do
				local a, b, c, d = string.byte(msg, chunk + i * 4, chunk + i * 4 + 3)
				w[i] = bor(lshift(a, 24), lshift(b, 16), lshift(c, 8), d)
			end
			for i = 16, 63 do
				local x, y = w[i - 15], w[i - 2]
				local s0 = bxor(rrotate(x, 7), rrotate(x, 18), rshift(x, 3))
				local s1 = bxor(rrotate(y, 17), rrotate(y, 19), rshift(y, 10))
				w[i] = (w[i - 16] + s0 + w[i - 7] + s1) % 4294967296
			end
			local a, b, c, d, e, f, g, h = H[1], H[2], H[3], H[4], H[5], H[6], H[7], H[8]
			for i = 0, 63 do
				local S1 = bxor(rrotate(e, 6), rrotate(e, 11), rrotate(e, 25))
				local ch = bxor(band(e, f), band(bnot(e), g))
				local t1 = (h + S1 + ch + K256[i + 1] + w[i]) % 4294967296
				local S0 = bxor(rrotate(a, 2), rrotate(a, 13), rrotate(a, 22))
				local maj = bxor(band(a, b), band(a, c), band(b, c))
				local t2 = (S0 + maj) % 4294967296
				h, g, f, e, d, c, b, a = g, f, e, (d + t1) % 4294967296, c, b, a, (t1 + t2) % 4294967296
			end
			H[1] = (H[1] + a) % 4294967296; H[2] = (H[2] + b) % 4294967296
			H[3] = (H[3] + c) % 4294967296; H[4] = (H[4] + d) % 4294967296
			H[5] = (H[5] + e) % 4294967296; H[6] = (H[6] + f) % 4294967296
			H[7] = (H[7] + g) % 4294967296; H[8] = (H[8] + h) % 4294967296
		end
		local out = {}
		for i = 1, 8 do out[i] = string.format("%08x", H[i]) end
		return table.concat(out)
	end

	local function fromhex(h)
		return (h:gsub("..", function(x) return string.char(tonumber(x, 16)) end))
	end

	local function hmac_sha256(key, msg)
		if #key > 64 then key = fromhex(sha256(key)) end
		key = key .. string.rep("\0", 64 - #key)
		local ipad, opad = {}, {}
		for i = 1, 64 do
			local k = string.byte(key, i)
			ipad[i] = string.char(bxor(k, 0x36))
			opad[i] = string.char(bxor(k, 0x5c))
		end
		local inner = fromhex(sha256(table.concat(ipad) .. msg))
		return sha256(table.concat(opad) .. inner)
	end

	local b64 = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/"
	local function b64enc(data)
		return ((data:gsub(".", function(x)
			local r, byte = "", x:byte()
			for i = 8, 1, -1 do r = r .. (byte % 2 ^ i - byte % 2 ^ (i - 1) > 0 and "1" or "0") end
			return r
		end) .. "0000"):gsub("%d%d%d?%d?%d?%d?", function(x)
			if #x < 6 then return "" end
			local c = 0
			for i = 1, 6 do c = c + (x:sub(i, i) == "1" and 2 ^ (6 - i) or 0) end
			return b64:sub(c + 1, c + 1)
		end) .. ({ "", "==", "=" })[#data % 3 + 1])
	end
	local function b64dec(data)
		data = data:gsub("[^" .. b64 .. "=]", "")
		return (data:gsub(".", function(x)
			if x == "=" then return "" end
			local r, f = "", (b64:find(x, 1, true) - 1)
			for i = 6, 1, -1 do r = r .. (f % 2 ^ i - f % 2 ^ (i - 1) > 0 and "1" or "0") end
			return r
		end):gsub("%d%d%d?%d?%d?%d?%d?%d?", function(x)
			if #x ~= 8 then return "" end
			local c = 0
			for i = 1, 8 do c = c + (x:sub(i, i) == "1" and 2 ^ (8 - i) or 0) end
			return string.char(c)
		end))
	end

	local function algo_of(a)
		return string.lower(tostring(a or "sha256")):gsub("[^%w]", "")
	end

	crypt = {
		hash = function(data, algo)
			local a = algo_of(algo)
			if a == "sha256" then return sha256(tostring(data)) end
			error("crypt.hash: unsupported algorithm " .. tostring(algo))
		end,
		hmac = function(key, data, algo)
			local a = algo_of(algo)
			if a == "sha256" then return hmac_sha256(tostring(key), tostring(data)) end
			error("crypt.hmac: unsupported algorithm " .. tostring(algo))
		end,
		base64encode = b64enc, base64_encode = b64enc, base64 = { encode = b64enc, decode = b64dec },
		base64decode = b64dec, base64_decode = b64dec,
	}
	crypt.base64.encode = b64enc
	crypt.base64.decode = b64dec
	__CRYPT_SHA256 = sha256
end
