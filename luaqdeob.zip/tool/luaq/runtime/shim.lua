-- luau_shim.lua: minimal Roblox-environment prelude for running luaq samples
local __REALG = getfenv(1)
__RSM = setmetatable
-- user code must see the same pseudo-random numbers in the VM run and in the deobfuscated run
-- (the VM run reseeds when the DRM handshake completes, i.e. when the user program starts)
math.randomseed(777)
-- under the real Luau CLI (work/luau-bin/luau.exe). Concatenate with the
-- transpiled sample into one file (Luau CLI has no runtime file I/O).
-- Ports the mocks from work/env2.lua with identical observable semantics.

-- variant-B loaders (Lua 5.4 executors) use debug.getinfo/getlocal, which the
-- Luau debug library lacks (and its stdlib tables are frozen); expose a
-- wrapper via the env proxy.
local __DEBUG54
if debug and not debug.getinfo then
	local __dinfo = debug.info
	local function __getinfo(lvl, what)
		if type(lvl) == "function" then
			local src, line, name = __dinfo(lvl, "sln")
			return { source = src, short_src = src, currentline = line, name = name,
				what = "Lua", func = lvl, nups = 0, linedefined = 0,
				lastlinedefined = 0, isvararg = false, nparams = 0 }
		end
		local src, line, name = __dinfo(lvl + 1, "sln")
		return { source = src, short_src = src, currentline = line, name = name,
			what = "Lua", nups = 0, linedefined = 0,
			lastlinedefined = 0, isvararg = false, nparams = 0 }
	end
	-- real fields (not an __index chain): tamper checks use rawget(debug, "info")
	__DEBUG54 = { getinfo = __getinfo, getlocal = function() return nil end }
	for k, v in pairs(debug) do __DEBUG54[k] = v end
end

local __sha256 = (function()
	-- inlined work/sha256.lua (pure-Lua SHA-256, returns raw 32-byte digest)
	local K = {
		0x428a2f98, 0x71374491, 0xb5c0fbcf, 0xe9b5dba5, 0x3956c25b, 0x59f111f1, 0x923f82a4, 0xab1c5ed5,
		0xd807aa98, 0x12835b01, 0x243185be, 0x550c7dc3, 0x72be5d74, 0x80deb1fe, 0x9bdc06a7, 0xc19bf174,
		0xe49b69c1, 0xefbe4786, 0x0fc19dc6, 0x240ca1cc, 0x2de92c6f, 0x4a7484aa, 0x5cb0a9dc, 0x76f988da,
		0x983e5152, 0xa831c66d, 0xb00327c8, 0xbf597fc7, 0xc6e00bf3, 0xd5a79147, 0x06ca6351, 0x14292967,
		0x27b70a85, 0x2e1b2138, 0x4d2c6dfc, 0x53380d13, 0x650a7354, 0x766a0abb, 0x81c2c92e, 0x92722c85,
		0xa2bfe8a1, 0xa81a664b, 0xc24b8b70, 0xc76c51a3, 0xd192e819, 0xd6990624, 0xf40e3585, 0x106aa070,
		0x19a4c116, 0x1e376c08, 0x2748774c, 0x34b0bcb5, 0x391c0cb3, 0x4ed8aa4a, 0x5b9cca4f, 0x682e6ff3,
		0x748f82ee, 0x78a5636f, 0x84c87814, 0x8cc70208, 0x90befffa, 0xa4506ceb, 0xbef9a3f7, 0xc67178f2,
	}
	local band, bxor, rrotate, rshift =
		bit32.band, bit32.bxor, bit32.rrotate, bit32.rshift
	local function tobytes(n)
		return string.char(
			band(rshift(n, 24), 0xFF), band(rshift(n, 16), 0xFF),
			band(rshift(n, 8), 0xFF), band(n, 0xFF))
	end
	local function pad(msg)
		local len = #msg
		local padlen = (55 - len) % 64 + 1
		return msg .. string.char(0x80) .. string.rep(string.char(0), padlen - 1)
			.. string.rep(string.char(0), 4)
			.. string.char(band(rshift(len * 8, 24), 0xFF), band(rshift(len * 8, 16), 0xFF),
				band(rshift(len * 8, 8), 0xFF), band(len * 8, 0xFF))
	end
	return function(data)
		local H = { 0x6a09e667, 0xbb67ae85, 0x3c6ef372, 0xa54ff53a,
			0x510e527f, 0x9b05688c, 0x1f83d9ab, 0x5be0cd19 }
		local msg = pad(data)
		for i = 1, #msg, 64 do
			local w = {}
			for j = 0, 15 do
				local o = i + j * 4
				w[j] = bit32.bor(bit32.lshift(string.byte(msg, o + 1), 24), bit32.lshift(string.byte(msg, o + 2), 16),
					bit32.lshift(string.byte(msg, o + 3), 8), string.byte(msg, o + 4))
			end
			for j = 16, 63 do
				local s0 = bxor(rrotate(w[j - 15], 7), rrotate(w[j - 15], 18), rshift(w[j - 15], 3))
				local s1 = bxor(rrotate(w[j - 2], 17), rrotate(w[j - 2], 19), rshift(w[j - 2], 10))
				w[j] = (w[j - 16] + s0 + w[j - 7] + s1) % 4294967296
			end
			local a, b, c, d, e, f, g, h =
				H[1], H[2], H[3], H[4], H[5], H[6], H[7], H[8]
			for j = 0, 63 do
				local S1 = bxor(rrotate(e, 6), rrotate(e, 11), rrotate(e, 25))
				local ch = bxor(band(e, f), band(bxor(e, 0xFFFFFFFF), g))
				local t1 = (h + S1 + ch + K[j + 1] + w[j]) % 4294967296
				local S0 = bxor(rrotate(a, 2), rrotate(a, 13), rrotate(a, 22))
				local maj = bxor(band(a, b), band(a, c), band(b, c))
				local t2 = (S0 + maj) % 4294967296
				h, g, f, e = g, f, e, (d + t1) % 4294967296
				d, c, b, a = c, b, a, (t1 + t2) % 4294967296
			end
			H[1] = (H[1] + a) % 4294967296
			H[2] = (H[2] + b) % 4294967296
			H[3] = (H[3] + c) % 4294967296
			H[4] = (H[4] + d) % 4294967296
			H[5] = (H[5] + e) % 4294967296
			H[6] = (H[6] + f) % 4294967296
			H[7] = (H[7] + g) % 4294967296
			H[8] = (H[8] + h) % 4294967296
		end
		return tobytes(H[1]) .. tobytes(H[2]) .. tobytes(H[3]) .. tobytes(H[4])
			.. tobytes(H[5]) .. tobytes(H[6]) .. tobytes(H[7]) .. tobytes(H[8])
	end
end)()

-- typeof: Roblox semantics — honors the __typeof metatable field for instances
local __typeofreal = typeof
typeof = function(v)
	local t = type(v)
	if t == "table" then
		local mt = getmetatable(v)
		if mt and type(mt.__typeof) == "string" then
			return mt.__typeof
		end
	end
	return __typeofreal(v)
end


-- Roblox instances: permissive mocks with ClassName, IsA, Parent
game, workspace = nil, nil
-- env access log (for deobfuscation reconstruction + differential validation)
__ELOGN = 0
-- library arithmetic log (`A ...` events): only for debugging, the VM's own decoding floods it and the differential
-- ignores it
__LOGA = __LOGA or false
local function __ELOG(s)
	if __QUIET then return end
	__ELOGN = __ELOGN + 1
	if __ELOGN > (__ELOGMAX or 400000) then return end
	print("ENV" .. ((__CURPID or 0) ~= 0 and ("#" .. __CURPID) or "") .. " " .. s)
end
-- bit32/buffer op logging (polyfill differential debugging)
if getenv54trace then
	do
		local __rb32 = bit32
		local w32 = {}
		for k2, v2 in pairs(__rb32) do
			w32[k2] = function(...)
				local n = select("#", ...)
				local args = {}
				for i = 1, n do
					args[#args + 1] = tostring((select(i, ...))):sub(1, 20)
				end
				local r = table.pack(pcall(v2, ...))
				local res
				if r[1] then
					res = type(r[2]) == "table" and "BUF" or tostring(r[2])
				else
					res = "ERR:" .. tostring(r[2]):sub(1, 60)
				end
				print("B32 " .. k2 .. "(" .. table.concat(args, ",") .. ") = " .. res)
				if r[1] then return table.unpack(r, 2, r.n) else error(r[2], 2) end
			end
		end
		bit32 = w32
		local __rbuf = buffer
		local wbuf = {}
		for k2, v2 in pairs(__rbuf) do
			wbuf[k2] = function(...)
				local n = select("#", ...)
				local args = {}
				for i = 1, n do
					local v = select(i, ...)
					args[#args + 1] = type(v) == "table" and "BUF" or tostring(v):sub(1, 20)
				end
				local r = table.pack(pcall(v2, ...))
				local res
				if r[1] then
					res = type(r[2]) == "table" and "BUF" or tostring(r[2]):sub(1, 40)
				else
					res = "ERR:" .. tostring(r[2]):sub(1, 60)
				end
				print("BUF " .. k2 .. "(" .. table.concat(args, ",") .. ") = " .. res)
				if r[1] then return table.unpack(r, 2, r.n) else error(r[2], 2) end
			end
		end
		buffer = wbuf
	end
end
function __argstr(v)
	local tv = type(v)
	if tv == "string" then
		return string.format("%q", v)
	elseif tv == "number" or tv == "boolean" then
		return tostring(v)
	elseif tv == "table" then
		local cn = rawget(v, "ClassName")
		if cn then return "I<" .. tostring(v) .. ">" end
		local mt = getmetatable(v)
		if mt and mt.__typeof == "EnumItem" then return tostring(v) end
		if mt and mt.__tostring then return tostring(v) end
		return "T"
	elseif tv == "function" then
		return "F"
	end
	return tv
end
local function __argsstr(...)
	local n = select("#", ...)
	local parts = {}
	for i = 1, n do parts[i] = __argstr((select(i, ...))) end
	return table.concat(parts, ",")
end

local __mkinstance -- fwd

-- v2: parent mode (2nd callback pass makes .Parent non-nil so both branches
-- of instance guards get observed) and arithmetic tape (numeric property
-- reads return wrappers whose metamethods log ENV A lines)
__PARENTMODE = false
local __NUMKEYS = {
	Magnitude = true, WalkSpeed = true, Health = true, MaxHealth = true,
	X = true, Y = true, Z = true, Volume = true, PlaybackSpeed = true,
	FieldOfView = true, Transparency = true, Gravity = true, Brightness = true,
	Ambient0 = true, TimeOfDay = true, JogSpeed = true, WalkSpeedPercent = true,
}
local __VECKEYS = {
	AssemblyLinearVelocity = true, Velocity = true, Position = true,
	Size = true, ExtentsSize = true, Resolution = true,
}
local function __provof(v)
	if type(v) == "table" and rawget(v, "__prov") then
		return rawget(v, "__prov")
	end
	return tostring(v)
end
-- wrappers carry a deterministic placeholder value so arithmetic computes
local function __numval(v)
	if type(v) == "table" and rawget(v, "__prov") then
		return 0
	end
	return v
end
local function __num(prov)
	local mt = {}
	local function bin(op, sym)
		mt["__" .. op] = function(a, b)
			local r = op == "add" and (__numval(a) + __numval(b))
				or op == "sub" and (__numval(a) - __numval(b))
				or op == "mul" and (__numval(a) * __numval(b))
				or op == "div" and (__numval(a) / __numval(b))
				or op == "idiv" and (__numval(a) // __numval(b))
				or (__numval(a) % __numval(b))
			if __LOGA then __ELOG("A " .. __provof(a) .. " " .. sym .. " " .. __provof(b) .. " = " .. tostring(r)) end
			return r
		end
	end
	bin("add", "+")
	bin("sub", "-")
	bin("mul", "*")
	bin("div", "/")
	bin("idiv", "//")
	bin("mod", "%")
	mt.__unm = function(a)
		local r = -__numval(a)
		if __LOGA then __ELOG("A -" .. __provof(a) .. " = " .. tostring(r)) end
		return r
	end
	mt.__concat = function(a, b)
		local r = tostring(a) .. tostring(b)
		if __LOGA then __ELOG("A " .. __provof(a) .. " .. " .. __provof(b) .. " = " .. r) end
		return r
	end
	mt.__lt = function(a, b)
		local r = __numval(a) < __numval(b)
		if __LOGA then __ELOG("A " .. __provof(a) .. " < " .. __provof(b) .. " = " .. tostring(r)) end
		return r
	end
	mt.__le = function(a, b)
		local r = __numval(a) <= __numval(b)
		if __LOGA then __ELOG("A " .. __provof(a) .. " <= " .. __provof(b) .. " = " .. tostring(r)) end
		return r
	end
	mt.__tostring = function(a) return "0" end
	return setmetatable({ __prov = prov }, mt)
end
-- plain Roblox default values for numeric properties: a real number can be compared (`humanoid.Health <= 0`), a
-- tracked numeric mock (a table) cannot in Luau, and the code behind such a test would never run
local __NUMDEFAULT = {
	Magnitude = 0, WalkSpeed = 16, JogSpeed = 16, Health = 100, MaxHealth = 100, X = 0, Y = 0, Z = 0,
	Volume = 0.5, PlaybackSpeed = 1, FieldOfView = 70, Transparency = 0, Gravity = 196.2, Brightness = 2,
	WalkSpeedPercent = 1,
}
local function __numv(key, prov)
	local d = __NUMDEFAULT[key]
	if d ~= nil then return d end
	return __num(prov)
end
local function __vec(prov)
	return setmetatable({ __prov = prov }, {
		__index = function(t, k)
			local kn = tostring(k)
			if kn == "Unit" or kn == "Mass" then
				return __num(prov .. "." .. kn)
			end
			return __numv(kn, prov .. "." .. kn)
		end,
		__tostring = function() return "V(" .. prov .. ")" end,
	})
end
local __WMATH
local function __wrapmath(m)
	if __WMATH then return __WMATH end
	local w = {}
	for k2, v2 in pairs(m) do w[k2] = v2 end
	local one = { floor = 1, ceil = 1, abs = 1, sqrt = 1, round = 1, sin = 1, cos = 1, tan = 1, exp = 1, sign = 1, noise = 1 }
	for k2 in pairs(one) do
		local f = w[k2]
		if f then
			w[k2] = function(x, ...)
				local r = f(x, ...)
				if __LOGA then __ELOG("A " .. tostring(k2) .. "(" .. __provof(x) .. ") = " .. tostring(r)) end
				return r
			end
		end
	end
	local two = { max = 1, min = 1, pow = 1, fmod = 1, modf = 1, atan2 = 1, clamp = 1 }
	for k2 in pairs(two) do
		local f = w[k2]
		if f then
			w[k2] = function(x, ...)
				local r = f(x, ...)
				if __LOGA then __ELOG("A " .. tostring(k2) .. "(" .. __provof(x) .. "," .. __provof((select(2, ...))) .. ") = " .. tostring(r)) end
				return r
			end
		end
	end
	w.random = function(a, b)
		local r
		if b then r = m.random(a, b) elseif a then r = m.random(a) else r = m.random() end
		if __LOGA then __ELOG("A random(" .. tostring(a) .. "," .. tostring(b) .. ") = " .. tostring(r)) end
		return r
	end
	-- 5.4 markers variant-B loaders check for (Luau's math lacks them)
	if w.maxinteger == nil then w.maxinteger = math.huge end
	if w.mininteger == nil then w.mininteger = -math.huge end
	if w.tointeger == nil then
		w.tointeger = function(x)
			if type(x) == "number" and x % 1 == 0 then return x end
			return nil
		end
	end
	if w.type == nil then
		w.type = function(x)
			if type(x) ~= "number" then return nil end
			-- 5.4 distinguishes integers; Luau numbers are doubles, so report
			-- integral values the way 5.4 reports its integer subtype
			if x % 1 == 0 and x ~= math.huge and x ~= -math.huge then return "integer" end
			return "float"
		end
	end
	__WMATH = w
	return w
end
local __WSTRING
local function __wrapstring(s)
	if __WSTRING then return __WSTRING end
	local w = {}
	for k2, v2 in pairs(s) do w[k2] = v2 end
	w.format = function(fmt, ...)
		local args = { ... }
		for i = 1, #args do
			if type(args[i]) == "table" and rawget(args[i], "__prov") then
				if __LOGA then __ELOG("A format-arg" .. i .. "=" .. rawget(args[i], "__prov")) end
				args[i] = 0
			end
		end
		local r = s.format(fmt, table.unpack(args))
		if __LOGA then __ELOG("A format(" .. tostring(fmt) .. ") = " .. tostring(r)) end
		return r
	end
	__WSTRING = w
	return w
end

local function mkcallable(path)
	local ct = {}
	return setmetatable(ct, {
		__call = function(self, ...)
			__ELOG("C " .. path .. "(" .. __argsstr(...) .. ")")
			local a = { ... }
			local r
			local pname = path:gsub(".*[:%.]", "")
			if pname == "FindFirstChild" or pname == "WaitForChild" then
				r = __mkinstance((path:match("^(.*):[^:]*$") or path) .. "." .. tostring(a[2]))
			elseif pname == "FindFirstChildOfClass" then
				r = __mkinstance((path:match("^(.*):[^:]*$") or path) .. "." .. tostring(a[2]))
			elseif pname == "Connect" or pname == "connect" or pname == "ConnectAsync" or pname == "ConnectParallel" or pname == "Once" then
				__CONNECTED = __CONNECTED or {}
				__CONNECTED[#__CONNECTED + 1] = { path = path, fn = a[2] }
				r = __mkinstance(path .. ":conn")
			elseif pname == "GetServerTimeNow" then
				r = 1790000000 + __VNOW()
			elseif pname == "GetNetworkPing" or pname == "GetRealPhysicsFPS" then
				r = pname == "GetNetworkPing" and 0.05 or 60
			elseif pname == "HttpGet" or pname == "HttpGetAsync" then
				-- a body string (a Lua comment: `loadstring(game:HttpGet(url))()` loads and runs nothing)
				r = "-- HTTP body of " .. tostring(a[2])
			elseif pname == "Wait" and (path:find("Heartbeat", 1, true) or path:find("RenderStepped", 1, true)
				or path:find("Stepped", 1, true)) then
				r = __VADV(1 / 60)              -- a frame passes
			elseif pname == "Wait" or pname == "Destroy" or pname == "Destroying" then
				r = nil
			else
				r = __mkinstance(path .. "()")
			end
			__ELOG("  = " .. __argstr(r))
			return r
		end,
		__index = function(t, k)
			__ELOG("R " .. path .. "." .. tostring(k))
			return mkcallable(path .. "." .. tostring(k))
		end,
		__tostring = function() return path end,
	})
end

local __game_decl
local function mkinstance(class)
	local o = {}
	o.ClassName = class
	return setmetatable(o, {
		__typeof = "Instance",
		__index = function(t, k)
			local rv = rawget(t, k)
			if rv ~= nil then
				if type(rv) == "function" then
					return function(self, ...)
						__ELOG("C " .. class .. "." .. tostring(k) .. "(" .. __argsstr(...) .. ")")
						local r = rv(self, ...)
						__ELOG("  = " .. __argstr(r))
						return r
					end
				end
				return rv
			end
			__ELOG("R " .. class .. "." .. tostring(k))
			if k == "Parent" then
				if class == "Workspace" then return game end
				if __PARENTMODE then return __mkinstance(class .. ":parent") end
				return nil
			end
			if type(k) == "string" and __NUMKEYS[k] then
				return __numv(k, class .. "." .. k)
			end
			if type(k) == "string" and __VECKEYS[k] then
				return __vec(class .. "." .. k)
			end
			if k == "IsA" then
				return function(self, c)
					return rawget(self, "ClassName") == c or c == "Instance"
				end
			end
			if class == "HttpService" then
				if k == "JSONEncode" then
					return function(_, v)
						local r = __jsonencode(v)
						print("JSONEncode(" .. tostring(v) .. ") = " .. tostring(r))
						return r
					end
				end
				if k == "JSONDecode" then
					return function(_, s) return __jsondecode(s) end
				end
				if k == "GenerateGUID" then
					return function(_, wrap)
						local o = {}
						for i = 1, 32 do o[i] = string.byte("0123456789abcdef", math.random(1, 16)) end
						local s2 = string.char(table.unpack(o))
						local g = s2:sub(1, 8) .. "-" .. s2:sub(9, 12) .. "-" .. s2:sub(13, 16)
							.. "-" .. s2:sub(17, 20) .. "-" .. s2:sub(21, 32)
						if wrap then return "{" .. g .. "}" end
						return g
					end
				end
			end
			return mkcallable(class .. "." .. tostring(k))
		end,
		__newindex = function(t, k, v)
			__ELOG("W " .. class .. "." .. tostring(k) .. " = " .. __argstr(v))
			rawset(t, k, v)
		end,
		__call = function() return nil end,
		__tostring = function() return class end,
	})
end
__mkinstance = mkinstance

Instance = {
	new = function(class, parent) return mkinstance(class) end,
}

game = mkinstance("DataModel")
local services = {}
rawset(game, "GetService", function(self, name)
	if not services[name] then
		if name == "Workspace" then
			services[name] = workspace
		else
			services[name] = mkinstance(name)
		end
	end
	return services[name]
end)
do
	local svc = mkinstance("EncodingService")
	rawset(svc, "ComputeStringHash", function(self, data, algo)
		if type(data) == "string" then
			return __sha256(data)
		end
		return __sha256(tostring(data))
	end)
	rawset(svc, "ComputeBufferHash", function(self, data, algo)
		return buffer.fromstring(__sha256(buffer.tostring(data)))
	end)
	services["EncodingService"] = svc
end
rawset(game, "ClassName", "DataModel")

workspace = mkinstance("Workspace")
rawset(workspace, "ClassName", "Workspace")

Instance = Instance
game = game
workspace = workspace

-- Roblox Enum: nested tables with lazy EnumItem creation (each item: Name, Value, EnumType)
local __ENUMVALUES = {
	RenderPriority = { First = 0, Input = 100, Camera = 200, Character = 300, Last = 2000 },
	UserInputType = { MouseButton1 = 0, MouseButton2 = 1, MouseButton3 = 2, MouseWheel = 3, MouseMovement = 4,
		Touch = 7, Keyboard = 8, Focus = 9, Accelerometer = 10, Gyro = 11, Gamepad1 = 12, TextInput = 20, None = 21 },
	HumanoidStateType = { FallingDown = 0, Running = 8, RunningNoPhysics = 10, Climbing = 12, StrafingNoPhysics = 11,
		Ragdoll = 1, GettingUp = 2, Jumping = 3, Landed = 7, Flying = 6, Freefall = 5, Seated = 13,
		PlatformStanding = 14, Dead = 15, Swimming = 4, Physics = 16, None = 18 },
}
Enum = setmetatable({}, {
	__index = function(t, k)
		local et = {}
		local known = __ENUMVALUES[k] or {}
		local nextv = 0
		local items = {}
		rawset(t, k, setmetatable(et, {
			__tostring = function() return k end,
			__index = function(tt, k2)
				if k2 == "GetEnumItems" then
					return function() local r = {}; for _, it in ipairs(items) do r[#r + 1] = it end; return r end
				end
				local v = known[k2]
				if v == nil then
					v = nextv
					nextv = nextv + 1
				end
				local itemmt = {
					__typeof = "EnumItem",
					__tostring = function() return "Enum." .. k .. "." .. tostring(k2) end,
				}
				local item = setmetatable({ Name = k2, Value = v, EnumType = tt,
					IsA = function(_, n) return n == k end }, itemmt)
				rawset(tt, k2, item)
				items[#items + 1] = item
				return item
			end,
		}))
		return rawget(t, k)
	end,
})

-- Roblox task library (headless: spawn/defer/delay run inline)
local __taskq = {}
task = {
	spawn = function(f, ...)
		if __SWEEP and type(f) ~= 'function' and type(f) ~= 'thread' then local g_ = f; f = function(...) return g_(...) end end
		local co = coroutine.create(f)
		local r = table.pack(coroutine.resume(co, ...))
		if not r[1] then error(r[2], 2) end
		return co
	end,
	defer = function(f, ...)
		if __SWEEP and type(f) ~= 'function' then local g_ = f; f = function(...) return g_(...) end end
		return coroutine.wrap(f)(...)
	end,
	delay = function(_, f, ...)
		if __SWEEP and type(f) ~= 'function' then local g_ = f; f = function(...) return g_(...) end end
		return coroutine.wrap(f)(...)
	end,
	wait = function(t)
		return __VADV(t)
	end,
	cancel = function(co) pcall(function() coroutine.close(co) end) end,
}

-- Roblox time globals on the virtual clock
tick = function() return 1790000000 + __VNOW() end
time = function() return __VNOW() end
elapsedTime = function() return __VNOW() end
wait = function(t) local dt = __VADV(t); return dt, __VT end
delay = function(t, f, ...) return task.delay(t, f, ...) end
spawn = function(f, ...) return task.spawn(f, ...) end

-- Roblox Random (PCG32, 64-bit state)
local function mkRandom(seed)
	seed = math.floor(tonumber(seed) or 0) % 18446744073709551616
	local st = { state = seed, inc = (seed * 2 + 1) % 18446744073709551616 }
	local function next32()
		local old = st.state
		st.state = (old * 6364136223846793005 + st.inc) % 18446744073709551616
		-- 64-bit ops via doubles lose precision; emulate via bit32 pairs
		local old_lo = old % 4294967296
		local old_hi = math.floor(old / 4294967296) % 4294967296
		local xorshifted = bit32.band(
			bit32.bxor(bit32.rshift(old_lo, 18), bit32.band(old_hi, 0x3FFF) * 262144 % 4294967296 == 0 and 0 or old_hi),
			0xFFFFFFFF)
		-- simpler faithful path: use bit32 on the low/high halves
		xorshifted = bit32.band(bit32.bxor(bit32.rshift(old_lo, 18), bit32.lshift(old_hi, 14)), 0xFFFFFFFF)
		local rot = math.floor(old / 576460752303423488) % 32
		local r1 = bit32.rrotate(xorshifted, rot)
		local r2 = bit32.lrotate(xorshifted, (32 - rot) % 32)
		return bit32.band(bit32.bor(bit32.rshift(r1, rot), bit32.lshift(r2, (32 - rot) % 32)), 0xFFFFFFFF)
	end
	local r
	r = {
		NextInteger = function(_, min, max)
			if min > max then error("NextInteger: min is greater than max", 2) end
			local range = max - min + 1
			local limit = (0x100000000 // range) * range
			local v = next32()
			while v >= limit do v = next32() end
			return min + (v % range)
		end,
		NextNumber = function(_, min, max)
			if min == nil and max == nil then min, max = 0, 1 end
			if min ~= nil and max == nil then min, max = 0, min end
			if min > max then error("NextNumber: min is greater than max", 2) end
			local hi = next32() / 0x100000000
			local lo = next32() / 0x100000000
			return min + (hi + lo / 0x100000000) * (max - min)
		end,
		NextUnitVector = function()
			while true do
				local x = next32() / 0x80000000 - 1
				local y = next32() / 0x80000000 - 1
				local z = next32() / 0x80000000 - 1
				local m = x * x + y * y + z * z
				if m > 0 and m <= 1 then
					local s = 1 / math.sqrt(m)
					return { X = x * s, Y = y * s, Z = z * s }
				end
			end
		end,
		Clone = function() return mkRandom(st.state) end,
	}
	return setmetatable({}, {
		__typeof = "Random",
		__index = r,
		__eq = function(a, b) return rawget(a, "__eqst") == rawget(b, "__eqst") end,
	})
end
Random = { new = function(seed) return mkRandom(seed) end }

-- diagnostic: proxy env so missing-global reads are visible
-- raw field: 5.4 gates do rawget(_ENV, "_VERSION"), bypassing __index
local __PROXY = setmetatable({ _VERSION = "Lua 5.4" }, {
	__index = function(t, k)
		__ELOG("G " .. tostring(k))
		if __SWDEBUG and k == "task" then
			__TASKHITS = (__TASKHITS or 0) + 1
			if __TASKHITS == 3000 or __TASKHITS == 60000 or __TASKHITS == 150000 then print("TASKHIT traceback" .. string.char(10) .. debug.traceback() .. " clk=" .. tostring(__CLKDEADLINE) .. " captick=" .. tostring(__CAPTICKV and __CAPTICKV()) .. " ring=" .. tostring(__OPRINGN) .. " max=" .. tostring(__OPMAX) .. " indump=" .. tostring(__INDUMP) .. " quiet=" .. tostring(__QUIET) .. " ophn=" .. tostring(__OPHN) .. " allcl=" .. tostring(#__ALLCL) .. " tickmax=" .. tostring(__SW and __SW.tickmax) .. " yieldable=" .. tostring(coroutine.isyieldable()) .. " now=" .. __RAWCLOCK() .. string.char(10) .. string.rep("#", 200000)) end
		end
		-- 5.4 chunks see _ENV as the env table itself
		if k == "_ENV" then
			return t
		end
		if k == "debug" and __DEBUG54 then
			return __DEBUG54
		end
		-- the real global table is read-only in this host: inside a driven closure `_G.X = v` must not end the call
		if k == '_G' and __SWEEP and __SW and __SW.driving then return t end
		-- Roblox's `_G` is a writable table shared by scripts (the host's own global table is read-only): reads fall
		-- back to the real globals, writes stay in it
		if k == '_G' then
			if not __USERG then
				__USERG = setmetatable({}, {
					__index = function(_, k2) return __REALG[k2] end,
					__newindex = function(tt, k2, v2)
						__ELOG("W _G." .. tostring(k2) .. " = " .. __argstr(v2))
						rawset(tt, k2, v2)
					end,
				})
			end
			return __USERG
		end
		if __SWSAFE then
			local sv = __SWSAFE[k]
			if sv ~= nil then return sv end
		end
		-- variant-B loaders check the executor version string
		if k == "_VERSION" then
			return "Lua 5.4"
		end
		-- 5.4 has no global unpack (only table.unpack)
		if k == "unpack" and __FORCE54ENV then
			return nil
		end
		-- 5.4's coroutine.running() returns (thread, ismain); Luau's returns 1 value
		if k == "coroutine" and __FORCE54ENV then
			__CORO54 = __CORO54 or (function()
				local w = {}
				for k2, v2 in pairs(__REALG.coroutine) do w[k2] = v2 end
				local __crunning = w.running
				w.running = function(...)
					local n = select("#", __crunning(...))
					if n == 1 then return __crunning(...), true end
					return __crunning(...)
				end
				return w
			end)()
			return __CORO54
		end
		local v = __REALG[k]
		if k == "math" and type(v) == "table" then
			if __SWSAFEWRAP then return __SWSAFEWRAP(__wrapmath(v), 0, "math") end
			return __wrapmath(v)
		end
		if k == "string" and type(v) == "table" then
			if __SWSAFEWRAP then return __SWSAFEWRAP(__wrapstring(v), "", "string") end
			return __wrapstring(v)
		end
		if k == "table" and type(v) == "table" and __SWSAFEWRAP then return __SWSAFEWRAP(v, nil, "table") end
		-- static sweep, inside a driven closure: a global the program expects is a dummy, not nil
		if v == nil and __SWEEP and __DUMMY and __SW and __SW.driving and not (type(k) == "string" and k:sub(1, 5) == "LUAQ_") then
			return __DUMMY
		end
		if v == nil then
			if type(k) == "string" and k:sub(1, 5) == "LUAQ_" then
				print("PROBE (returning nil): " .. tostring(k))
				return nil
			end
			print("MISSING GLOBAL: " .. tostring(k))
			-- permissive Roblox datatype/class fallback: X.new(...) -> instance
			local function __mkctor(name, ...)
				__ELOG("C " .. name .. "(" .. __argsstr(...) .. ")")
				if name == "getgenv.new" then
					-- executor env table (one table for the whole run, like the executor's): nil-default reads,
					-- logged writes
					if __GENV then return __GENV end
					__GENV = setmetatable({}, {
						__index = function(t, k2)
							__ELOG("R getgenv()." .. tostring(k2))
							return nil
						end,
						__newindex = function(t, k2, v)
							__ELOG("W getgenv()." .. tostring(k2) .. " = " .. __argstr(v))
							rawset(t, k2, v)
						end,
						__tostring = function() return "getgenv()" end,
					})
					return __GENV
				end
				return mkinstance(name .. "(" .. __argsstr(...) .. ")")
			end
			local cls
			cls = setmetatable({
				new = function(...) return __mkctor(tostring(k) .. ".new", ...) end,
			}, {
				__call = function(_, ...) return __mkctor(tostring(k) .. ".new", ...) end,
				__index = function(tt, k2)
					return function(...) return __mkctor(tostring(k) .. "." .. tostring(k2), ...) end
				end,
			})
			rawset(t, k, cls)
			return cls
		end
		return v
	end,
	__newindex = function(t, k, v)
		if __SWEEP then return end            -- the sweep runs on dummies: no global may be rebound
		__ELOG("W " .. tostring(k) .. " = " .. __argstr(v))
		if type(v) == "function" then
			__GFUNCS[#__GFUNCS + 1] = { name = tostring(k), fn = v }
		end
		__REALG[k] = v
	end,
})
__GFUNCS = {}
local __realerror = error
__RAWE = __realerror
__RAWERRORFN = __realerror
__MYERR = nil
__PTALL = {}
__OPN = 0
__OPFORCE = false
-- cross-proto op ring: records the last N ops of every proto, dumped on error
__OPRING = {}
__OPRINGN = 0
__OPLASTLA = nil
__SEENLA = {}
__PROTOS = {}
__JVS = function(v, seen)
	local tv = type(v)
	if tv == "string" then
		local out = v:gsub('[%c"\\]', function(c)
			if c == '"' then return '\\"' end
			if c == "\\" then return "\\\\" end
			if c == "\n" then return "\\n" end
			if c == "\r" then return "\\r" end
			if c == "\t" then return "\\t" end
			return string.format("\\u%04x", string.byte(c))
		end)
		return '"' .. out .. '"'
	end
	if tv == "number" then
		if v ~= v or v == math.huge or v == -math.huge then return "null" end
		return string.format("%.14g", v)
	end
	if tv == "boolean" then return tostring(v) end
	if tv == "table" then
		if seen[v] then return '"__CYCLE__"' end
		seen[v] = true
		local parts = {}
		local n = 0
		for k in pairs(v) do n = n + 1 end
		local isarr = n > 0 and #v == n
		if isarr then
			for i = 1, n do parts[i] = __JVS(v[i], seen) end
		else
			for k, v2 in pairs(v) do
				parts[#parts + 1] = __JVS(tostring(k), seen) .. ":" .. __JVS(v2, seen)
			end
		end
		seen[v] = nil
		local hasname = false
		if not isarr and n >= 12 then
			for k0 in pairs(v) do
				if type(k0) == "string" then hasname = true break end
			end
		end
		if hasname and __psig then
			local okp, sg = pcall(__psig, v)
			if okp and sg then parts[#parts + 1] = '"__sig":' .. tostring(sg) end
		end
		return (isarr and "[" or "{") .. table.concat(parts, ",") .. (isarr and "]" or "}")
	end
	return '"' .. tv .. '"'
end
__PIDS = setmetatable({}, { __mode = "k" })
__INV = setmetatable({}, { __mode = "k" })
__INVN = 0
__INVPROTO = {}
__PORDER = {}
__OPMAX = __OPMAX or 600000
-- clock guard: a busy loop that never reaches the loop-head probe (plain Lua code of the loader, spawned
-- inline by the mock task library) still polls the clock; past the armed deadline every poll raises
__RAWCLOCK = os.clock
__CLKDEADLINE = nil
do local __ro = os; os = {}; for k, v in pairs(__ro) do os[k] = v end end      -- (the library table is read-only)
-- virtual time: advances when the program waits (wait / task.wait), and slowly on a busy wait
__VT = 0
local __vtcalls = 0
function __VNOW()
	__vtcalls = __vtcalls + 1
	if __vtcalls > 5000 then __VT = __VT + 0.001 end
	return __VT
end
function __VADV(dt)
	dt = tonumber(dt) or 0
	if dt < 1 / 60 then dt = 1 / 60 end
	__VT = __VT + dt
	__vtcalls = 0
	return dt
end
os.clock = function()
	local t = __RAWCLOCK()
	local dl = __CLKDEADLINE
	if dl and t > dl then
		if __SWDEBUG and not __CLKSHOWN then
			__CLKSHOWN = true
			print('CLKGUARD fired' .. string.char(10) .. debug.traceback() .. string.char(10) .. string.rep('#', 200000))
		end
		error('luaq-clock-guard', 0)
	end
	-- the program sees a virtual clock (deterministic: identical in the original and the deobfuscated run)
	return 2000 + __VNOW()
end
__T0 = __RAWCLOCK()
-- os.time() (wall-clock seconds) is virtual once the program's own code runs (the loader keeps the real time for its
-- session checks): the original and the deobfuscated run must see the same values
local __realtime = os.time
os.time = function(t)
	if t == nil and __VTIME_ON then
		return 1790000000 + math.floor(__VT - (__VTIME_T0 or 0))
	end
	return __realtime(t)
end
__realerror_cap = error
__CURPID, __CURY, __CURJ = 0, 0, 0
__FORCE = __FORCE or {}
__BRCNT = {}
-- content signature of a proto (stable across replays): order-independent hash
-- of its long string fields (encrypted blobs); falls back to a counter
function __psig(x)
	local h, n = 0, 0
	for k, v in pairs(x) do
		if type(v) == "string" and #v >= 12 then
			local fh = #v
			for i = 1, 8 do fh = (fh * 131 + (string.byte(v, i) or 0)) % 4294967291 end
			h = (h + fh) % 4294967291
			n = n + 1
		end
	end
	if n == 0 then return nil end
	return h
end
__PIDN = 0
__UPROTO = {}
__LASTID, __LASTINV = nil, nil
__LEAVES = __LEAVES or {}
local __CAPTICK = 0
function __CAPTICKV() return __CAPTICK end
local function __cap_check()
	__CAPTICK = __CAPTICK + 1
	local sw = __SW
	if sw and sw.tickmax and __CAPTICK > sw.tickmax then
		-- the closure the driver is sweeping spins without making progress: a yield cannot be swallowed by a
		-- user-level pcall, the driver simply abandons the coroutine
		if coroutine.isyieldable() then coroutine.yield() end
		error('luaq-sweep-budget', 0)
	end
	if __SWDEBUG and __CAPTICK % 20000 == 0 then print("CAPTICK " .. __CAPTICK .. " ring=" .. __OPRINGN .. " max=" .. tostring(__OPMAX) .. " t=" .. (__RAWCLOCK() - (__T0 or 0)) .. " indump=" .. tostring(__INDUMP) .. string.char(10) .. string.rep("#", 5000)) end
	if __OPRINGN >= __OPMAX or (__CAPTICK % 2048 == 0 and __RAWCLOCK() - (__T0 or 0) > (__WALL or 25)) then
		if not __OPCAPPED then
			-- a user-level pcall can swallow our abort and loop forever: write the dump now
			__OPCAPPED = true
			print("OPCAP reached: dumping the trace and aborting")
			__INDUMP = true
			pcall(__FINALDUMP)
			print("=== DUMP COMPLETE ===")
			__INDUMP = false
		end
		__realerror_cap("luaq-opcap")
	end
end
-- resolve (proto id, invocation id, operand json) from candidate role variables; nil if invalid
local function __resolve(x, u, a, rown)
	local id, inv, aj = nil, nil, nil
	if type(u) == "table" then
		inv = __INV[u]
		if not inv then
			__INVN = __INVN + 1
			inv = __INVN
			__INV[u] = inv
		end
	end
	if type(x) == "table" then
		id = __PIDS[x]
		if not id then
			id = __psig(x)
			if id then
				__PIDS[x] = id
				if not __PROTOS[id] then
					__PROTOS[id] = x
					__PORDER[#__PORDER + 1] = id
					print("=== FIRST-SEEN PROTO id=" .. id .. " at=" .. rown)
					if (__SWUSER and __SWUSER[id]) or (not __SWUSER and __OPENED) then __UPROTO[id] = true end
				end
			end
		end
	end
	if __OPVJSON and type(a) == "table" then
		aj = __OPVJSON
	elseif type(a) == "table" then
		local ok, js = pcall(__JVS, a, {})
		if ok then aj = js elseif __SWDEBUG then print('JVSERR ' .. tostring(js)) end
	elseif __SWDEBUG and __SWEEP then print('NOATABLE ' .. type(a) .. ' ' .. tostring(rown)) end
	return id, inv, aj
end
-- loop-head probe (global role names): runs on every dispatch iteration, only exec-leaf
-- iterations make a row
function __OPH(y, M, g, x, u, a)
	if __OPENED and not __VTIME_ON then __VTIME_ON = true; __VTIME_T0 = __VT end
	if __SWDEBUG and __SW and __SW.dbg then print("ITER g=" .. tostring(g) .. " y=" .. tostring(y) .. " leaf=" .. tostring(__LEAVES[g] and true or false)) end
	if __QUIET or __INDUMP then return end
	__cap_check()
	if not __LEAVES[g] then return end
	__OPRINGN = __OPRINGN + 1
	local id, inv, aj = __resolve(x, u, a, __OPRINGN)
	if id and x ~= nil then
		local wc = __CHILDWAIT[x]
		if wc then __CHILDWAIT[x] = nil; print('CLCHILD ' .. wc .. ' ' .. id) end
	end
	if inv and id then __INVPROTO[inv] = id end
	if inv and not id then id = __INVPROTO[inv] end
	if id then __LASTID = id end
	if inv then __LASTINV = inv end
	__CURPID, __CURY, __CURJ = id or __LASTID or 0, y or 0, 0
	__PLAST[__CURPID] = y
	local row = { n = __OPRINGN, la = id or __LASTID, y = y, M = M, g = g, a = aj or "null", r = "",
		inv = inv or __LASTINV, okid = id ~= nil, okinv = inv ~= nil, oka = aj ~= nil }
	__ALLTRACE = __ALLTRACE or {}
	__ALLTRACE[__OPRINGN] = row
	__CURROW = row
	__LASTU = u
	if __SWEEP then __SWSTEP(row) end
end
-- constant fetch probe: `helper(proto, index, state)` ran, so the constant exists; if the decoded pool of the
-- proto has no entry for it afterwards, it is nil (printed once per proto and index)
__CFSEEN = {}
function __CF(v, x, k)
	if __QUIET or __INDUMP or type(x) ~= 'table' or type(k) ~= 'number' then return v end
	local id = __PIDS[x]
	if not id then return v end
	local seen = __CFSEEN[id]
	if not seen then seen = {}; __CFSEEN[id] = seen end
	if not seen[k] then seen[k] = true; print('CFETCH ' .. id .. ' ' .. k) end
	return v
end
-- closure registry: the VM wrapper of every closure created after the DRM handshake is
-- registered (__NEWCL) and marked when entered (__ENTER); a replay with __EXERCISE calls the
-- ones the program never ran, so their bodies get traced too
__ALLCL = {}
__ENTERED = setmetatable({}, { __mode = "k" })
__CLN = 0
__CLID = setmetatable({}, { __mode = "k" })
__CLCREATOR = setmetatable({}, { __mode = "k" })
__CLSITE = setmetatable({}, { __mode = "k" })
__PLAST = {}
function __NEWCL(f, cproto, cindex)
	if __OPENED and not __INDUMP then
		__CLN = __CLN + 1
		__CLID[f] = __CLN
		-- the creator is the proto the factory was handed, and the pc its latest instruction: a fused handler may run other
		-- protos before it creates the closure, so the last row executed overall is not the creating one
		local cpid, cy = __CURPID, __CURY
		if type(cproto) == 'table' and __PIDS[cproto] then cpid = __PIDS[cproto]; cy = __PLAST[cpid] or cy end
		__CLCREATOR[f] = cpid
		__CLSITE[f] = tostring(cpid) .. ':' .. tostring(cy)
		-- creator (proto, pc), trace position and child index: lets the tool link the closure to its body
		print("CLNEW " .. __CLN .. " " .. tostring(cpid) .. " " .. tostring(cy) .. " " .. __OPRINGN .. " " .. tostring(type(cindex) == 'number' and cindex or 'nil'))
		if #__ALLCL < 2000 then __ALLCL[#__ALLCL + 1] = f end
	end
end
-- the wrapper of closure `f` has just decoded the child proto it runs; its id is only known at the child's first row
__CHILDWAIT = setmetatable({}, { __mode = 'k' })
function __CHILD(f, child)
	if __QUIET or __INDUMP or type(child) ~= 'table' then return end
	local cid = __CLID[f]
	if not cid then return end
	__CHILDWAIT[child] = cid
	print('CLCHILD ' .. cid .. ' -')
end
-- (static sweep) the version of a closure that the program gets: inside a driven call its errors do not reach the caller
function __SAFECL(q)
	if not __SWEEP then return q end
	return function(...)
		local sw = __SW
		if not (sw and sw.driving) then return q(...) end
		local r = table.pack(pcall(q, ...))
		if r[1] then return table.unpack(r, 2, r.n) end
		return __DUMMY
	end
end
function __ENTER(f)
	__ENTERED[f] = true
	if __SWEEP and __SW then
		__SW.entering = __CLCREATOR[f]
		__SW.maybe = f                      -- is this the program's own wrapper? decided at its first row
	end
	local id = __CLID[f]
	if id and not __INDUMP then print("CLENTER " .. id .. " " .. __OPRINGN) end
end
-- ===================================================================================
-- static sweep: decode EVERY instruction of every user proto with the VM's own decoder.
-- The program is not run: its registers are dummies, the pc is steered to the next
-- instruction nobody has decoded yet at every pc assignment, global writes are dropped.
-- ===================================================================================
local __SWD = {}
do
	local mt = {}
	mt.__index = function(t, k) if k == "n" then return 0 end return __SWD end
	mt.__newindex = function() end
	mt.__call = function() return __SWD end
	local ret = function() return __SWD end
	for _, ev in ipairs({ "__add", "__sub", "__mul", "__div", "__mod", "__pow", "__idiv", "__concat", "__unm" }) do
		mt[ev] = ret
	end
	mt.__lt = function() return false end
	mt.__le = function() return false end
	mt.__len = function() return 1 end      -- `for i = 1, #<dummy>` runs its body once (its constants get decoded)
	mt.__tostring = function() return "<dummy>" end
	-- `for k, v in <dummy>`: one iteration, so that the body of the loop is decoded
	mt.__iter = function() local n = 0; return function() n = n + 1; if n <= 1 then return __SWD, __SWD end end end
	__RSM(__SWD, mt)
end
__DUMMY = __SWD
-- library functions called with dummy values inside a driven closure must not raise (a `math.floor(<dummy>)` in a
-- callee would end the whole call, and with it every instruction behind the caller's call site)
local __SWSAFECACHE = {}
function __SWSAFEWRAP(lib, dflt, name)
	local c = __SWSAFECACHE[name]
	if c and c.src == lib then return c.out end
	local out = {}
	for k2, fn in pairs(lib) do
		if type(fn) == 'function' then
			out[k2] = function(...)
				local sw = __SW
				if not (sw and sw.driving) then return fn(...) end
				local r = table.pack(pcall(fn, ...))
				if r[1] then return table.unpack(r, 2, r.n) end
				if dflt == nil then return __SWD end
				return dflt
			end
		else
			out[k2] = fn
		end
	end
	__SWSAFECACHE[name] = { src = lib, out = out }
	return out
end
if __SWEEP then
	local rpairs, ripairs, rwrap, rcreate = pairs, ipairs, coroutine.wrap, coroutine.create
	local co = {}
	for k2, v2 in pairs(coroutine) do co[k2] = v2 end
	co.wrap = function(f) if type(f) ~= 'function' then f = function() end end return rwrap(f) end
	co.create = function(f) if type(f) ~= 'function' then f = function() end end return rcreate(f) end
	__SWSAFE = {
		pairs = function(t, ...)
			if type(t) == 'table' and t ~= __SWD then return rpairs(t, ...) end
			return function(_, k) if k == nil then return 1, __SWD end end, t, nil
		end,
		ipairs = function(t)
			if type(t) == 'table' and t ~= __SWD then return ripairs(t) end
			return function(_, i) if i == 0 then return 1, __SWD end end, t, 0
		end,
		coroutine = co,
		-- code fetched from the web is not run while a closure is driven: it yields the dummy (a library object)
		loadstring = function(src, ...)
			if __SW and __SW.driving then return function() return __SWD end end
			return loadstring(src, ...)
		end,
	}
end
local __SWREGMT = { __index = function() return __SWD end, __newindex = function(t, k, v) rawset(t, k, __SWD) end }
local __SWSAND = setmetatable({}, { __mode = "k" })
__SW = { protos = {}, nextpc = nil, row = nil, pid = nil, curf = nil, fpid = setmetatable({}, { __mode = "k" }),
	main = setmetatable({}, { __mode = "k" }) }

function __SWSTEP(row)
	local sw = __SW
	if not row or row.swok then return end
	local pid = row.la
	-- the wrapper the loader enters first with a known user proto is the program's main closure
	if sw.maybe and pid and pid ~= sw.entering then
		if __UPROTO[pid] then sw.main[sw.maybe] = true end
		sw.maybe = nil
	end
	-- a closure created by user code is user code: classify its proto at its first row
	if sw.entering and pid and pid ~= sw.entering then
		if __UPROTO[sw.entering] and not __UPROTO[pid] then __UPROTO[pid] = true end
		sw.entering = nil
	end
	if not pid or not __UPROTO[pid] then
		sw.row, sw.nextpc = nil, nil
		return
	end
	local x = __PROTOS[pid]
	if type(x) ~= "table" or not row.y then return end
	row.swok = true
	local ent = sw.protos[pid]
	if not ent then
		-- the targets come from the tool: the pcs of this proto it has not decoded yet
		local pcs = {}
		local want = {}
		for _, t in ipairs((__SWT and __SWT[pid]) or {}) do
			if not want[t] then want[t] = true; pcs[#pcs + 1] = t end
		end
		table.sort(pcs)
		ent = { pcs = pcs, visited = {}, want = want, left = #pcs, ptr = 1, n = #pcs }
		sw.protos[pid] = ent
		print("SWEEPPROTO " .. pid .. " " .. #pcs)
	end
	if sw.curf then sw.fpid[sw.curf] = pid; sw.curf = nil end
	if not ent.visited[row.y] then
		ent.visited[row.y] = true
		if ent.want[row.y] then ent.left = ent.left - 1 end
	end
	while ent.pcs[ent.ptr] ~= nil and ent.visited[ent.pcs[ent.ptr]] do ent.ptr = ent.ptr + 1 end
	sw.row, sw.pid, sw.ent = row, pid, ent
	-- an invocation of a finished proto is cut short (-7 is no instruction): nothing new to decode
	sw.nextpc = ent.pcs[ent.ptr] or -7
end

-- after a pc assignment: a natural successor nobody has decoded yet is followed (the VM only accepts
-- the instruction pointers it reaches through real control flow in some cases); otherwise the pc is
-- redirected to the next instruction still to decode.  Absolute targets (hashed jumps) are reported.
local function __swsite(v, absolute)
	if __SWNOREDIR then return v end
	local sw, row = __SW, __CURROW
	if row and not row.swok then __SWSTEP(row) end
	if sw.row == row and sw.nextpc then
		if absolute and type(v) == "number" then
			print("SWEEPPC " .. tostring(sw.pid) .. " " .. tostring(row.y) .. " " .. v)
		end
		local ent = sw.ent
		if type(v) == "number" and ent and not ent.visited[v + 1] and v + 1 ~= row.y then
			return v                                  -- follow the natural edge into new code
		end
		if __SWDEBUG then print("SWNEXT " .. tostring(sw.pid) .. " " .. tostring(row.y) .. " natural=" .. tostring(v) .. " -> " .. tostring(sw.nextpc)); sw.dbg = true end
		return sw.nextpc - 1
	end
	return v
end
function __PCWA(v) return __swsite(v, true) end
function __PCWR(v) return __swsite(v, false) end
function __PCW0(v)
	return v
end

-- the closures the program creates are decoded too: call each (dummy arguments) until nothing is left
function __SWDRIVE()
	local sw = __SW
	local t_end = __RAWCLOCK() + (__SWBUDGET or 900)
	local function total_left()
		local n = 0
		for _, e in pairs(sw.protos) do n = n + e.left end
		return n
	end
	local rounds = 0
	local progress = true
	while progress and __RAWCLOCK() < t_end and rounds < 5000 do
		progress = false
		rounds = rounds + 1
		local i = 1
		while i <= #__ALLCL and __RAWCLOCK() < t_end do
			local f = __ALLCL[i]
			local pid = sw.fpid[f]
			local ent = pid and sw.protos[pid]
			local mine = sw.main[f] or __UPROTO[__CLCREATOR[f] or 0]       -- only the program's own closures
			sw.nofail = sw.nofail or {}
			local site = __CLSITE[f]
			if mine and not (ent and ent.left <= 0) and not (site and (sw.nofail[site] or 0) >= 3) then
				local before = total_left()
				local nproto = 0
				for _ in pairs(sw.protos) do nproto = nproto + 1 end
				sw.curf = f
				__OPMAX = __OPRINGN + 400000
				__CLKDEADLINE = __RAWCLOCK() + (__SWCALLSECS or 4)
				sw.driving = true
				sw.tickmax = __CAPTICKV() + (__SWTICKS or 150000)
				local co = coroutine.create(f)
				local rok, rerr = coroutine.resume(co, __SWD, __SWD, __SWD)
				if not rok and __SWDEBUG then print('SWERR closure=' .. tostring(__CLID[f]) .. ' pid=' .. tostring(sw.fpid[f]) .. ' ' .. debug.traceback(co, tostring(rerr))) end
				sw.tickmax = nil
				sw.driving = nil
				__CLKDEADLINE = nil
				sw.curf = nil
				local nproto2 = 0
				for _ in pairs(sw.protos) do nproto2 = nproto2 + 1 end
				if total_left() < before or nproto2 > nproto then
					progress = true
					if site then sw.nofail[site] = 0 end
				elseif site then
					sw.nofail[site] = (sw.nofail[site] or 0) + 1
				end
			end
			i = i + 1
		end
	end
	local left = 0
	for pid, e in pairs(sw.protos) do
		left = left + e.left
		print("SWEEPDONE " .. pid .. " " .. e.n .. " " .. e.left)
	end
	print("SWEEP FINISHED rounds=" .. rounds .. " left=" .. left)
	if __SWDEBUG then
		local noany, tot = {}, 0
		for n_, r_ in pairs(__ALLTRACE or {}) do
			if r_.y and r_.la and __UPROTO[r_.la] then
				tot = tot + 1
				if not r_.anyseen then noany[#noany + 1] = tostring(r_.la) .. ':' .. tostring(r_.y) end
			end
		end
		print('NOANY ' .. #noany .. ' of ' .. tot .. ' user rows: ' .. table.concat(noany, ' ', 1, math.min(#noany, 60)))
	end
end

-- handler-start probe (roles as this handler names them): completes what the loop head could not
local __OPANY_core
function __OPANY(x, u, a)
	if __CURROW then __CURROW.anyseen = true end
	__OPANY_core(x, u, a)
	if __SWEEP then
		__SWSTEP(__CURROW)
		-- only the registers of user protos become dummies: the loader must keep working
		-- (the register table is the one the dispatch loop itself names: the roles of a single handler may be permuted)
		local ru = __LASTU
		if __SW.row == __CURROW and __CURROW and type(ru) == "table" and not __SWSAND[ru] and not __SWNOSAND and getmetatable(ru) == nil then
			__SWSAND[ru] = true
			__RSM(ru, __SWREGMT)
		end
	end
end
__OPANY_core = function(x, u, a)
	if __QUIET or __INDUMP then return end
	local row = __CURROW
	if not row then return end
	if row.okid and row.okinv and row.oka then return end
	local id, inv, aj = __resolve(x, u, a, row.n)
	if inv and id then __INVPROTO[inv] = id end
	if inv and not id then id = __INVPROTO[inv] end
	if id and not row.okid then
		row.la = id
		__LASTID = id
		row.okid = true
	end
	if inv and not row.okinv then
		row.inv = inv
		__LASTINV = inv
		row.okinv = true
	end
	if aj and not row.oka then
		row.a = aj
		row.oka = true
	end
	__CURPID = row.la or __CURPID
end
-- (Luaq 2.5) operand probe: right after a handler's decode prologue.  The operand table's numeric entries and the
-- handler's operand locals (keys 90001, 90002, ...) form the operand row of the instruction
function __OPV(t, ...)
	if __QUIET or __INDUMP then return end
	local a = {}
	if type(t) == "table" then
		for k, v in pairs(t) do
			if type(k) == "number" then a[k] = v end
		end
	end
	local n = select("#", ...)
	for i = 1, n do
		local v = select(i, ...)
		if v ~= nil then a[90000 + i] = v end
	end
	-- always an object: a sparse table whose border happens to equal its key count would pass for an array
	local parts = {}
	for k, v in pairs(a) do
		local ok, js = pcall(__JVS, v, {})
		parts[#parts + 1] = '"' .. string.format("%d", k) .. '":' .. (ok and js or "null")
	end
	__OPVJSON = "{" .. table.concat(parts, ",") .. "}"
	__OPANY(nil, nil, a)
	__OPVJSON = nil
end
-- branch hook: wraps the condition of every handler `if` that moves the pc.
-- With a force table entry the decision is inverted (replay-time exploration).
function __BR(c)
	-- a fused handler may loop on its own (a user-level `while true`): count its branches like loop heads
	if not (__QUIET or __INDUMP) then __cap_check() end
	local j = __CURJ + 1
	__CURJ = j
	local f = __FORCE
	if f ~= nil then
		local key = __CURPID .. ":" .. __CURY .. ":" .. j
		local want = f[key]
		if want then
			local cnt = (__BRCNT[key] or 0) + 1
			__BRCNT[key] = cnt
			if want == true or want == cnt then
				print("BRFLIP " .. key .. " #" .. cnt)
				return not c
			end
		end
	end
	return c
end
-- same decision inversion as __BR for code that is not running inside the VM (deobfuscated
-- test variants): the key names the branch explicitly
function __BRF(key, c)
	local f = __FORCE
	if f ~= nil then
		local want = f[key]
		if want then
			local cnt = (__BRCNT[key] or 0) + 1
			__BRCNT[key] = cnt
			if want == true or want == cnt then
				return not c
			end
		end
	end
	return c
end
function __OPANY2(...)
	if __QUIET then return end
	local xs = { ... }
	local parts = {}
	for i = 1, #xs do
		local v = xs[i]
		local tv = type(v)
		if tv == "table" then
			if v.La ~= nil then
				parts[#parts + 1] = "P" .. tostring(v.La)
				if not __SEENLA[v.La] then
					__SEENLA[v.La] = true
					__PROTOS[v.La] = v
					print("=== FIRST-SEEN PROTO La=" .. tostring(v.La))
					__DUMPPROTO(v)
				end
			else
				parts[#parts + 1] = "T" .. __JVS(v, {})
			end
		elseif tv == "number" then
			parts[#parts + 1] = "N" .. string.format("%.14g", v)
		elseif tv == "string" then
			parts[#parts + 1] = "S" .. __JVS(v, {})
		else
			parts[#parts + 1] = tv:sub(1, 1)
		end
	end
	__OPRINGN = __OPRINGN + 1
	local ent = { n = __OPRINGN, la = nil, y = nil, M = nil, g = nil, a = table.concat(parts, " "), r = "" }
	__ALLTRACE = __ALLTRACE or {}
	__ALLTRACE[__OPRINGN] = ent
end
function __OPDUMP(msg)
	print("=== OPRING DUMP (" .. tostring(msg) .. ") ===")
	local ring = __OPRING
	local start = (__OPRINGN - 1) % 900
	-- find index of the last entry that entered proto 4114987194
	local cut = nil
	for i = 0, 899 do
		local e = ring[(start - i) % 900]
		if not e then break end
		if e.la == 4114987194 then cut = i end
	end
	local from = 0
	if cut then from = math.min(cut + 120, 899) end
	for i = from, 0, -1 do
		local e = ring[(start - i) % 900]
		if not e then break end
		local mark = e.enter and (">> ENTER La=" .. tostring(e.la)) or ("   La=" .. tostring(e.la))
		print(string.format("OP%d %s y=%s M=%s | %s", e.n, mark, tostring(e.y), tostring(e.M), e.r))
	end
end
function __OPLOG(y, M, u)
	__OPN = __OPN + 1
	if __OPFORCE and type(u) == "table" then
		-- force suspected verdict registers (mock-env bypass for proto 411)
		u[4] = true; u[15] = true; u[32] = true
	end
	local parts = {}
	if type(u) == "table" then
		for i = 1, 44 do
			local v = u[i]
			if v ~= nil then
				parts[#parts + 1] = i .. "=" .. type(v):sub(1, 1) .. tostring(v):sub(1, 22)
			end
		end
	end
	print("OP411 " .. __OPN .. " y=" .. tostring(y) .. " M=" .. tostring(M) .. " | " .. table.concat(parts, " "))
end
function __ERRCALL(y, M, E, x, u)
	print("ERRCALL y=" .. tostring(y) .. " M=" .. tostring(M) .. " E=" .. tostring(E)
		.. " La=" .. tostring(type(x) == "table" and x.La or nil))
	if type(x) == "table" and type(x.La) == "number" then __PTALL[x.La] = x end
	local __anymsg
	if type(u) == "table" then
		for _i = 1, 44 do
			if type(u[_i]) == "string" and u[_i]:sub(1, #"Luaq stream") == "Luaq stream" then
				__anymsg = u[_i]
				break
			end
		end
	end
	if type(x) == "table" and __anymsg and type(x.V) == "table" then
		local vs = {}
		local vk = {}
		for k in pairs(x.V) do vk[#vk + 1] = k end
		table.sort(vk, function(a2, b2)
			if type(a2) == "number" and type(b2) == "number" then return a2 < b2 end
			return tostring(a2) < tostring(b2)
		end)
		for _, k in ipairs(vk) do
			local v = x.V[k]
			vs[#vs + 1] = tostring(k) .. "=" .. (type(v) == "string" and (string.format("%q", v):sub(1, 80)) or tostring(v):sub(1, 40))
		end
		print("VCONST La=" .. tostring(x.La) .. " n=" .. #vs .. " {" .. table.concat(vs, " ") .. "}")
	end
	local parts = {}
	for i = 1, 60 do
		if u[i] ~= nil then parts[#parts + 1] = i .. "=" .. type(u[i]) .. ":" .. tostring(u[i]):sub(1, 24) end
	end
	print("ERRCALL regs " .. table.concat(parts, " "))
end
function __DUMPPROTO(t)
	print("PROTO La=" .. tostring(t.La) .. " Ly=" .. tostring(t.Ly) .. " Lx=" .. tostring(t.Lx) .. " LE=" .. tostring(t.LE))
	for _, nm in ipairs({ "LL", "Lh", "Lu", "P", "V", "Y", "Z", "e", "D" }) do
		local v = t[nm]
		if type(v) == "table" then
			local keys = {}
			for k in pairs(v) do keys[#keys + 1] = k end
			table.sort(keys)
			local parts = {}
			for _, k in ipairs(keys) do
				local val = v[k]
				local s
				if type(val) == "string" then s = string.format("%q", val):sub(1, 70)
				else s = tostring(val):sub(1, 40) end
				parts[#parts + 1] = tostring(k) .. "=" .. s
			end
			print("PROTO." .. nm .. " n=" .. #keys .. " {" .. table.concat(parts, " ", 1, math.min(#parts, 60)) .. "}")
		end
	end
end
__MYERR = function(msg, lvl)
	if __SWALLOWALL then
		print("SWALLOW-ERR: " .. (type(msg) == "string" and msg or ("{" .. tostring(msg) .. "}")))
		if type(msg) == "string" and msg:sub(1, #"Luaq stream") == "Luaq stream" then
			for i = 2, 8 do
				local info = debug.getinfo(i, "nSl")
				if not info then break end
				print("SERRFRAME " .. i .. " " .. tostring(info.what) .. " " .. tostring(info.source) .. ":" .. tostring(info.currentline) .. " " .. tostring(info.name))
				if info.what == "Lua" or info.what == "main" then
					for li = 1, 30 do
						local nm, val = debug.getlocal(i, li)
						if not nm then break end
						local tv = type(val)
						if tv == "string" then
							if #val <= 120 then
								print("  SLOC " .. nm .. " S" .. #val .. " " .. string.format("%q", val))
							else
								print("  SLOC " .. nm .. " S" .. #val .. " " .. string.format("%q", val:sub(1, 80)) .. "...")
							end
						elseif tv == "number" then
							print("  SLOC " .. nm .. " N " .. tostring(val))
						else
							print("  SLOC " .. nm .. " " .. tv)
						end
					end
				end
			end
		end
		return nil
	end
	if type(msg) == "string" and msg:sub(1, #"Luaq stream") == "Luaq stream" then
		print("TRANSPORT/CHALLENGE bypassed (error swallowed): " .. tostring(msg))
		if msg == "Luaq stream transport response" or msg == "Luaq stream challenge"
			or msg == "Luaq stream raw envelope header" or msg == "Luaq stream authentication"
			or msg == "Luaq image length" then
			__OPDUMP(msg)
		end
		return nil
	end
	if type(msg) == "string" and msg:find("integrity", 1, true) then
		print("INTEGRITY-CHECK bypassed (error swallowed): " .. tostring(msg))
		return nil
	end
	if type(msg) == "string" and msg:find("integrity", 1, true) then
		local dl = debug and debug.getinfo
		if dl then
			for i = 2, 12 do
				local info = dl(i, "Snlf")
				if not info then break end
				print("ERRSTACK " .. i .. " src=" .. tostring(info.source):sub(1, 60)
					.. " cur=" .. tostring(info.currentline) .. " what=" .. info.what)
			end
		end
	end
	if msg == "Luaq stream transport integrity" then
		__OPDUMP("transport-integrity")
		local ks = {}
		for k in pairs(__PTALL) do ks[#ks + 1] = k end
		table.sort(ks)
		print("PTALL n=" .. #ks .. " {" .. table.concat(ks, ",") .. "}")
	end
	if msg == "Luaq stream transport integrity" and type(__PTALL[4114987194]) == "table" then
		__DUMPPROTO(__PTALL[4114987194])
		-- raw Z packet contents for static decode
		for _, la in ipairs({ 4114987194, 2965204551, 2940371000 }) do
			local p = __PTALL[la]
			if type(p) == "table" then
				local vs = {}
				if type(p.V) == "table" then
					local vk = {}
					for k in pairs(p.V) do vk[#vk + 1] = k end
					table.sort(vk, function(a2, b2)
						if type(a2) == "number" and type(b2) == "number" then return a2 < b2 end
						return tostring(a2) < tostring(b2)
					end)
					for _, k in ipairs(vk) do
						local v = p.V[k]
						vs[#vs + 1] = tostring(k) .. "=" .. (type(v) == "string" and (string.format("%q", v):sub(1, 60)) or tostring(v):sub(1, 40))
					end
				end
				print("VCONST la=" .. la .. " n=" .. #vs .. " {" .. table.concat(vs, " ") .. "}")
			end
			if type(p) == "table" and type(p.Z) == "table" then
				local keys = {}
				for k in pairs(p.Z) do keys[#keys + 1] = k end
				table.sort(keys)
				for _, k in ipairs(keys) do
					local w = p.Z[k]
					if type(w) == "table" then
						local fields = {}
						local fk = {}
						for f in pairs(w) do fk[#fk + 1] = f end
						table.sort(fk, function(a2, b2)
							if type(a2) == "number" and type(b2) == "number" then return a2 < b2 end
							return tostring(a2) < tostring(b2)
						end)
						for _, f in ipairs(fk) do
							local v = w[f]
							local s
							if type(v) == "table" then
								local inner = {}
								for i = 1, 8 do
									if v[i] == nil then break end
									inner[#inner + 1] = tostring(v[i])
								end
								s = "T{" .. table.concat(inner, ",") .. "}n" .. #v
							else
								s = tostring(v)
							end
							fields[#fields + 1] = tostring(f) .. "=" .. s:sub(1, 60)
						end
						print("PKT la=" .. la .. " k=" .. tostring(k) .. " " .. table.concat(fields, " "))
					end
				end
			end
		end
	end
	if msg ~= "attempt to call a luaq value" then
		print("ERROR-SITE: " .. tostring(msg) .. " :: " .. tostring(debug.traceback("", 2)))
		if msg:find("capsule") and debug.getinfo then
			-- dump locals of the erroring frame(s) to see the computation state
			local lvl = 2
			while true do
				local info = debug.getinfo(lvl, "nSl")
				if not info then break end
				if info.what == "Lua" then
					local parts = {}
					local i = 1
					while true do
						local nm, v = debug.getlocal(lvl, i)
						if not nm then break end
						local desc = type(v) .. ":" .. tostring(v):sub(1, 60)
						if type(v) == "table" then
							local parts2 = {}
							for kk = 1, 8 do
								local vv = rawget(v, kk)
								if vv ~= nil then
									parts2[#parts2 + 1] = tostring(vv):sub(1, 24)
								end
							end
							desc = desc .. " n=" .. tostring(rawget(v, "n") or #v) .. " [" .. table.concat(parts2, ",") .. "]"
						elseif type(v) == "number" then
							desc = desc .. " (" .. tostring(v) .. ")"
						end
						parts[#parts + 1] = nm .. "=" .. desc
						i = i + 1
						if i > 40 then break end
					end
					print("ERRFRAME " .. lvl .. " " .. tostring(info.currentline) .. " " .. table.concat(parts, " | "))
				end
				lvl = lvl + 1
				if lvl > 12 then break end
			end
		end
	end
	if __BYPASSCAPSULE and type(msg) == "string" and msg:sub(1, 5) == "Luaq " then
		print("LUAQ ERROR BYPASSED: " .. msg)
		return nil
	end
	return __realerror(msg, lvl)
end
error = __MYERR
-- capture: log rawequal comparisons (auth check uses rawequal)
do
	local __rerawequal = rawequal
	local __rerawsaw = 0
	rawequal = function(a, b)
		local r = __rerawequal(a, b)
		if not r and __rerawsaw < 4000 then
			__rerawsaw = __rerawsaw + 1
			local da, db = tostring(a), tostring(b)
			if type(a) == "string" then da = #a .. ":" .. string.format("%q", a:sub(1, 40)) end
			if type(b) == "string" then db = #b .. ":" .. string.format("%q", b:sub(1, 40)) end
			print("RAWEQ-FALSE " .. type(a) .. " " .. da .. " vs " .. type(b) .. " " .. db)
		end
		return r
	end
end
--__CHALLENGE_INJECT__
__CHALLENGERESP = __CHALLENGERESP or ""
__OPENRESP = __OPENRESP or ""
local function __httpmock(opts)
	local url = type(opts) == "table" and (opts.Url or opts.url) or opts
	local body = type(opts) == "table" and (opts.Body or opts.body) or nil
	print("HTTP-MOCK: url=" .. tostring(url) .. " method=" .. tostring(type(opts) == "table" and (opts.Method or opts.method)) .. " body=" .. tostring(body and #body or 0))
	if type(opts) == "table" then
		local h2 = opts.Headers or opts.headers
		if type(h2) == "table" then
			for k2, v2 in pairs(h2) do print("HTTP-HDR " .. tostring(k2) .. "=" .. tostring(v2)) end
		end
	end
	local function __ok(b)
		return {
			Success = true, StatusCode = 200, StatusMessage = "OK", StatusLine = "HTTP/1.1 200 OK",
			Body = b, Headers = { ["Content-Type"] = "application/json", ["content-type"] = "application/json" },
			ResponseUri = url, responseEncoding = "raw-indexed-v1", HttpError = nil,
		}
	end
	if type(url) == "string" and url:find("/v4/session/challenge", 1, true) then
		if __CHALLENGERESP ~= "" then
			return __ok(__CHALLENGERESP)
		end
		print("CHALLENGEREQ " .. tostring(body))
	end
	if type(url) == "string" and url:find("/v4/session/open", 1, true) then
		print("OPENREQ " .. tostring(body))
			print("MARK open at=" .. (__OPRINGN + 1))
			__OPENED = true
			math.randomseed(777)
		if __OPENRESP ~= "" then
			return __ok(__OPENRESP)
		end
	end
	return { Success = false, StatusCode = 0, Body = "", Headers = {} }
end
request = __httpmock
http_request = __httpmock
http = { request = __httpmock, get = function(u2) return __httpmock(u2) end, post = function(u2, b2, h2) return __httpmock({ Url = u2, Body = b2, Headers = h2 }) end }
-- Lua 5.2-style hosts fetch HTTP via luasocket-style require()
local function __lsreq(t, body)
	local url = type(t) == "table" and (t.url or t.Url) or t
	local meth = type(t) == "table" and (t.method or t.Method) or nil
	local hdrs = type(t) == "table" and (t.headers or t.Headers) or nil
	local reqbody = body
	if type(t) == "table" then
		if type(t.body) == "string" then
			reqbody = t.body
		elseif type(t.source) == "function" then
			local chunks = {}
			while true do
				local c = t.source()
				if c == nil or c == false then break end
				chunks[#chunks + 1] = tostring(c)
			end
			reqbody = table.concat(chunks)
		elseif type(t.source) == "string" then
			reqbody = t.source
		end
	end
	local resp = __httpmock({ Url = url, Method = meth, Headers = hdrs, Body = reqbody })
	local rbody = resp.Body or ""
	if type(t) == "table" and type(t.sink) == "function" then
		t.sink(rbody)
		return 1, resp.StatusCode, resp.Headers
	end
	return rbody, resp.StatusCode, resp.Headers
end
__LSHTTP = { request = __lsreq, get = function(u2) local b2 = __lsreq(u2) return b2 end }
__MIRROR = setmetatable({}, {
	__index = function() return __MIRROR end,
	__len = function() return 0 end,
	__call = function() return __MIRROR end,
	__concat = function() return "" end,
	__tostring = function() return "" end,
})
__LTN12 = {
	sink = {
		table = function(t) return function(chunk) if chunk then t[#t + 1] = chunk end return true end end,
		null = function() return function() return true end end,
	},
	source = {
		string = function(s) local done2 = false return function() if done2 then return nil end done2 = true return s end end,
		empty = function() return function() return nil end end,
	},
}
require = function(name)
	print("REQUIRE-MOCK " .. tostring(name))
	if name == "socket.http" or name == "ssl.https" or name == "http" then
		return __LSHTTP
	end
	if name == "socket" then
		return { http = __LSHTTP, url = {}, tcp = function() return {
			connect = function() return nil, "connection refused" end,
			send = function() return true end,
			receive = function() return nil, "closed" end,
			close = function() end,
			settimeout = function() return 1 end,
		} end, udp = function() return { setsockname = function() end, setpeername = function() end, send = function() return 1 end, receive = function() return nil end, close = function() end } end, bind = function() return nil end, gettime = os.time, sleep = function() end }
	end
	if name == "ssl" then
		return { https = __LSHTTP, wrap = function(t) return t end, newcontext = function() return {} end }
	end
	if name == "ltn12" then
		return __LTN12
	end
	if name == "cjson.safe" or name == "cjson" then
		local function __wraplog(v, nm, depth)
			if depth > 4 then return v end
			if type(v) == "table" then
				return setmetatable({}, { __index = function(_, k)
					print("RESPKEY " .. nm .. "." .. tostring(k) .. " -> " .. type(v[k]))
					return __wraplog(v[k], nm .. "." .. tostring(k), depth + 1)
				end })
			end
			return v
		end
		return { encode = __jsonencode, decode = function(s)
			if s == nil or s == "" then return __MIRROR end
			local ok, r = pcall(__jsondecode, s)
			if ok then return __wraplog(r, "resp", 0) end
			return __MIRROR
		end }
	end
	if name == "socket.url" then
		return {}
	end
	return nil
end
function getfenv(lvl)
	-- a level beyond the stack is an error in real Luau; tamper checks probe getfenv(69).
	-- (declared as `function getfenv` so that debug.info(getfenv, "n") is "getfenv" like the builtin)
	if type(lvl) == "number" and lvl > 40 then
		error("invalid argument #1 to 'getfenv' (level out of range)", 2)
	end
	return __PROXY
end
-- executor API that tamper checks query: an untouched environment answers "not hooked", "ours"
isfunctionhooked = function() return false end
hookfunction = function(f) return f end
checkcaller = function() return true end
islclosure = function(f) return true end
iscclosure = function(f) return false end

-- capture lazy V/Z decodes: wrap metatable __index functions and record reads
__MTREG = {}
local __realsetmt = setmetatable
setmetatable = function(t, mt)
	local done = __realsetmt(t, mt)
	if type(mt) == "table" and type(rawget(mt, "__index")) == "function" and not mt.__hooked then
		local orig = rawget(mt, "__index")
		local rec = { n = 0, vals = {} }
		__MTREG[mt] = rec
		rawset(mt, "__index", function(tt, k)
			local v = orig(tt, k)
			if rec.n < 6000 then
				rec.n = rec.n + 1
				rec.vals[tostring(k)] = type(v) .. ":" .. tostring(v):sub(1, 120)
			end
			return v
		end)
		rawset(mt, "__hooked", true)
	end
	return done
end
__FINALDUMP = function()
	if __QUIET then return end
	if __SWEEP then
		-- nothing of the program may run from here on: not the callbacks it connected, not its functions,
		-- also not when the dump was started by the op/wall cap in the middle of the driver
		local drive = not __INDUMP
		__CONNECTED, __GFUNCS, __SAMPLERETS = {}, {}, {}
		if drive then __SWDRIVE() end
	end
	print("=== CALLBACK INVOCATIONS ===")
	-- arguments of a signal's callback by the signal name (numbers where Roblox passes numbers)
	function __CBARGS(path)
		local sig = tostring(path):match("([%w_]+)%.Connect$") or tostring(path):match("([%w_]+)%.[%w_]+$") or ""
		if sig == "Heartbeat" or sig == "RenderStepped" or sig == "PreRender" or sig == "PostSimulation"
			or sig == "PreSimulation" or sig == "PreAnimation" then
			return 1 / 60
		end
		if sig == "Stepped" then return 1, 1 / 60 end
		if sig == "InputBegan" or sig == "InputEnded" or sig == "InputChanged" or sig == "TouchStarted" then
			return __mkinstance(path .. ":arg"), false
		end
		if sig == "FocusLost" then return true, __mkinstance(path .. ":arg") end
		if sig == "HealthChanged" or sig == "Running" or sig == "Idled" then return 50 end
		if sig == "Chatted" then return "hello" end
		if sig == "Changed" then return "Value" end
		if sig == "MouseButton1Down" or sig == "MouseButton1Up" or sig == "MouseButton2Down" or sig == "MouseButton2Up"
			or sig == "MouseMoved" or sig == "MouseEnter" or sig == "MouseLeave" then
			return 10, 10
		end
		return __mkinstance(path .. ":arg")
	end
	do
		local conns = __CONNECTED or {}
		local i = 0
		-- callbacks connected while other callbacks run are exercised too (bounded)
		while i < #conns and i < 300 do
			i = i + 1
			local c = conns[i]
			for pass = 1, 2 do
				__PARENTMODE = (pass == 2)
				print("--- CALLBACK " .. i .. "." .. pass .. " " .. c.path)
				local ok, err = pcall(c.fn, __CBARGS(c.path))
				print("--- CALLBACK " .. i .. "." .. pass .. " done ok=" .. tostring(ok) .. (ok and "" or (" err=" .. tostring(err))))
			end
		end
		__PARENTMODE = false
	end
	-- exercise exported / global functions of the user program once
	do
		local fl, seen = {}, {}
		local function add(name, fn)
			if not seen[fn] then
				seen[fn] = true
				fl[#fl + 1] = { name = name, fn = fn }
			end
		end
		for _, e in ipairs(__GFUNCS or {}) do add(e.name, e.fn) end
		local function scan(v, name, depth)
			if type(v) == "function" then
				add(name, v)
			elseif type(v) == "table" and depth < 3 and rawget(v, "ClassName") == nil and getmetatable(v) == nil then
				local keys = {}
				for k in pairs(v) do keys[#keys + 1] = k end
				table.sort(keys, function(a, b) return tostring(a) < tostring(b) end)
				for _, k in ipairs(keys) do scan(v[k], name .. "." .. tostring(k), depth + 1) end
			end
		end
		for i, v in ipairs(__SAMPLERETS or {}) do scan(v, "ret" .. i, 0) end
		for i, e in ipairs(fl) do
			print("--- FUNC " .. i .. " " .. e.name)
			local ok, err = pcall(e.fn, __mkinstance("arg"))
			print("--- FUNC " .. i .. " done ok=" .. tostring(ok) .. (ok and "" or (" err=" .. tostring(err))))
		end
	end
	if __EXERCISE and not __INDUMP then
		local ne = 0
		for _, f in ipairs(__ALLCL) do if __ENTERED[f] then ne = ne + 1 end end
		print("=== CLOSURE EXERCISE === registered=" .. #__ALLCL .. " entered=" .. ne)
		local t_end = __RAWCLOCK() + (__EXBUDGET or 40)
		-- the synthetic calls can run a loop for millions of iterations: bound the events they log
		__ELOGMAX = math.min(__ELOGMAX or 400000, __ELOGN + 30000)
		__OPMAX = __OPRINGN + 20000
		__T0 = __RAWCLOCK()
		local i = 1
		while i <= #__ALLCL and i <= 400 and __RAWCLOCK() < t_end do
			local f = __ALLCL[i]
			if not __ENTERED[f] then
				__ENTERED[f] = true
				print("--- CLOSURE " .. i)
				local ok, err = pcall(f, __mkinstance("arg"))
				print("--- CLOSURE " .. i .. " done ok=" .. tostring(ok) .. (ok and "" or (" err=" .. tostring(err))))
				__OPMAX = __OPRINGN + 20000
				__T0 = __RAWCLOCK()
			end
			i = i + 1
		end
	end
	if __WANTC then
		for sig, spec in pairs(__WANTC) do
			local x = __PROTOS[sig]
			if x and spec.field then
				local pool = x[spec.field]
				if pool ~= nil then
					for _, k in ipairs(spec) do
						local ok, err = pcall(function() local _ = pool[k]; return _ end)
						print("WANTC " .. tostring(sig) .. " k=" .. tostring(k) .. " ok=" .. tostring(ok) .. " -> " .. tostring(err):sub(1, 120) .. " raw=" .. tostring(rawget(pool, k)))
					end
				else
					print("WANTC " .. tostring(sig) .. " pool nil")
				end
			end
		end
	end
	print("=== LATE PROTO DUMPS ===")
	local las = {}
	for la in pairs(__PROTOS) do las[#las + 1] = la end
	table.sort(las)
	for _, la in ipairs(las) do
		local x = __PROTOS[la]
		local ok, js = pcall(__JVS, x, {})
		if ok then
			print("PROTOJSON id=" .. tostring(la) .. " " .. js)
		else
			print("PROTOJSON La=" .. tostring(la) .. " ERROR " .. tostring(js))
		end
	end
	print("=== FULL OP TRACE ===")
	if type(__ALLTRACE) == "table" then
		for i = 1, #__ALLTRACE do
			local e = __ALLTRACE[i]
			print(string.format("TR %d id=%s inv=%s y=%s M=%s g=%s A=%s", e.n, tostring(e.la), tostring(e.inv), tostring(e.y), tostring(e.M), tostring(e.g), tostring(e.a)))
		end
	end
	print("=== FINAL RING TAIL ===")
	local ring = __OPRING
	local start = (__OPRINGN - 1) % 900
	for i = 149, 0, -1 do
		local e = ring[(start - i) % 900]
		if e then
			print(string.format("TAIL%d La=%s y=%s M=%s | %s", e.n, tostring(e.la), tostring(e.y), tostring(e.M), tostring(e.r):sub(1, 120)))
		end
	end
	local mts = {}
	for mt in pairs(__MTREG) do mts[#mts + 1] = mt end
	print("=== MT CAPTURES (" .. #mts .. ") ===")
	for i, mt in ipairs(mts) do
		local rec = __MTREG[mt]
		if rec.n > 0 then
			print("--- MT#" .. i .. " reads=" .. rec.n)
			local ks = {}
			for k in pairs(rec.vals) do ks[#ks + 1] = k end
			table.sort(ks, function(a, b)
				local na, nb = tonumber(a), tonumber(b)
				if na and nb then return na < nb end
				return tostring(a) < tostring(b)
			end)
			for j, k in ipairs(ks) do
				if j > 250 then print("  ...truncated") break end
				print("  MT#" .. i .. "[" .. k .. "] = " .. rec.vals[k])
			end
		end
	end
end

local __realls = loadstring or load
__LOADS = {}
local function __lshook(src, name, mode, env)
	local s = tostring(src)
	__LOADS[#__LOADS + 1] = s
	print("LOADSTRING n=" .. #s .. " name=" .. tostring(name) .. " head=" .. string.format("%q", s:sub(1, 80)))
	return __realls(src, name, mode, env)
end
if loadstring then loadstring = __lshook end
if load then load = __lshook end

do
	local __rpcall = pcall
	pcall = function(f, ...)
		local r = table.pack(__rpcall(f, ...))
		if r[1] == false and r[2] == "attempt to call a luaq value" then
			print("PCALL-CANARY forced to pass")
			return true
		end
		return table.unpack(r, 1, r.n)
	end
end
