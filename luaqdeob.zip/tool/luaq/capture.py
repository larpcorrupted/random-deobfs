"""Run a Luaq sample inside real Luau with a Roblox-style mock and capture it.

The sample is executed *unmodified* (apart from hook calls added at statement
boundaries by :mod:`prepare`).  The loader's own anti-tamper therefore runs
against a faithful emulation.  The remote session handshake the loader performs
is relayed verbatim to the endpoint the loader itself names.
"""
import io
import json
import os
import re
import ssl
import subprocess
import sys
import tempfile
import time
import urllib.error
import urllib.request

HERE = os.path.dirname(os.path.abspath(__file__))
TOOL_DIR = os.path.dirname(HERE)
RUNTIME = os.path.join(HERE, 'runtime')


def find_luau(name='luau'):
    cands = [os.path.join(TOOL_DIR, 'bin', name + '.exe'),
             os.path.join(TOOL_DIR, 'bin', name),
             os.path.join(os.path.dirname(TOOL_DIR), 'work', 'luau-bin', name + '.exe')]
    for c in cands:
        if os.path.isfile(c):
            return c
    from shutil import which
    w = which(name)
    if w:
        return w
    raise FileNotFoundError('luau binary not found (looked in tool/bin, work/luau-bin, PATH)')


class DrmError(Exception):
    pass


_CTX = ssl.create_default_context()
_CTX.check_hostname = False
_CTX.verify_mode = ssl.CERT_NONE


def http_post(url, body, tries=4):
    if isinstance(body, str):
        body = body.encode()
    last = None
    for i in range(tries):
        req = urllib.request.Request(url, data=body, headers={'Content-Type': 'application/json'})
        try:
            with urllib.request.urlopen(req, timeout=25, context=_CTX) as r:
                return r.status, r.read()
        except urllib.error.HTTPError as e:
            return e.code, e.read()
        except Exception as e:  # network hiccup: retry
            last = e
            time.sleep(1.5 * (i + 1))
    raise DrmError('network failure talking to %s: %s' % (url, last))


def luastr(b):
    out = []
    for c in b:
        ch = chr(c)
        if ch == '"':
            out.append('\\"')
        elif ch == '\\':
            out.append('\\\\')
        elif ch == '\n':
            out.append('\\n')
        elif ch == '\r':
            out.append('\\r')
        elif 32 <= c < 127:
            out.append(ch)
        else:
            out.append('\\%03d' % c)
    return '"' + ''.join(out) + '"'


HARNESS_TAIL = r'''
setfenv(__SAMPLECHUNK, getfenv(1))
local __R = table.pack(pcall(__SAMPLECHUNK))
if not __R[1] then print('SAMPLE ERROR: ' .. tostring(__R[2])) end
__SAMPLERETS = { table.unpack(__R, 2, __R.n) }
print('SAMPLE DONE rets=' .. (__R.n - 1))
__FINALDUMP()
print('=== DUMP COMPLETE ===')
'''


def build_harness(sample_src, quiet, challenge=b'', openresp=b'', extra_prelude=''):
    json_impl = io.open(os.path.join(RUNTIME, 'json.lua'), encoding='utf-8').read()
    shim = io.open(os.path.join(RUNTIME, 'shim.lua'), encoding='utf-8').read()
    marker = '--__CHALLENGE_INJECT__'
    inject = '__CHALLENGERESP = %s\n__OPENRESP = %s\n' % (luastr(challenge), luastr(openresp))
    shim = shim.replace(marker, marker + '\n' + inject)
    pre = ('__QUIET = true\n' if quiet else '') + extra_prelude
    return (pre + json_impl + '\n' + shim + '\n-- ==== SAMPLE ====\n'
            + 'local function __SAMPLECHUNK(...)\n' + sample_src + '\nend\n' + HARNESS_TAIL)


def run_luau(script_path, out_path, timeout=240, max_bytes=800 * 1024 * 1024):
    """Run luau on script_path, streaming stdout to out_path (size/time capped)."""
    luau = find_luau('luau')
    t0 = time.time()
    with open(out_path, 'wb') as fh:
        p = subprocess.Popen([luau, script_path], stdout=fh, stderr=subprocess.STDOUT)
        killed = None
        scan_pos = 0
        while True:
            try:
                rc = p.wait(timeout=1.0)
                break
            except subprocess.TimeoutExpired:
                if time.time() - t0 > timeout:
                    killed = 'timeout'
                elif os.path.getsize(out_path) > max_bytes:
                    killed = 'output-cap'
                else:
                    # dump finished but the (looping) program keeps running: stop it
                    # (scan only the bytes written since the last look: a looping program may flood the
                    # log after the marker, so the marker is not necessarily at the tail)
                    try:
                        with open(out_path, 'rb') as rf:
                            rf.seek(0, 2)
                            sz = rf.tell()
                            start = max(0, scan_pos - 32)
                            rf.seek(start)
                            while True:
                                chunk = rf.read(8 * 1024 * 1024)
                                if not chunk:
                                    break
                                if b'=== DUMP COMPLETE ===' in chunk:
                                    killed = 'after-dump'
                                    break
                                if len(chunk) < 8 * 1024 * 1024:
                                    break
                            scan_pos = sz
                    except OSError:
                        pass
                if killed:
                    p.kill()
                    p.wait()
                    rc = -9
                    break
    return rc, killed, time.time() - t0


def _read(path):
    return io.open(path, encoding='utf-8', errors='replace').read()


def capture(sample_instrumented, workdir, log=print, keep_quiet_logs=False, prelude=''):
    """Perform the 3-run DRM relay.  Returns dict with paths and metadata."""
    os.makedirs(workdir, exist_ok=True)
    res = {'workdir': workdir}

    def write_run(name, quiet, challenge=b'', openresp=b''):
        h = build_harness(sample_instrumented, quiet, challenge, openresp, extra_prelude=prelude)
        p = os.path.join(workdir, name + '.lua')
        io.open(p, 'w', encoding='utf-8', newline='').write(h)
        return p

    # run0: learn the endpoint, capability and buildId the loader wants
    p0 = write_run('run0', True)
    rc, killed, dt = run_luau(p0, os.path.join(workdir, 'run0.txt'), timeout=120)
    t0 = _read(os.path.join(workdir, 'run0.txt'))
    m = re.search(r'CHALLENGEREQ (\{.*?\})\s*$', t0, re.M)
    mu = re.search(r'HTTP-MOCK: url=(\S+?)/v4/session/challenge', t0)
    res['run0'] = {'rc': rc, 'killed': killed, 'secs': round(dt, 1)}
    if not m:
        res['drm'] = 'none'
        # no handshake observed: a plain full run is the capture
        p2 = write_run('run2', False)
        rc, killed, dt = run_luau(p2, os.path.join(workdir, 'run2.txt'))
        res['run2'] = {'rc': rc, 'killed': killed, 'secs': round(dt, 1)}
        res['out'] = os.path.join(workdir, 'run2.txt')
        # (replays need a session file: this program has no remote session, it is empty)
        io.open(os.path.join(workdir, 'session.json'), 'w').write(json.dumps({
            'base': None, 'params': None, 'challenge': '', 'openresp': ''}))
        return res
    params = m.group(1)
    base = mu.group(1) if mu else None
    if not base:
        raise DrmError('loader asked for a session challenge but no endpoint URL was observed')
    res['drm'] = 'remote-session'
    res['base'] = base
    res['params'] = json.loads(params)

    last_err = None
    for attempt in range(3):
        st, chal = http_post(base + '/v4/session/challenge', params)
        if st != 200:
            raise DrmError('challenge refused (%s): %r' % (st, chal[:200]))
        p1 = write_run('run1', True, challenge=chal)
        rc, killed, dt1 = run_luau(p1, os.path.join(workdir, 'run1.txt'), timeout=60)
        t1 = _read(os.path.join(workdir, 'run1.txt'))
        mo = re.search(r'OPENREQ (.*)$', t1, re.M)
        if not mo:
            last_err = 'loader produced no open request (rc=%s killed=%s)' % (rc, killed)
            continue
        st, openresp = http_post(base + '/v4/session/open', mo.group(1))
        if st != 200:
            last_err = 'open refused (%s): %r' % (st, openresp[:200])
            continue
        p2 = write_run('run2', False, challenge=chal, openresp=openresp)
        rc, killed, dt = run_luau(p2, os.path.join(workdir, 'run2.txt'))
        res['run1'] = {'secs': round(dt1, 1)}
        res['run2'] = {'rc': rc, 'killed': killed, 'secs': round(dt, 1)}
        res['out'] = os.path.join(workdir, 'run2.txt')
        res['challenge_len'] = len(chal)
        res['openresp_len'] = len(openresp)
        import base64
        io.open(os.path.join(workdir, 'session.json'), 'w').write(json.dumps({
            'base': base, 'params': res['params'],
            'challenge': base64.b64encode(chal).decode(),
            'openresp': base64.b64encode(openresp).decode()}))
        return res
    raise DrmError(last_err or 'session relay failed')


def load_session(workdir):
    import base64
    d = json.load(io.open(os.path.join(workdir, 'session.json')))
    return base64.b64decode(d['challenge']), base64.b64decode(d['openresp'])


def replay(sample_instrumented, workdir, name='replay', prelude='', timeout=240):
    """Re-run the instrumented sample against the stored DRM session (offline)."""
    chal, openresp = load_session(workdir)
    h = build_harness(sample_instrumented, False, chal, openresp, extra_prelude=prelude)
    p = os.path.join(workdir, name + '.lua')
    io.open(p, 'w', encoding='utf-8', newline='').write(h)
    out = os.path.join(workdir, name + '.txt')
    rc, killed, dt = run_luau(p, out, timeout=timeout)
    return out, rc, killed, dt
