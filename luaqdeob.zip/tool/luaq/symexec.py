"""Symbolic execution of a single VM handler body.

Given the AST of one handler (a fused superinstruction), the instruction's
operand table ``a`` (concrete, from the trace), and the role names of the
dialect, produce an ordered list of *effects* with symbolic expressions:

  ('set',   reg, expr)                register assignment
  ('call',  callee, args, dst, nret)  call; dst = register or None
  ('setidx', obj, key, val)           table store
  ('setglob', kexpr, val)             global store
  ('setupv', n, val)                  upvalue store
  ('pc',    expr)                     unconditional pc assignment (jump)
  ('if',    cond, then_effects, else_effects)
  ('ret',   [exprs])                  function return
  ('unk',   text)                     anything not understood

Expressions are tuples: ('reg',i) ('const',k) ('num',v) ('str',s) ('bool',b)
('nil',) ('glob',kexpr) ('upv',n) ('idx',obj,key) ('callres',id) ('bin',op,l,r)
('un',op,e) ('tbl',[items]) ('closure',k,[caps]) ('unpack',e) ('vararg',)
('unkv',text) ('pcv',) ('rel',expr)
"""
from . import luaparse as lp


class Unsupported(Exception):
    pass


NIL = ('nil',)


def _lit(v):
    if v is None:
        return NIL
    if isinstance(v, bool):
        return ('bool', v)
    if isinstance(v, (int, float)):
        return ('num', v)
    if isinstance(v, str):
        return ('str', v)
    return ('data', v)


def _is_conc(e):
    return e[0] in ('num', 'str', 'bool', 'nil', 'data')


def _pyval(e):
    if e[0] == 'nil':
        return None
    return e[1]


class Roles:
    """Names of the dialect's special variables (discovered per sample)."""

    def __init__(self, u, a, x, pc, flag):
        self.u, self.a, self.x, self.pc, self.flag = u, a, x, pc, flag


def _aget(A, k):
    if isinstance(A, dict):
        return A.get(str(int(k)))
    if isinstance(A, list):
        k = int(k)
        return A[k - 1] if 0 < k <= len(A) else None
    return None


class Interp:
    def __init__(self, roles, A):
        self.R = roles
        self.A = A
        self.regs = {}
        self.ncall = 0
        self.scopes = [{}]
        self.unk = []
        self.brj = 0
        self.tbls = {}
        self.ntbl = 0
        self.nread = 0
        self.packed = set()

    # ------------------------------------------------------------ scoping
    def lookup(self, name):
        for sc in reversed(self.scopes):
            if name in sc:
                return sc[name]
        return None

    def has(self, name):
        return any(name in sc for sc in self.scopes)

    def setvar(self, name, val):
        for sc in reversed(self.scopes):
            if name in sc:
                sc[name] = val
                return
        self.scopes[0][name] = val

    # ------------------------------------------------------------ expressions
    def ev(self, e):
        t = e[0]
        if t == 'Number':
            return ('num', e[1])
        if t == 'String':
            return ('str', e[1])
        if t == 'Nil':
            return NIL
        if t == 'True':
            return ('bool', True)
        if t == 'False':
            return ('bool', False)
        if t == 'Paren':
            return self.ev(e[1])
        if t == 'Name':
            n = e[1]
            if self.has(n):
                return self.lookup(n)
            if n == self.R.u:
                return ('REGFILE',)
            if n == self.R.a or n == getattr(self.R, 'a2', None):
                return ('OPERANDS',)
            if n == self.R.x:
                return ('PROTO',)
            if n == self.R.pc:
                return ('pcv',)
            if n == self.R.flag:
                return ('bool', True)
            return ('free', n)
        if t == 'Index':
            return self.index(self.ev(e[1]), self.ev(e[2]))
        if t == 'Call':
            return self.call(e)
        if t == 'Method':
            return ('unkv', 'method:' + e[2])
        if t == 'Bin':
            return self.binop(e[1], e[2], e[3])
        if t == 'Un':
            return self.unop(e[1], self.ev(e[2]))
        if t == 'Table':
            arr, kv = [], []
            for kind, k, v in e[1]:
                if kind == 'arr':
                    arr.append(self.ev(v))
                else:
                    kk = self.ev(k)
                    if kk == ('str', 'n'):
                        continue          # length bookkeeping of VM-internal packs
                    kv.append((kk, self.ev(v)))
            self.ntbl += 1
            self.tbls[self.ntbl] = {'arr': arr, 'kv': kv}
            return ('tblref', self.ntbl)
        if t == 'Vararg':
            return ('vararg',)
        raise Unsupported('expr ' + t)

    def index(self, obj, key):
        k = obj[0]
        if k == 'REGFILE':
            if key[0] != 'num':
                raise Unsupported('symbolic register index')
            i = int(key[1])
            if i in self.regs:
                return self.regs[i]
            return ('reg', i)
        if k == 'OPERANDS':
            if key[0] != 'num':
                raise Unsupported('symbolic operand index')
            return _lit(_aget(self.A, key[1])) if not isinstance(_aget(self.A, key[1]), (list, dict)) \
                else ('data', _aget(self.A, key[1]))
        if k == 'data':
            d = obj[1]
            if key[0] == 'num' and isinstance(d, list):
                i = int(key[1])
                v = d[i - 1] if 0 < i <= len(d) else None
            elif isinstance(d, dict):
                v = d.get(str(int(key[1]))) if key[0] == 'num' else d.get(key[1])
            else:
                v = None
            return _lit(v) if not isinstance(v, (list, dict)) else ('data', v)
        if k == 'free':
            # free table indexed by a proto constant => env (global access);
            # indexed by operand number => upvalue slot table
            if key[0] == 'const':
                return self.emit_read(('glob', key))
            if key[0] == 'num':
                return ('upvslot', obj[1], int(key[1]))
            return self.emit_read(('idx', obj, key))
        if k == 'upvslot':
            if key[0] == 'num' and key[1] == 1:
                return self.emit_read(('upv', obj[2]))
            return self.emit_read(('idx', obj, key))
        if k == 'pack':
            if key[0] == 'num':
                return ('nth', obj[1], int(key[1]))
            if key == ('str', 'n'):
                return ('packn', obj[1])
            return ('idx', obj, key)
        if k == 'tblref':
            tb = self.tbls[obj[1]]
            if key[0] == 'num' and float(key[1]).is_integer():
                i = int(key[1])
                if 1 <= i <= len(tb['arr']):
                    return tb['arr'][i - 1]
                return NIL
            for kk, vv in tb['kv']:
                if kk == key:
                    return vv
            return NIL
        return self.emit_read(('idx', obj, key))

    def unop(self, op, v):
        if _is_conc(v) and v[0] != 'data':
            x = _pyval(v)
            try:
                if op == 'not':
                    return ('bool', not (x is not None and x is not False))
                if op == '-':
                    return ('num', -x)
                if op == '#':
                    return ('num', len(x))
            except Exception:
                pass
        if v[0] == 'data' and op == '#':
            return ('num', len(v[1]))
        if v[0] == 'tblref' and op == '#':
            return ('num', len(self.tbls[v[1]]['arr']))
        return ('un', op, v)

    def truthy(self, v):
        """Return True/False if decidable, else None."""
        if v[0] == 'bool':
            return v[1]
        if v[0] == 'nil':
            return False
        if v[0] in ('num', 'str', 'data', 'tbl', 'tblref'):
            return True
        return None

    def binop(self, op, l, r):
        if op == 'and':
            lv = self.ev(l)
            if lv[0] == 'idx' and lv[1][0] == 'free':
                return ('bool', False)         # optional VM-internal library function: absent
            tv = self.truthy(lv)
            if tv is False:
                return lv
            if tv is True:
                return self.ev(r)
            rv = self.ev(r)
            if self.truthy(rv) is False:
                return ('bool', False)          # (anything and false) is falsy
            return ('bin', 'and', lv, rv)
        if op == 'or':
            lv = self.ev(l)
            tv = self.truthy(lv)
            if tv is True:
                return lv
            if tv is False:
                return self.ev(r)
            return ('bin', 'or', lv, self.ev(r))
        a, b = self.ev(l), self.ev(r)
        # sentinel comparisons: a free (unknown upvalue) value never equals real data
        if op in ('==', '~='):
            def sentinel(v):
                return v[0] == 'free' or (v[0] == 'idx' and sentinel(v[1]))
            if sentinel(a) or sentinel(b):
                return ('bool', op == '~=')
            if _is_conc(a) and _is_conc(b) and a[0] != 'data' and b[0] != 'data':
                res = (_pyval(a) == _pyval(b)) and (a[0] == b[0] or {a[0], b[0]} <= {'num'})
                return ('bool', res if op == '==' else not res)
        if _is_conc(a) and _is_conc(b) and a[0] != 'data' and b[0] != 'data' \
                and a[0] != 'nil' and b[0] != 'nil':
            x, y = _pyval(a), _pyval(b)
            try:
                if op == '+':
                    return ('num', x + y)
                if op == '-':
                    return ('num', x - y)
                if op == '*':
                    return ('num', x * y)
                if op == '/':
                    return ('num', x / y)
                if op == '%':
                    return ('num', x % y)
                if op == '<':
                    return ('bool', x < y)
                if op == '<=':
                    return ('bool', x <= y)
                if op == '>':
                    return ('bool', x > y)
                if op == '>=':
                    return ('bool', x >= y)
                if op == '..':
                    return ('str', str(x) + str(y))
            except Exception:
                pass
        if a[0] == 'pcv' and op in ('+', '-') and b[0] == 'num':
            return ('rel', b[1] if op == '+' else -b[1])
        return ('bin', op, a, b)

    def call(self, e):
        fn = e[1]
        args = e[2]
        # proto-relative helpers: first arg is the proto variable
        if args and args[0][0] == 'Name' and args[0][1] == self.R.x and not self.has(args[0][1]):
            vals = [self.ev(x) for x in args[1:]]
            if len(vals) == 2 and vals[0][0] == 'num':
                return ('const', int(vals[0][1]))
            if len(vals) >= 4 and vals[0][0] == 'num':
                return ('closure', int(vals[0][1]), vals[2], vals[3] if len(vals) > 3 else NIL)
            raise Unsupported('proto helper arity %d' % len(vals))
        callee = self.ev(fn)
        # `lib.fn(x)` on a VM-internal library table (numeric coercion of loop control values):
        # value-preserving for the numbers the compiler feeds it
        if callee[0] == 'idx' and callee[1][0] == 'free' and len(args) == 1:
            return self.ev(args[0])
        if callee[0] in ('reg', 'callres', 'rres', 'idx', 'glob', 'upv', 'unkv', 'closure', 'lvar', 'nth', 'mnth'):
            argv = [self.ev(x) for x in args]
            return self.emit_call(callee, argv)
        if callee[0] == 'free':
            argv = [self.ev(x) for x in args]
            if STEP_FN and callee[1] == STEP_FN and len(argv) == 1:
                # generic-for step helper: results = rec[1](rec[2], rec[3]); rec[3] = results[1]
                rec = argv[0]
                res = self.emit_call(('idx', rec, ('num', 1)), [('idx', rec, ('num', 2)), ('idx', rec, ('num', 3))])
                self.packed.add(res[1])
                self.cur.append(('setidx', rec, ('num', 3), ('nth', res[1], 1)))
                return ('pack', res[1])
            # the VM's result wrapper is table.pack: the register receives all returns
            if len(argv) == 1 and argv[0][0] == 'callres':
                self.packed.add(argv[0][1])
                return ('pack', argv[0][1])
            if len(argv) == 1 and argv[0][0] in ('reg',):
                return argv[0]
            if len(argv) == 3 and argv[1] == ('num', 1):
                return ('unpack', argv[0])
            if len(argv) == 2 and argv[0][0] in ('pack', 'tblref', 'reg') and argv[1][0] == 'num':
                return argv[0]        # iterator record built from packed call results
            # jump-target decoder or other opaque helper
            return ('unkv', 'call:%s/%d' % (callee[1], len(argv)))
        raise Unsupported('call of ' + callee[0])

    OPAQUE_OBJS = ('PROTO', 'free', 'unkv', 'pcv', 'REGFILE', 'OPERANDS', 'upvslot')

    def emit_read(self, expr):
        """A state-dependent read happens exactly once, at its evaluation point."""
        if expr[0] == 'idx' and expr[1][0] in self.OPAQUE_OBJS:
            return expr                   # VM-internal structure, not user-visible state
        self.nread += 1
        rid = self.nread
        self.cur.append(('read', rid, expr))
        return ('rres', rid)

    def emit_call(self, callee, argv, nret=1):
        self.ncall += 1
        cid = self.ncall
        self.cur.append(('call', callee, argv, cid))
        return ('callres', cid)

    # ------------------------------------------------------------ statements
    def run(self, body):
        self.cur = []
        try:
            self.block(body, self.cur)
        except _Stop:
            pass
        return self._mark_packed(self.cur)

    def _mark_packed(self, eff):
        out = []
        for e in eff:
            if e[0] == 'call' and e[3] in self.packed:
                e = ('call', e[1], e[2], e[3], True)
            elif e[0] == 'if':
                e = ('if', e[1], self._mark_packed(e[2]), self._mark_packed(e[3])) + tuple(e[4:])
            out.append(e)
        return out

    def block(self, stmts, out):
        self.scopes.append({})
        saved = self.cur
        self.cur = out
        try:
            for s in stmts:
                self.stmt(s, out)
        finally:
            self.cur = saved
            self.scopes.pop()

    def is_guard(self, cond):
        # `not <flag>` or `<flag> == false`-style liveness guard
        if cond[0] == 'Un' and cond[1] == 'not' and cond[2] == ('Name', self.R.flag):
            return True
        return False

    def stmt(self, s, out):
        t = s[0]
        if t == 'Local':
            vals = [self.ev(x) for x in s[2]]
            for i, n in enumerate(s[1]):
                self.scopes[-1][n] = vals[i] if i < len(vals) else NIL
            return
        if t == 'Assign':
            vals = [self.ev(x) for x in s[2]]
            for i, tg in enumerate(s[1]):
                v = vals[i] if i < len(vals) else NIL
                self.assign(tg, v, out)
            return
        if t == 'CAssign':
            self.assign(s[2], self.binop(s[1], s[2], s[3]), out)
            return
        if t == 'CallStmt':
            c = s[1]
            if c[0] == 'Call':
                self.call(c)
            else:
                out.append(('unk', 'method call stmt'))
            return
        if t == 'Do':
            self.block(s[1], out)
            return
        if t == 'If':
            self.if_stmt(s, out)
            return
        if t == 'GenFor':
            return self._genfor(s, out)
        if t == 'While':
            return self._while(s, out)

        if t == 'NumFor':
            if self._append_all(s) or self._set_multi(s):
                return
            a, b = self.ev(s[2]), self.ev(s[3])
            c = self.ev(s[4]) if s[4] is not None else ('num', 1)
            if not (a[0] == 'num' and b[0] == 'num' and c[0] == 'num'):
                raise Unsupported('symbolic for bounds')
            i = a[1]
            n = 0
            while (c[1] > 0 and i <= b[1]) or (c[1] < 0 and i >= b[1]):
                self.scopes.append({s[1]: ('num', i)})
                self.block(s[5], out)
                self.scopes.pop()
                i += c[1]
                n += 1
                if n > 4096:
                    raise Unsupported('long for')
            return
        if t == 'Return':
            vals = [self.ev(x) for x in s[1]]
            out.append(('ret', vals))
            raise _Stop()
        raise Unsupported('stmt ' + t)

    def _while(self, s, out):
        """Fused loop macro: `while <alive> do <exit test + break> ; <body micro-ops> end`.
        Reported as ('whileloop', continue_condition, body_effects, id)."""
        cond, body = s[1], s[2]
        if not (cond[0] == 'Name' and (cond[1] == self.R.flag or not self.has(cond[1]))):
            raise Unsupported('stmt While')
        # find the exit test: `if not (C) then <pc = X>; break end` (possibly inside a do-block)
        pre, test_if, rest = None, None, None
        flat = body
        if flat and flat[0][0] == 'Do':
            flat = flat[0][1]
        decl = []
        idx = None
        for k, st in enumerate(flat):
            if st[0] == 'Local':
                decl.append(st)
            elif st[0] == 'If' and len(st[1]) == 1 and any(x[0] == 'Break' for x in st[1][0][1]):
                idx = k
                break
            else:
                break
        if idx is None:
            # straight-line sequence of fused micro-ops, possibly with conditional exits; when the body does not
            # end with a `break`, the macro is a loop (the source's `while`): falling off its end repeats it
            last = body[-1] if body else None
            ends = last is not None and (last[0] in ('Break', 'Return')
                                        or (last[0] == 'Do' and last[1] and last[1][-1][0] in ('Break', 'Return')))
            self._micro_seq(body, 0, out, loop=not ends)
            return
        test_if = flat[idx]
        rest = (body[1:] if body[0][0] == 'Do' else flat[idx + 1:])
        if body[0][0] != 'Do':
            rest = flat[idx + 1:]
        # the exit test lives in its own scope (its locals shadow the register file name)
        self.scopes.append({})
        try:
            for st in decl:
                self.stmt(st, out)
            tcond = test_if[1][0][0]
            if tcond[0] == 'Un' and tcond[1] == 'not':
                c = self.ev(tcond[2])          # `if not C then leave end`: continue while C
            else:
                c = self.unop('not', self.ev(tcond))
            leave_eff = []
            for st in test_if[1][0][1]:
                if st[0] == 'Break':
                    break
                self.stmt(st, leave_eff)
        finally:
            self.scopes.pop()
        self.ngen = getattr(self, 'ngen', 0) + 1
        gid = self.ngen
        body_eff = []
        outer = self.cur
        self.cur = body_eff
        try:
            self.block(rest, body_eff)
        except _Stop:
            body_eff.append(('ret-in-if',))
        finally:
            self.cur = outer
        # `if not C then leave end` => the loop continues while C is true
        cont = c
        out.extend(e for e in leave_eff if e[0] == 'pc')
        out.append(('whileloop', cont, body_eff, gid))

    @staticmethod
    def _break_if(st):
        """`if C then ...; break end` (single clause, no else, `break` ends the clause)."""
        return (st[0] == 'If' and len(st[1]) == 1 and st[2] is None and st[1][0][1]
                and st[1][0][1][-1][0] == 'Break'
                and not any(x[0] == 'Break' for x in st[1][0][1][:-1]))

    def _micro_seq(self, body, i, out, loop=False):
        """`while <alive> do do <micro-op> end; if not <alive> then return end; ... end`: the
        fused superinstruction runs its micro-ops in order.  A `do if C then <exit>; break end
        end` block is a conditional exit: the micro-ops after it form the else-branch."""
        while i < len(body):
            st = body[i]
            pre, brk = [], None
            if st[0] == 'Do' and st[1] and self._break_if(st[1][-1]):
                pre, brk = st[1][:-1], st[1][-1]
            elif self._break_if(st):
                brk = st
            if brk is None:
                if st[0] == 'Break':
                    return
                self.stmt(st, out)
                i += 1
                if loop and i >= len(body):
                    # the end of the `while <alive> do` body: the fused instruction runs again
                    out.append(('pc', ('self',)))
                continue
            cond, blk = brk[1][0]
            jwrap = None
            if self.moves_pc(blk):
                self.brj += 1
                jwrap = self.brj
            then_e = []
            self.scopes.append({})
            try:
                for p in pre:
                    self.stmt(p, out)
                cv = self.ev(cond)
                tv = self.truthy(cv)
                if tv is False:
                    i += 1
                    continue
                saved_regs = dict(self.regs)
                for s3 in blk[:-1]:
                    self.stmt(s3, then_e)
            finally:
                self.scopes.pop()
            if tv is True:
                out.extend(then_e)
                return
            self.regs = dict(saved_regs)
            else_e = []
            saved_cur = self.cur
            self.cur = else_e
            try:
                self._micro_seq(body, i + 1, else_e, loop)
            except _Stop:
                else_e.append(('ret-in-if',))
            finally:
                self.cur = saved_cur
            out.append(('if', cv, then_e, else_e, jwrap))
            return

    # ---- generic for: one symbolic iteration, reported as a ('forin', ...) effect
    def _is_triple(self, exprs):
        if len(exprs) != 3:
            return None
        base = None
        for k, e in enumerate(exprs, start=1):
            if not (e[0] == 'Index' and e[1][0] == 'Name' and e[2] == ('Number', k)):
                return None
            if base is None:
                base = e[1]
            elif base != e[1]:
                return None
        return base

    def _contains_triple_forin(self, node):
        found = []

        def v(n):
            if n[0] == 'GenFor' and self._is_triple(n[2]):
                found.append(1)
        lp.walk(node, v)
        return bool(found)

    def _genfor(self, s, out):
        names, exprs, body = s[1], s[2], s[3]
        base = self._is_triple(exprs)
        if base is not None:
            explist = self.ev(base)
        else:
            vals = [self.ev(x) for x in exprs]
            explist = vals[0] if len(vals) == 1 else ('tbl', vals, [], -1)
        self.ngen = getattr(self, 'ngen', 0) + 1
        gid = self.ngen
        lvars = [('lvar', gid, j) for j in range(len(names))]
        # scratch table of the loop variables: `NAME[1], NAME[2] = d, c`
        scratch = None
        for st in body:
            if st[0] != 'Assign':
                continue
            tg = st[1]
            if tg and all(x[0] == 'Index' and x[1][0] == 'Name' and x[2][0] == 'Number' for x in tg)                     and len({x[1][1] for x in tg}) == 1                     and st[2] and all(v[0] == 'Name' and v[1] in names for v in st[2]):
                if base is not None and tg[0][1] == base:
                    continue          # control-variable bookkeeping on the explist itself
                scratch = tg[0][1][1]
                break
        saved_regs = dict(self.regs)
        body_eff = []
        outer_cur = self.cur
        self.cur = body_eff
        self.scopes.append({n: lvars[j] for j, n in enumerate(names)})
        if scratch is not None:
            self.ntbl += 1
            self.tbls[self.ntbl] = {'arr': [], 'kv': []}
            self.setvar(scratch, ('tblref', self.ntbl))
        prev_forlist = getattr(self, 'forlist', None)
        self.forlist = explist
        try:
            self.block(body, body_eff)
        except _Stop:
            body_eff.append(('ret-in-if',))
        finally:
            self.scopes.pop()
            self.cur = outer_cur
        out.append(('forin', explist, len(names), body_eff, gid))

    def _set_multi(self, s):
        """`for z = 1, L.n do U[V + z - 1] = L[z] end`: spread a packed result over
        consecutive registers starting at V."""
        body = s[5]
        if len(body) != 1 or body[0][0] != 'Assign':
            return False
        tg, val = body[0][1][0], body[0][2][0]
        iv = s[1]
        if not (tg[0] == 'Index' and tg[2][0] == 'Bin' and tg[2][1] == '-'
                and tg[2][3] == ('Number', 1) and tg[2][2][0] == 'Bin' and tg[2][2][1] == '+'
                and tg[2][2][3] == ('Name', iv)):
            return False
        if not (val[0] == 'Index' and val[2] == ('Name', iv)):
            return False
        obj = self.ev(tg[1])
        base = self.ev(tg[2][2][2])
        src = self.ev(val[1])
        if base[0] != 'num':
            return False
        if obj[0] == 'REGFILE':
            self.cur.append(('setmulti', int(base[1]), src))
            return True
        if obj[0] == 'tblref':
            self.tbls[obj[1]]['open'] = src      # `{a, b, f()}`: open tail of a table built here
            return True
        # SETLIST into a table that lives in a register: T[v..] = every value of the pack
        self.cur.append(('settail', obj, int(base[1]), src))
        return True

    def _append_all(self, s):
        """`for i = 1, X.n do L[L.n + i] = X[i] end`: append every value of the packed
        multi-value X to table L (open tail)."""
        body = s[5]
        if len(body) != 1 or body[0][0] != 'Assign':
            return False
        tg, val = body[0][1][0], body[0][2][0]
        iv = s[1]
        # `for i = 1, X.n do L[i + c] = X[i] end`: X follows c leading items of L (`{first, f()}`)
        if (tg[0] == 'Index' and tg[1][0] == 'Name' and tg[2][0] == 'Bin' and tg[2][1] == '+'
                and ((tg[2][2] == ('Name', iv) and tg[2][3][0] == 'Number')
                     or (tg[2][3] == ('Name', iv) and tg[2][2][0] == 'Number'))
                and val[0] == 'Index' and val[1][0] == 'Name' and val[2] == ('Name', iv)):
            lt = self.ev(tg[1])
            xv = self.ev(val[1])
            if lt[0] == 'tblref':
                self.tbls[lt[1]]['open'] = xv
                return True
            return False
        if not (tg[0] == 'Index' and tg[1][0] == 'Name' and tg[2][0] == 'Bin' and tg[2][1] == '+'
                and tg[2][3] == ('Name', iv) and tg[2][2][0] == 'Index' and tg[2][2][1] == tg[1]
                and tg[2][2][2] == ('String', 'n')):
            return False
        if not (val[0] == 'Index' and val[1][0] == 'Name' and val[2] == ('Name', iv)):
            return False
        lt = self.ev(tg[1])
        xv = self.ev(val[1])
        if lt[0] != 'tblref':
            return False
        self.tbls[lt[1]]['open'] = xv
        return True

    def assign(self, tg, v, out):
        if tg[0] == 'Index':
            obj = self.ev(tg[1])
            key = self.ev(tg[2])
            if obj[0] == 'REGFILE':
                if key[0] != 'num':
                    raise Unsupported('symbolic register store')
                self.regs[int(key[1])] = v
                out.append(('set', int(key[1]), v))
                return
            if obj[0] == 'free' and key[0] == 'const':
                out.append(('setglob', key, v))
                return
            if obj[0] == 'upvslot' and key[0] == 'num' and key[1] == 1:
                out.append(('setupv', obj[2], v))
                return
            if getattr(self, 'forlist', None) is not None and obj == self.forlist:
                return                # iterator control bookkeeping
            if obj[0] == 'tblref':
                tb = self.tbls[obj[1]]
                if key == ('str', 'n'):
                    return
                if self._mentions_tbl(v, obj[1]):
                    # `cell[1] = <closure capturing cell>` (a recursive local function created inside one fused
                    # instruction): the table cannot contain itself as a value, the store stays a statement
                    out.append(('setidx', obj, key, v))
                    return
                if key[0] == 'num' and float(key[1]).is_integer() and key[1] >= 1:
                    i = int(key[1])
                    while len(tb['arr']) < i:
                        tb['arr'].append(NIL)
                    tb['arr'][i - 1] = v
                else:
                    for n_, (kk, vv) in enumerate(tb['kv']):
                        if kk == key:
                            tb['kv'][n_] = (kk, v)
                            break
                    else:
                        tb['kv'].append((key, v))
                return
            if obj[0] in ('reg', 'callres', 'rres', 'idx', 'glob', 'upv', 'tbl'):
                out.append(('setidx', obj, key, v))
                return
            if obj[0] == 'data':
                return
            out.append(('unk', 'store into ' + obj[0]))
            return
        if tg[0] == 'Name':
            n = tg[1]
            if n == self.R.pc:
                out.append(('pc', v))
                self.scopes[0].setdefault('__pc', v)
                return
            if self.has(n):
                self.setvar(n, v)
                return
            # assignment to an unknown free variable (flag / bookkeeping): ignore
            return
        raise Unsupported('assign target ' + tg[0])

    def _mentions_tbl(self, v, tid, seen=None):
        seen = set() if seen is None else seen
        if isinstance(v, tuple):
            if v and v[0] == 'tblref':
                if v[1] == tid:
                    return True
                if v[1] in seen:
                    return False
                seen.add(v[1])
                tb = self.tbls.get(v[1], {})
                return any(self._mentions_tbl(x, tid, seen) for x in tb.get('arr', ())) or \
                    any(self._mentions_tbl(b, tid, seen) for _a, b in tb.get('kv', ()))
            return any(self._mentions_tbl(x, tid, seen) for x in v if isinstance(x, (tuple, list)))
        if isinstance(v, list):
            return any(self._mentions_tbl(x, tid, seen) for x in v)
        return False

    def moves_pc(self, blk):
        pcn = self.R.pc
        for st in blk:
            if st[0] == 'Assign' and len(st[1]) == 1 and st[1][0] == ('Name', pcn):
                return True
            if st[0] == 'CAssign' and st[2] == ('Name', pcn):
                return True
        return False

    def if_stmt(self, s, out):
        clauses, els = s[1], s[2]
        # iteration-protocol dispatch: keep the branch holding the generic `for i[1], i[2], i[3]`
        if any(self._contains_triple_forin(b) for _, b in clauses) or                 (els is not None and self._contains_triple_forin(els)):
            for _, b in clauses:
                if self._contains_triple_forin(b) and not any(
                        x[0] == 'If' and False for x in b):
                    self.block(b, out)
                    return
            if els is not None:
                self.block(els, out)
                return
        # liveness guard `if not flag then return end` => skip entirely
        if len(clauses) == 1 and self.is_guard(clauses[0][0]) and els is None:
            return
        # build nested structure for the first clause whose condition is symbolic
        for i, (cond, blk) in enumerate(clauses):
            jwrap = None
            if self.moves_pc(blk):
                self.brj += 1
                jwrap = self.brj
            cv = self.ev(cond)
            tv = self.truthy(cv)
            if tv is True:
                self.block(blk, out)
                return
            if tv is False:
                continue
            # symbolic: fork
            then_e, else_e = [], []
            saved_regs = dict(self.regs)
            try:
                self.block(blk, then_e)
            except _Stop:
                then_e.append(('ret-in-if',))
            regs_then = dict(self.regs)
            self.regs = dict(saved_regs)
            rest = (clauses[i + 1:], els)
            if rest[0] or rest[1] is not None:
                try:
                    self.if_stmt(('If', rest[0], rest[1]) if rest[0] else ('If', [(('True',), rest[1])], None), else_e) \
                        if rest[0] else self.block(rest[1], else_e)
                except _Stop:
                    else_e.append(('ret-in-if',))
            # register state after a symbolic branch is path-dependent: invalidate
            changed = set(regs_then) | set(self.regs)
            self.regs = dict(saved_regs)
            for r_ in changed:
                if regs_then.get(r_) != saved_regs.get(r_) or self.regs.get(r_) != saved_regs.get(r_):
                    pass
            out.append(('if', cv, then_e, else_e, jwrap))
            return
        if els is not None:
            self.block(els, out)


STEP_FN = None      # name of the VM's generic-for step helper (set by lift.Model from the VM model)


class _Stop(Exception):
    pass


def _resolve(e, tbls, depth=0):
    if isinstance(e, tuple):
        if e and e[0] == 'tblref':
            tb = tbls[e[1]]
            arr = [_resolve(x, tbls, depth + 1) for x in tb['arr']]
            kv = [(_resolve(k, tbls, depth + 1), _resolve(v, tbls, depth + 1)) for k, v in tb['kv']]
            if tb.get('open') is not None:
                return ('tbl', arr, kv, e[1], _resolve(tb['open'], tbls, depth + 1))
            return ('tbl', arr, kv, e[1])
        return tuple(_resolve(x, tbls, depth + 1) for x in e)
    if isinstance(e, list):
        return [_resolve(x, tbls, depth + 1) for x in e]
    return e


def _refs(e, out):
    if isinstance(e, tuple):
        if len(e) == 2 and e[0] == 'rres':
            out.add(e[1])
        for x in e:
            _refs(x, out)
    elif isinstance(e, list):
        for x in e:
            _refs(x, out)


def _drop_dead_reads(eff, final):
    refs = set()
    for e in eff:
        if e[0] != 'read':
            _refs(e, refs)
        else:
            _refs(e[2], refs)
    out = []
    for e in eff:
        if e[0] == 'read' and e[1] not in refs:
            continue
        if e[0] == 'if':
            e = ('if', e[1], _drop_dead_reads(e[2], False), _drop_dead_reads(e[3], False)) + tuple(e[4:])
        elif e[0] == 'forin':
            e = ('forin', e[1], e[2], _drop_dead_reads(e[3], False), e[4])
        elif e[0] == 'whileloop':
            e = ('whileloop', e[1], _drop_dead_reads(e[2], False), e[3])
        out.append(e)
    return out


def interpret(body, roles, A):
    ip = Interp(roles, A)
    if hasattr(body, 'oplocals') and hasattr(body, 'opaque'):
        # (Luaq 2.5) the handler decoded its operands into locals before its semantics: bind them to the values the
        # operand probe recorded; the other prologue locals are VM bookkeeping
        from .vmmodel import OPV_BASE
        for n in body.opaque:
            ip.scopes[0][n] = ('unkv', 'vm:' + n)
        for i, n in enumerate(body.oplocals):
            v = _aget(A, OPV_BASE + 1 + i)
            ip.scopes[0][n] = ('data', v) if isinstance(v, (list, dict)) else _lit(v)
    eff = ip.run(body)
    eff = _resolve(eff, ip.tbls)
    # reads referenced nowhere (scratch lookups of VM-internal tables) are not user-visible
    for _ in range(3):
        eff = _drop_dead_reads(eff, True)
    return eff


def handler_roles(body, scoped=False):
    """Roles (regs, operands, proto, pc, flag) as used by ONE handler body.  The variables
    holding these roles are permuted between decode paths, so they cannot be global.
    Only names that are free in the body (not declared by a `local`/loop inside it) count."""
    from collections import Counter
    declared = set()

    def dv(n):
        t = n[0]
        if t == 'Local':
            # `local F = F[e]` re-binds a register-file name from itself: still the same role
            for k, nm in enumerate(n[1]):
                init = n[2][k] if k < len(n[2]) else None
                if init is not None and init[0] == 'Index' and init[1][0] == 'Name'                         and init[2][0] != 'Number':
                    continue
                declared.add(nm)
        elif t == 'NumFor':
            declared.add(n[1])
        elif t == 'GenFor':
            declared.update(n[1])
        elif t == 'LocalFunction':
            declared.add(n[1])
        elif t == 'Function':
            declared.update(n[1])
    lex_scopes = [set()]

    if scoped:
        pass
    else:
        lp.walk(body, dv)
    pair, upair, direct, xs, flags, pcs = Counter(), Counter(), Counter(), Counter(), Counter(), Counter()
    first3 = Counter()

    def free(nm):
        if scoped:
            return not any(nm in sc for sc in lex_scopes)
        return nm not in declared

    def f(n):
        if n[0] == 'Index' and n[1][0] == 'Name' and n[2][0] == 'Index' and n[2][1][0] == 'Name'                 and n[2][2][0] == 'Number' and free(n[1][1]):
            upair[n[1][1]] += 1
            if free(n[2][1][1]):
                pair[(n[1][1], n[2][1][1])] += 1
        if n[0] == 'Index' and n[1][0] == 'Name' and n[2][0] == 'Number' and free(n[1][1]):
            direct[n[1][1]] += 1
        if n[0] == 'Call' and len(n[2]) >= 3 and n[2][0][0] == 'Name' and n[2][1][0] == 'Index'                 and n[2][1][1][0] == 'Name' and n[2][1][2][0] == 'Number' and free(n[2][0][1])                 and n[2][0][1] != n[2][1][1][1]:
            xs[n[2][0][1]] += 1
        elif n[0] == 'If' and len(n[1]) == 1 and n[1][0][0][0] == 'Un' and n[1][0][0][1] == 'not'                 and n[1][0][0][2][0] == 'Name' and n[1][0][1] and n[1][0][1][0][0] == 'Return'                 and not n[1][0][1][0][1]:
            flags[n[1][0][0][2][1]] += 1
        elif n[0] == 'Assign' and len(n[1]) == 1 and n[1][0][0] == 'Name' and n[2] and n[2][0][0] == 'Bin'                 and n[2][0][1] in ('+', '-') and n[2][0][2] == n[1][0] and free(n[1][0][1]):
            pcs[n[1][0][1]] += 1
        if n[0] == 'Call' and len(n[2]) == 3 and all(x[0] == 'Name' for x in n[2]) and free(n[2][0][1]):
            first3[n[2][0][1]] += 1
    destr = Counter()

    def g_(n):
        # `local E = i[1]; local x = i[2]; ...`: the handler unpacks its operand table into locals
        if n[0] == 'Local' and len(n[1]) == 1 and n[2] and n[2][0][0] == 'Index' and n[2][0][1][0] == 'Name'                 and n[2][0][2][0] == 'Number' and free(n[2][0][1][1]):
            destr[n[2][0][1][1]] += 1
    def declare(names):
        lex_scopes[-1].update(names)

    def visit_block(block):
        lex_scopes.append(set())
        for st in block:
            visit(st)
        lex_scopes.pop()

    def visit(node):
        if isinstance(node, list):
            for z in node:
                visit(z)
            return
        if not isinstance(node, tuple) or not node or not isinstance(node[0], str):
            if isinstance(node, tuple):
                for z in node:
                    visit(z)
            return
        t = node[0]
        f(node)
        g_(node)
        if t == 'Local':
            for e in node[2]:
                visit(e)
            for k, nm in enumerate(node[1]):
                init = node[2][k] if k < len(node[2]) else None
                if init is not None and init[0] == 'Index' and init[1][0] == 'Name' and init[2][0] != 'Number':
                    continue                  # `local F = F[e]`: the same role, re-bound
                declare([nm])
        elif t == 'LocalFunction':
            declare([node[1]])
            visit(node[2])
        elif t == 'Function':
            lex_scopes.append(set(node[1]))
            visit_block(node[3])
            lex_scopes.pop()
        elif t == 'Do':
            visit_block(node[1])
        elif t == 'While':
            visit(node[1])
            visit_block(node[2])
        elif t == 'Repeat':
            visit_block(node[1])
            visit(node[2])
        elif t == 'If':
            for cond, blk in node[1]:
                visit(cond)
                visit_block(blk)
            if node[2]:
                visit_block(node[2])
        elif t == 'NumFor':
            for e in node[2:5]:
                if e is not None:
                    visit(e)
            lex_scopes.append({node[1]})
            visit_block(node[5])
            lex_scopes.pop()
        elif t == 'GenFor':
            for e in node[2]:
                visit(e)
            lex_scopes.append(set(node[1]))
            visit_block(node[3])
            lex_scopes.pop()
        else:
            for z in node[1:]:
                visit(z)
    if scoped:
        visit_block(body)
    else:
        lp.walk(body, f)
        lp.walk(body, g_)
    u = a = None
    if upair:
        u = upair.most_common(1)[0][0]
    if pair:
        cands = [(cnt, k[1]) for k, cnt in pair.items() if k[0] == u] or [(cnt, k[1]) for k, cnt in pair.items()]
        a = max(cands)[1]
        if u is None:
            u = pair.most_common(1)[0][0][0]
    else:
        cand = [k for k, _ in direct.most_common() if k != u]
        if not cand:
            return None
        a = cand[0]
    if destr:
        dname, dcnt = destr.most_common(1)[0]
        cur = pair.get((u, a), 0) if (u and a) else 0
        if dcnt >= 6 and dname != u and dcnt >= 3 * max(cur, 1):
            a = dname
    if not xs and first3:
        # constant fetch with an operand alias:  H(proto, K, seed)
        cands = [k for k, _ in first3.most_common() if k not in (u, a)]
        if cands:
            xs[cands[0]] = first3[cands[0]]
    return Roles(u, a, xs.most_common(1)[0][0] if xs else None,
                 pcs.most_common(1)[0][0] if pcs else None,
                 flags.most_common(1)[0][0] if flags else None)


def discover_roles(vm, ast_leaf_cases):
    """Find (u, a, x, pc, flag) names from handler bodies using only syntax."""
    from collections import Counter
    cnt = Counter()
    xs = Counter()
    flags = Counter()
    pcs = Counter()

    def f(n):
        if n[0] == 'Index' and n[1][0] == 'Name' and n[2][0] == 'Index' and n[2][1][0] == 'Name' \
                and n[2][2][0] == 'Number':
            cnt[(n[1][1], n[2][1][1])] += 1
        elif n[0] == 'Call' and len(n[2]) == 3 and n[2][0][0] == 'Name' and n[2][1][0] == 'Index' \
                and n[2][1][1][0] == 'Name' and n[2][2][0] == 'Name':
            xs[n[2][0][1]] += 1
        elif n[0] == 'If' and len(n[1]) == 1 and n[1][0][0][0] == 'Un' and n[1][0][0][1] == 'not' \
                and n[1][0][0][2][0] == 'Name' and n[1][0][1] and n[1][0][1][0][0] == 'Return' \
                and not n[1][0][1][0][1]:
            flags[n[1][0][0][2][1]] += 1
        elif n[0] == 'Assign' and len(n[1]) == 1 and n[1][0][0] == 'Name' and n[2] and n[2][0][0] == 'Bin' \
                and n[2][0][1] == '+' and n[2][0][2] == n[1][0] and n[2][0][3][0] == 'Number':
            pcs[n[1][0][1]] += 1
    for body in list(ast_leaf_cases)[:40]:
        lp.walk(body, f)
    u, a = cnt.most_common(1)[0][0]
    x = xs.most_common(1)[0][0] if xs else None
    flag = flags.most_common(1)[0][0] if flags else None
    pc = pcs.most_common(1)[0][0] if pcs else None
    return Roles(u, a, x, pc, flag)
