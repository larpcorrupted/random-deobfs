"""Static sweep: decode every reachable instruction of every user proto with the VM's own decoder.

The program is not run.  A replay of the stored DRM session is driven by a sweep-instrumented VM
(``prepare.instrument(..., sweep=True)``): registers are dummies, global writes are dropped and every
pc assignment is redirected to a pc the tool has not decoded yet.  Each decoded instruction leaves
the same trace row as a normal run (handler selector, operands, constants decoded on the way), so
the existing lifter works on the result unchanged.

The tool owns the frontier: after every replay it builds the control-flow graph of what is decoded,
asks for the successors that are still missing and replays again until there are none.  Targets that
the VM cannot fetch (padding, impossible fall-throughs) are remembered as dead.
"""
import collections
import time

from . import capture, cfg, trace

_NODE_CACHE = {}
_DEADLINE = float('inf')


def _out_of_time():
    return time.time() > _DEADLINE


def _nodes(pm):
    """_nodes(pm), memoised on the size of what it is built from (it is called for every proto
    in every round of the sweep)."""
    key = (id(pm), len(pm.instrs), sum(len(v) for v in pm.edges.values()), len(pm.entry), len(getattr(pm, 'entry_sw', ())))
    hit = _NODE_CACHE.get(id(pm))
    if hit is not None and hit[0] == key:
        return hit[1]
    nodes = cfg.build_nodes(pm)
    _NODE_CACHE[id(pm)] = (key, nodes)
    return nodes


def _frontier(model, dead):
    targets = {}
    targets_all = {}
    for pid in sorted(model.keep):
        pm = model.protos.get(pid)
        if pm is None:
            continue
        nodes = _nodes(pm)
        fr = set()
        for nd in nodes.values():
            succ = list(nd.succ)
            if nd.real_fall is not None:
                succ.append(nd.real_fall)
            for s in succ:
                if isinstance(s, int) and 0 <= s < cfg.SEG and s not in pm.instrs and s not in dead[pid]:
                    fr.add(s)
        if fr:
            targets[pid] = sorted(fr)
        # every known pc is visited again: the closures the proto creates must exist to be swept too
        targets_all[pid] = sorted(fr | set(y for y in pm.instrs if y not in dead[pid]))
    return targets, targets_all


def _prelude(base_prelude, keep, targets, extra=''):
    user = '__SWUSER = {%s}' % ','.join('[%d]=true' % p for p in sorted(keep))
    swt = '__SWT = {%s}' % ','.join('[%d]={%s}' % (p, ','.join(str(y) for y in ys)) for p, ys in sorted(targets.items()))
    return (base_prelude + extra + user + chr(10) + swt + chr(10) + '__SWEEP = true' + chr(10)
            + '__OPMAX = 1500000' + chr(10) + '__WALL = 25' + chr(10) + '__SWBUDGET = 12' + chr(10) + '__SWCALLSECS = 2' + chr(10))


def sweep(sweep_src, workdir, model, base_prelude='', log=lambda s: None, max_iter=80, timeout=150, budget=900):
    """Grow ``model`` with the instructions reachable from the entry of every user proto.
    Returns (iterations, instructions decoded by the sweep).

    A first pass runs on dummy registers.  Some VMs reject that (their instruction pages are signed and
    the dummy values leak into the signature check): whatever is still undecoded afterwards is attempted
    by a second pass that leaves the registers alone (the pc steering, the dummy globals and the
    dropped global writes stay)."""
    global _DEADLINE
    _DEADLINE = time.time() + budget          # the whole sweep (all passes and rounds) stops here
    before_total = sum(len(pm.instrs) for pm in model.protos.values())
    its = 0
    for mode in ('', '__SWNOSAND = true' + chr(10)):
        if mode and not _frontier(model, collections.defaultdict(set))[0]:
            break
        its += _one_pass(sweep_src, workdir, model, base_prelude + mode, log, max_iter, timeout)
    after_total = sum(len(pm.instrs) for pm in model.protos.values())
    return its, after_total - before_total


def _one_pass(sweep_src, workdir, model, base_prelude, log, max_iter, timeout):
    dead = collections.defaultdict(set)
    it = 0
    for it in range(max_iter):
        targets, visit = _frontier(model, dead) if it else ({}, {})
        if it and (not targets or _out_of_time()):
            break
        name = 'sw'
        out, rc, killed, dt = capture.replay(sweep_src, workdir, name,
                                             prelude=_prelude(base_prelude, model.keep, visit), timeout=timeout)
        run = trace.parse_run(out)
        n0 = sum(len(pm.instrs) for pm in model.protos.values())
        model.add_run(run)
        n1 = sum(len(pm.instrs) for pm in model.protos.values())
        asked = 0
        for pid, ys in targets.items():
            pm = model.protos.get(pid)
            for y in ys:
                asked += 1
                if pm is None or y not in pm.instrs:
                    dead[pid].add(y)
        log('  sweep #%d: %d target(s) asked, +%d instruction(s), rc=%s killed=%s (%.1fs)' % (
            it + 1, asked, n1 - n0, rc, killed, dt))
        if it and n1 == n0:
            break
    it += _flip_rounds(sweep_src, workdir, model, base_prelude, dead, log)
    it += _constant_rounds(sweep_src, workdir, model, base_prelude, dead, log)
    return it + 1


def _undecoded_branches(model, dead):
    """[(key, pid, y)] for every conditional node with a successor that is not decoded (a pc assignment
    only happens on one side of the condition, so the sweep alone never reaches the other side)."""
    out = []
    for pid in sorted(model.keep):
        pm = model.protos.get(pid)
        if pm is None:
            continue
        for y, nd in sorted(_nodes(pm).items()):
            if nd.kind != 'cond' or nd.j is None or len(nd.succ) != 2:
                continue
            succ = [nd.succ[0], nd.real_fall if nd.real_fall is not None else nd.succ[1]]
            if any(isinstance(t, int) and 0 <= t < cfg.SEG and t not in pm.instrs for t in succ):
                out.append(('%d:%d:%d' % (pid, y % cfg.SEG, nd.j), pid, y % cfg.SEG))
    return out


def _flip_rounds(sweep_src, workdir, model, base_prelude, dead, log, group=6, max_rounds=40, budget=240):
    """Sweep replays that also invert the branch conditions leading to undecoded code (``__FORCE``), a few
    at a time so that one inverted condition does not hide the effect of another."""
    import time as _t
    from . import explore
    t0 = _t.time()
    tried = set()
    good = {}           # inverted branches that led to new code stay inverted: later branches sit behind them
    used = 0
    for rnd in range(max_rounds):
        cands = [c for c in _undecoded_branches(model, dead) if c[0] not in tried]
        if not cands or _t.time() - t0 > budget or _out_of_time():
            break
        flips = dict(good)
        fresh = {}
        seen_pid = set()
        for key, pid, y in cands:                  # at most one inverted branch per proto and round
            if pid in seen_pid:
                continue
            seen_pid.add(pid)
            flips[key] = 1
            fresh[key] = 1
            tried.add(key)
            if len(fresh) >= group:
                break
        # dead targets are asked again: the inverted branch may make them reachable
        for pid in list(dead):
            dead[pid].clear()
        _t_, visit = _frontier(model, dead)
        out, rc, killed, dt = capture.replay(
            sweep_src, workdir, 'sw', prelude=_prelude(base_prelude, model.keep, visit, explore.force_prelude(flips)),
            timeout=150)
        run = trace.parse_run(out)
        i0 = sum(len(pm.instrs) for pm in model.protos.values())
        model.add_run(run)
        i1 = sum(len(pm.instrs) for pm in model.protos.values())
        used += 1
        log('  sweep flips #%d: %d branch(es) inverted, +%d instruction(s), rc=%s (%.1fs)' % (
            rnd + 1, len(flips), i1 - i0, rc, dt))
        if i1 > i0:
            good.update(fresh)
            _follow(sweep_src, workdir, model, base_prelude, dead, log)
    return used


def _missing_consts(model):
    """{(pid, y): [constant index, ...]} referenced by a decoded instruction but not decoded yet."""
    from . import explore
    out = {}
    for pid in model.keep:
        pm = model.protos.get(pid)
        if pm is None or not pm.const_field:
            continue
        for y, ins in pm.instrs.items():
            miss = [k for k in explore.referenced_consts(pm, {y}) if str(k) not in pm.consts]
            if miss:
                out[(pid, y)] = miss
    return out


def _constant_rounds(sweep_src, workdir, model, base_prelude, dead, log, max_rounds=6):
    """A constant is decoded when the handler really executes the micro-op that reads it, and the sweep
    leaves a fused handler at the first taken ``pc`` branch.  For every instruction with an undecoded
    constant the branches of that instruction are inverted (``__FORCE``, one branch per instruction and
    round) so the other side of the handler runs as well."""
    from . import explore
    used = 0
    tried = set()
    for rnd in range(max_rounds):
        miss = _missing_consts(model)
        if not miss or _out_of_time():
            break
        keys_of = {}
        for pid in model.keep:
            pm = model.protos.get(pid)
            if pm is None:
                continue
            ys = {y for (p_, y) in miss if p_ == pid}
            if not ys:
                continue
            for y, nd in _nodes(pm).items():
                if nd.kind == 'cond' and nd.j is not None and y % cfg.SEG in ys:
                    keys_of.setdefault((pid, y % cfg.SEG), set()).add('%d:%d:%d' % (pid, y % cfg.SEG, nd.j))
        flips = {}
        for (pid, y), keys in keys_of.items():
            todo = [k for k in sorted(keys) if k not in tried]
            if todo:
                flips[todo[0]] = 1
                tried.add(todo[0])
        if not flips:
            break
        _t, visit = _frontier(model, dead)
        out, rc, killed, dt = capture.replay(
            sweep_src, workdir, 'sw', prelude=_prelude(base_prelude, model.keep, visit, explore.force_prelude(flips)),
            timeout=150)
        run = trace.parse_run(out)
        n0 = sum(len(pm.consts) for pm in model.protos.values())
        i0 = sum(len(pm.instrs) for pm in model.protos.values())
        model.add_run(run)
        n1 = sum(len(pm.consts) for pm in model.protos.values())
        i1 = sum(len(pm.instrs) for pm in model.protos.values())
        used += 1
        log('  sweep constants #%d: %d branch(es) inverted, +%d constant(s), +%d instruction(s), rc=%s (%.1fs)' % (
            rnd + 1, len(flips), n1 - n0, i1 - i0, rc, dt))
        if i1 > i0:     # new code behind a flipped branch: let the sweep follow it
            more, _ = _follow(sweep_src, workdir, model, base_prelude, dead, log)
    return used


def _follow(sweep_src, workdir, model, base_prelude, dead, log, max_iter=20):
    n_added = 0
    for _ in range(max_iter):
        targets, visit = _frontier(model, dead)
        if not targets or _out_of_time():
            break
        out, rc, killed, dt = capture.replay(sweep_src, workdir, 'sw',
                                             prelude=_prelude(base_prelude, model.keep, visit), timeout=150)
        run = trace.parse_run(out)
        n0 = sum(len(pm.instrs) for pm in model.protos.values())
        model.add_run(run)
        n1 = sum(len(pm.instrs) for pm in model.protos.values())
        for pid, ys in targets.items():
            pm = model.protos.get(pid)
            for y in ys:
                if pm is None or y not in pm.instrs:
                    dead[pid].add(y)
        n_added += n1 - n0
        log('    follow-up sweep: +%d instruction(s), rc=%s (%.1fs)' % (n1 - n0, rc, dt))
        if n1 == n0:
            break
    return n_added, 0
