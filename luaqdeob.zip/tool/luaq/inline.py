"""Inline single-definition, single-use variables into their use site while
preserving the evaluation order of calls and reads."""
from . import opt
from .emit import render_expr
from .post import first_eval_is, replace_var, is_trivial, has_call


def _exprs_of(s):
    t = s[0]
    if t in ('callres', 'local', 'multi'):
        return [s[2]]
    if t == 'assign':
        return ([s[1]] if s[1][0] != 'var' else []) + [s[2]]
    if t in ('callstmt', 'if', 'while'):
        return [s[1]]
    if t == 'return':
        return list(s[1])
    return []


def _uses_var(s, name):
    found = []
    for e in _exprs_of(s):
        opt.walk_e(e, lambda x: found.append(1) if x == ('var', name) else None)
    return bool(found)


def _global_read(e):
    """A property read chain rooted at a global (`workspace.CurrentCamera`): reading it is
    observable (it may trigger __index), so an unused result is still emitted."""
    if e[0] != 'index':
        return False
    if e[2][0] == 'lit' and isinstance(e[2][1], str):
        # `local LocalPlayer = Players.LocalPlayer` (a property read the program never uses): the read is
        # observable (__index of an object) and is what the author wrote
        b = e[1]
        while b[0] == 'index':
            b = b[1]
        if b[0] in ('glob', 'var', 'call', 'mcall'):
            return True
    while e[0] == 'index':
        e = e[1]
    return e[0] == 'glob'


def _observable_read(e):
    """Does evaluating e read something whose order the program can observe: a property of an object
    (`Lighting.ClockTime`, __index) or a global?  A call must not be moved across such a read."""
    from .validate import NOISE_G
    found = []

    def f(x):
        if x[0] == 'index' and x[2][0] == 'lit' and isinstance(x[2][1], str):
            found.append(1)
        elif x[0] == 'glob' and x[1] not in NOISE_G:
            found.append(1)
    opt.walk_e(e, f)
    return bool(found)


# reads of these globals/members are moved freely: they are VM-internal or standard-library lookups
# (their events are filtered by the differential, and user code does not rebind them)
_STABLE_LIBS = {'debug', 'string', 'table', 'math', 'os', 'coroutine', 'utf8', 'bit32', 'buffer', 'task'}


def _stable_read(e):
    from .validate import NOISE_G
    if e[0] == 'glob':
        return e[1] in NOISE_G
    if e[0] == 'index' and e[1][0] == 'glob' and e[1][1] in _STABLE_LIBS and e[2][0] == 'lit':
        return True
    return False


def _pure(e, defs):
    """Evaluating e has no observable effect and its value cannot change with time: literals, closures,
    single-definition variables and tables built from those.  Such an expression may move anywhere."""
    t = e[0]
    if t in ('lit', 'func'):
        return True
    if t == 'var':
        return len(defs.get(e[1], [])) == 1 and e[1] not in _BOUND
    if t == 'paren':
        return _pure(e[1], defs)
    if t == 'table':
        for it in e[1]:
            if it[0] == 'kv':
                if not (_pure(it[1], defs) and _pure(it[2], defs)):
                    return False
            elif not _pure(it, defs):
                return False
        return True
    if t == 'un' and e[1] == '-' and e[2][0] == 'lit':
        return True
    return False


def _called_directly(s, name):
    found = []
    for e in _exprs_of(s):
        opt.walk_e(e, lambda x: found.append(1) if x[0] == 'call' and x[1] == ('var', name) else None)
    return bool(found)


def _fei(stable, e, name):
    return stable or first_eval_is(e, name)


def _inline_block(block, defs, uses, flag):
    # recurse
    res = []
    for s in block:
        t = s[0]
        if t == 'if':
            s = ('if', s[1], _inline_block(s[2], defs, uses, flag), _inline_block(s[3], defs, uses, flag))
        elif t == 'while':
            s = ('while', s[1], _inline_block(s[2], defs, uses, flag))
        res.append(s)
    # closures inside expressions
    def fn(x):
        if x[0] == 'func':
            return ('func', x[1], _inline_block(list(x[2]), defs, uses, flag), x[3])
        return x
    res = [opt.map_block([s], fn)[0] if s[0] not in ('if', 'while') else s for s in res]

    k = 0
    while k < len(res):
        s = res[k]
        if s[0] == 'callres':
            name, expr = s[1], s[2]
        elif s[0] == 'assign' and s[1][0] == 'var':
            name, expr = s[1][1], s[2]
        else:
            k += 1
            continue
        if len(defs.get(name, [])) != 1 or name in _BOUND:
            k += 1
            continue
        u = uses.get(name, 0)
        if u == 0:
            if s[0] == 'callres' and _global_read(expr):
                k += 1                # `local x = workspace.CurrentCamera`: an observable property read
                continue
            if s[0] == 'callres' and expr[0] == 'mcall' and expr[2] == 'GetService' and expr[3] \
                    and expr[3][0][0] == 'lit':
                k += 1                # `local TweenService = game:GetService("TweenService")` kept as written
                continue
            if s[0] == 'callres' or has_call(expr):
                if expr[0] in ('call', 'mcall'):
                    res[k] = ('callstmt', expr)
                    flag[0] = True
                    k += 1
                    continue
            if not has_call(expr):
                del res[k]
                flag[0] = True
                continue
            # (an unused value that still calls something, e.g. a box `v = {game:GetService("X")}`: the call stays)
            k += 1
            continue
        if u != 1:
            k += 1
            continue
        j = k + 1
        target = None
        stable = _stable_read(expr)
        # a variable with a single definition (earlier in this block) never changes afterwards:
        # reading it later gives the same value, whatever the statements in between do
        stable_var = expr[0] == 'var' and len(defs.get(expr[1], [])) == 1 and expr[1] != name             and expr[1] not in _BOUND
        stable = stable or stable_var or _pure(expr, defs)
        while j < len(res):
            sj = res[j]
            if _uses_var(sj, name):
                target = j
                break
            if sj[0] == 'assign' and sj[1][0] == 'var' and not has_call(sj[2]) \
                    and sj[1] != ('var', name) and (stable or not _observable_read(sj[2])):
                j += 1
                continue
            if stable and sj[0] in ('callres', 'local', 'assign', 'callstmt', 'multi') \
                    and not (sj[0] == 'assign' and sj[1][0] == 'glob'):
                j += 1                  # a library lookup can move across any simple statement
                continue
            break
        if target is None:
            k += 1
            continue
        sj = res[target]
        if expr[0] == 'func' and _called_directly(sj, name):
            k += 1                 # a named local function stays named: `(function(...) ... end)(x)` is unreadable
            continue
        t = sj[0]
        ok = False
        new = None
        if t in ('assign', 'local', 'callres'):
            if t == 'assign' and sj[1][0] != 'var':
                lhs, rhs = sj[1], sj[2]
                if _fei(stable, lhs, name) or (is_trivial(lhs) and _fei(stable, rhs, name)) \
                        or (lhs[0] == 'index' and is_trivial(lhs[1]) and is_trivial(lhs[2]) and _fei(stable, rhs, name)):
                    ok = True
                    new = ('assign', replace_var(lhs, name, expr), replace_var(rhs, name, expr))
            else:
                if _fei(stable, sj[2], name):
                    ok = True
                    if t == 'assign':
                        new = ('assign', sj[1], replace_var(sj[2], name, expr))
                    else:
                        new = (t, sj[1], replace_var(sj[2], name, expr))
        elif t == 'callstmt':
            if _fei(stable, sj[1], name):
                ok = True
                new = ('callstmt', replace_var(sj[1], name, expr))
        elif t == 'if':
            if _fei(stable, sj[1], name):
                ok = True
                new = ('if', replace_var(sj[1], name, expr), sj[2], sj[3])
        elif t == 'while' and sj[1][0] == 'forin':
            hd = sj[1][2]
            for hi, hx in enumerate(hd):          # `for i = 1, n do` with `local n = #t` just before
                if _fei(stable, hx, name):
                    ok = True
                    new_hd = list(hd)
                    new_hd[hi] = replace_var(hx, name, expr)
                    new = ('while', ('forin', sj[1][1], new_hd) + tuple(sj[1][3:]), sj[2])
                    break
                if not is_trivial(hx):
                    break
        elif t == 'return':
            for v in sj[1]:
                if _fei(stable, v, name):
                    ok = True
                    break
                if not is_trivial(v):
                    break
            if ok:
                new = ('return', [replace_var(v, name, expr) for v in sj[1]])
        if ok:
            res[target] = new
            del res[k]
            flag[0] = True
            continue
        k += 1
    return res


_BOUND = set()       # parameters / loop variables of the program being inlined (set by inline_all)


def inline_all(ir, rounds=12):
    global _BOUND
    for _ in range(rounds):
        defs, uses = opt.collect(ir)
        _BOUND = opt.bound_names(ir)
        flag = [False]
        ir = _inline_block(ir, defs, uses, flag)
        if not flag[0]:
            break
    return ir
