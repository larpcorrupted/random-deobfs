"""Source-shape passes: give the lifted program back the shape a person writes.

The VM spells `x = {Name = "a", Size = 3}` as `x = {}; x.Name = "a"; x.Size = 3` and `obj:M({...})` as
`m = obj.M; t = {}; t.k = v; m(obj, t)`.  The passes here undo exactly those spellings and nothing else:
every rewrite keeps the order in which calls and reads are evaluated.
"""
from . import opt


def _mentions(e, name):
    found = []
    opt.walk_e(e, lambda x: found.append(1) if x == ('var', name) else None)
    return bool(found)


def _def_of(s):
    """(name, expr) for `name = expr` statements, else None."""
    if s[0] in ('callres', 'local'):
        return s[1], s[2]
    if s[0] == 'assign' and s[1][0] == 'var':
        return s[1][1], s[2]
    return None


def _is_ident(k):
    from .emit import is_ident
    return isinstance(k, str) and is_ident(k)


def _single_value(v):
    # a call/vararg as a positional item would expand to all its values
    if v[0] in ('call', 'mcall', 'vararg', 'unpack'):
        return ('paren', v)
    return v


def _fold_block(block):
    out = []
    i = 0
    n = len(block)
    while i < n:
        s = block[i]
        d = _def_of(s)
        if d is not None and d[1][0] == 'table' and not any(it[0] == 'unpack' for it in d[1][1]):
            name, tbl = d
            items = list(tbl[1])
            keys = set()
            npos = 0
            for it in items:
                if it[0] == 'kv':
                    if it[1][0] == 'lit':
                        keys.add(('k', it[1][1]))
                else:
                    npos += 1
            j = i + 1
            while j < n:
                sj = block[j]
                if not (sj[0] == 'assign' and sj[1][0] == 'index' and sj[1][1] == ('var', name)):
                    break
                key, val = sj[1][2], sj[2]
                if key[0] != 'lit' or _mentions(val, name) or ('k', key[1]) in keys:
                    break
                k = key[1]
                if isinstance(k, (int, float)) and not isinstance(k, bool) and float(k).is_integer() \
                        and int(k) == npos + 1 and not any(it[0] == 'kv' and isinstance(it[1][1], (int, float))
                                                           for it in items if it[0] == 'kv'):
                    items.append(_single_value(val))
                    npos += 1
                else:
                    items.append(('kv', key, val))
                keys.add(('k', k))
                j += 1
            if j > i + 1:
                new_tbl = ('table', items)
                if s[0] == 'assign':
                    s = ('assign', s[1], new_tbl)
                else:
                    s = (s[0], s[1], new_tbl)
                out.append(s)
                i = j
                continue
        out.append(s)
        i += 1
    return out


def fold_constructors(block):
    """`T = {}; T.a = x; T.b = y` (consecutive stores of literal keys into the table just built, values not
    mentioning T) -> `T = {a = x, b = y}`."""
    def rec(b):
        b = [_rec_stmt(s) for s in b]
        return _fold_block(b)

    def _rec_stmt(s):
        t = s[0]
        if t == 'if':
            return ('if', s[1], rec(s[2]), rec(s[3]))
        if t == 'while':
            return ('while', s[1], rec(s[2]))
        return opt.map_block([s], lambda x: ('func', x[1], rec(list(x[2])), x[3]) if x[0] == 'func' else x)[0]
    return rec(list(block))


def _has_call(e):
    found = []
    opt.walk_e(e, lambda x: found.append(1) if x[0] in ('call', 'mcall') else None)
    return bool(found)


def _quiet_cond(e):
    # locals, literals and operators only: evaluating it reads nothing observable (no global, no field)
    t = e[0]
    if t in ('var', 'lit'):
        return True
    if t == 'un':
        return _quiet_cond(e[2])
    if t == 'bin' and e[1] in ('and', 'or', '==', '~='):
        return _quiet_cond(e[2]) and _quiet_cond(e[3])
    return False


def tidy(block):
    """Last touches before naming: an `if` with two empty branches and a call-free condition is dropped, and a
    service fetched for nothing (`game:GetService("Players")`) is kept as the local the author wrote."""
    counter = [0]

    def rec(b):
        out = []
        for s in b:
            t = s[0]
            if t == 'if':
                s = ('if', s[1], rec(s[2]), rec(s[3]))
                if not s[2] and not s[3] and _quiet_cond(s[1]):
                    continue
                if not s[2] and s[3]:
                    from .emit import negate
                    s = ('if', negate(s[1]), s[3], [])          # `if C then else B end` -> `if not C then B end`
            elif t == 'while':
                s = ('while', s[1], rec(s[2]))
                # `while true do if not C then break end ... end` -> `while C do ... end`
                body = s[2]
                if s[1] == ('lit', True) and body and body[0][0] == 'if' and body[0][2] == [('break',)]                         and not body[0][3]:
                    from .emit import negate
                    s = ('while', negate(body[0][1]), body[1:])
            else:
                s = opt.map_block([s], lambda x: ('func', x[1], rec(list(x[2])), x[3]) if x[0] == 'func' else x)[0]
            if t == 'return' and len(s[1]) == 1 and s[1][0][0] == 'unpack' and s[1][0][1][0] == 'table'                     and s[1][0][1][1] and all(it[0] != 'kv' for it in s[1][0][1][1]):
                s = ('return', list(s[1][0][1][1]))      # return table.unpack({a, b, f()}) -> return a, b, f()
            if t == 'assign' and s[1][0] == 'index' and s[1][1][0] == 'table' and s[1][2][0] == 'lit' \
                    and not _has_call(s[1][1]) and not _has_call(s[1][2]):
                # `({nil})[1] = function ... end`: a store into a cell nobody keeps (a local function that is never
                # used) -> the local it was
                counter[0] += 1
                s = ('local', 'v9%07d' % counter[0], s[2])
            if t == 'if' and s[1][0] == 'un' and s[1][1] == 'not' and s[2] and s[3]:
                s = ('if', s[1][2], s[3], s[2])        # `if not C then A else B end` -> `if C then B else A end`
            if t == 'callstmt' and s[1][0] == 'mcall' and s[1][2] == 'GetService' and s[1][3] \
                    and s[1][3][0][0] == 'lit' and isinstance(s[1][3][0][1], str):
                counter[0] += 1
                s = ('callres', 'v9%07d' % counter[0], s[1])
            out.append(s)
        return out
    return rec(list(block))


# ------------------------------------------------------------------ generic for with early exits
_PACK = ('index', ('glob', 'table'), ('lit', 'pack'))


def _explist_of(v):
    if v[0] == 'table' and len(v[1]) == 1 and v[1][0][0] == 'unpack':
        v = v[1][0][1]
    if v[0] == 'call' and v[1] == _PACK and len(v[2]) == 1:
        return v[2][0]
    if v[0] == 'table' and len(v[1]) == 1 and v[1][0][0] in ('call', 'mcall'):
        return v[1][0]
    return None


def _count_uses(node, name):
    n = [0]

    def f(e):
        if e == ('var', name):
            n[0] += 1
    if isinstance(node, list):
        opt.walk_b(node, f)
    else:
        opt.walk_e(node, f)
    return n[0]


def _rename_var(block, old, new):
    from .post import replace_var

    def ren_e(e):
        return replace_var(e, old, ('var', new))

    def ren_b(b):
        out = []
        for s in b:
            t = s[0]
            if t in ('callres', 'local'):
                out.append((t, new if s[1] == old else s[1], ren_e(s[2])))
            elif t == 'assign':
                lhs = ('var', new) if s[1] == ('var', old) else ren_e(s[1])
                out.append(('assign', lhs, ren_e(s[2])))
            elif t == 'multi':
                out.append(('multi', [new if n_ == old else n_ for n_ in s[1]], ren_e(s[2])))
            elif t == 'callstmt':
                out.append(('callstmt', ren_e(s[1])))
            elif t == 'if':
                out.append(('if', ren_e(s[1]), ren_b(s[2]), ren_b(s[3])))
            elif t == 'while':
                c = s[1]
                if c[0] == 'forin':
                    c = ('forin', [new if n_ == old else n_ for n_ in c[1]], [ren_e(x) for x in c[2]]) + tuple(c[3:])
                else:
                    c = ren_e(c)
                out.append(('while', c, ren_b(s[2])))
            elif t == 'return':
                out.append(('return', [ren_e(v) for v in s[1]]))
            else:
                out.append(s)
        return out
    return ren_b(block)


def _before_breaks(block, extra):
    """Insert the statements `extra()` before every `break` of this loop (not of an inner loop)."""
    out = []
    for s in block:
        t = s[0]
        if t == 'break':
            out.extend(extra())
            out.append(s)
        elif t == 'if':
            out.append(('if', s[1], _before_breaks(s[2], extra), _before_breaks(s[3], extra)))
        else:
            out.append(s)
    return out


def recover_forin_exits(root):
    """The VM's generic `for` (iterator record R = {f, s, c}; `k, v = R[1](R[2], R[3]); R[3] = k;
    if k == nil then [flag = K;] break end`) when the loop also has other exits (a flag tells them apart
    after the loop) or its variables are read after the loop.  The loop becomes `for k, v in E do`; the
    flag starts at its "exhausted" value and every other `break` first restores the value it had before;
    a loop variable read after the loop is copied to its outer variable right before each `break`."""
    counter = [0]

    def try_fold(b, i):
        s = b[i]
        if s[0] in ('callres', 'local'):
            r, init = s[1], s[2]
        elif s[0] == 'assign' and s[1][0] == 'var':
            r, init = s[1][1], s[2]
        else:
            return None
        e = _explist_of(init)
        if e is None:
            return None
        j = i + 1
        between = []
        while j < len(b) and b[j][0] == 'assign' and b[j][1][0] == 'var' and b[j][2][0] == 'lit' \
                and b[j][1][1] != r:
            between.append(b[j])
            j += 1
        if j >= len(b) or b[j][0] != 'while' or b[j][1] != ('lit', True) or len(b[j][2]) < 3:
            return None
        body = b[j][2]
        R = ('var', r)
        step = ('call', ('index', R, ('lit', 1)), [('index', R, ('lit', 2)), ('index', R, ('lit', 3))])
        head = body[0]
        if head[0] == 'multi' and head[2] == step:
            names = list(head[1])
        elif head[0] in ('callres', 'local') and head[2] == step:
            names = [head[1]]
        else:
            return None
        if body[1] != ('assign', ('index', R, ('lit', 3)), ('var', names[0])):
            return None
        test = body[2]
        if test[0] != 'if' or test[1] != ('bin', '==', ('var', names[0]), ('lit', None)) or test[3]:
            return None
        thn = test[2]
        flag = None
        if thn == [('break',)]:
            pass
        elif len(thn) == 2 and thn[1] == ('break',) and thn[0][0] == 'assign' and thn[0][1][0] == 'var' \
                and thn[0][2][0] == 'lit':
            flag = (thn[0][1][1], thn[0][2])
        else:
            return None
        if _count_uses(root, r) != 4:
            return None
        rest = list(body[3:])
        if rest and rest[-1] == ('continue',):
            rest = rest[:-1]
        new_between = list(between)
        pre_break = []
        if flag is not None:
            fname, kval = flag
            init = [st for st in between if st[1] == ('var', fname)]
            if len(init) != 1:
                return None
            ival = init[0][2]
            new_between = [(('assign', ('var', fname), kval) if st[1] == ('var', fname) else st) for st in between]
            pre_break.append(('assign', ('var', fname), ival))
        # loop variables read after the loop keep an outer variable, set right before each break
        after = b[j + 1:]
        loop_names = list(names)
        for k_, nm in enumerate(names):
            if _count_uses(after, nm) or any(_count_uses([x], nm) for x in b[:i]):
                counter[0] += 1
                inner = '%s_9%d' % (nm, counter[0])          # (still a generated name: renamed by naming)
                rest = _rename_var(rest, nm, inner)
                loop_names[k_] = inner
                pre_break.append(('assign', ('var', nm), ('var', inner)))
                new_between.append(('assign', ('var', nm), ('lit', None)))
        if pre_break:
            rest = _before_breaks(rest, lambda: list(pre_break))
        loop = ('while', ('forin', loop_names, [e]), rest)
        return new_between + [loop], j + 1

    def rec(b):
        b = [_stmt(s) for s in b]
        out = []
        i = 0
        while i < len(b):
            r = try_fold(b, i)
            if r is not None:
                out.extend(r[0])
                i = r[1]
                continue
            out.append(b[i])
            i += 1
        return out

    def _stmt(s):
        t = s[0]
        if t == 'if':
            return ('if', s[1], rec(s[2]), rec(s[3]))
        if t == 'while':
            return ('while', s[1], rec(s[2]))
        return opt.map_block([s], lambda x: ('func', x[1], rec(list(x[2])), x[3]) if x[0] == 'func' else x)[0]
    return rec(list(root))


# ------------------------------------------------------------------ copies made on both sides of an `if`
def _assigned_names(block):
    out = []

    def f(s):
        t = s[0]
        if t in ('callres', 'local'):
            out.append(s[1])
        elif t == 'assign' and s[1][0] == 'var':
            out.append(s[1][1])
        elif t == 'multi':
            out.extend(s[1])
        elif t == 'if':
            for b in (s[2], s[3]):
                for x in b:
                    f(x)
        elif t == 'while':
            if s[1][0] == 'forin':
                out.extend(s[1][1])
            for x in s[2]:
                f(x)
    for s in block:
        f(s)
    return out


def _reads_after_copy(block, x):
    """In this branch, x is read only after its (top-level) copy statement."""
    for st in block:
        if st[0] == 'assign' and st[1] == ('var', x):
            return not _count_uses([('callstmt', st[2])], x)
        if _count_uses([st], x):
            return False
    return False


def hoist_branch_copies(root):
    """`if C then ...; x = y ... else ...; x = y ... end` (the same copy of an immutable value on both sides, x not
    otherwise touched by either branch) -> the copy is made once, after the `if`.  The VM's register moves are
    duplicated by the structurer into every path; once they are single definitions, propagation removes them."""
    defs, _uses = opt.collect(root)
    bound = opt.bound_names(root)

    def immutable(e):
        if e[0] == 'lit':
            return True
        if e[0] == 'var':
            nd = len(defs.get(e[1], []))
            # a single assignment, or a parameter / loop variable that is never assigned
            return (nd == 1 and e[1] not in bound) or (nd == 0 and e[1] in bound)
        return False

    in_closures = _shared_names(root)        # upvalues: a call may change them

    def copies(b):
        res = {}
        for s in b:
            if s[0] == 'assign' and s[1][0] == 'var' and (immutable(s[2]) or (
                    s[2][0] == 'var' and s[2][1] not in in_closures)):
                if s[1][1] in res:
                    res[s[1][1]] = None          # assigned twice: leave it
                else:
                    res[s[1][1]] = s[2]
        return res

    def rec(b):
        out = []
        for s in b:
            t = s[0]
            if t == 'if':
                s = ('if', s[1], rec(s[2]), rec(s[3]))
                if s[2] and s[3]:
                    ca, cb = copies(s[2]), copies(s[3])
                    common, before = [], []
                    for x, e in ca.items():
                        if e is None or cb.get(x) != e:
                            continue
                        # x is written only by these two copies inside the if
                        if _assigned_names(s[2]).count(x) != 1 or _assigned_names(s[3]).count(x) != 1:
                            continue
                        if _mentions(s[1], x):
                            continue
                        if e[0] == 'var' and (e[1] in _assigned_names(s[2]) or e[1] in _assigned_names(s[3])):
                            continue
                        if not _count_uses(s[2], x) and not _count_uses(s[3], x):
                            common.append((x, e))          # read nowhere in the if: the copy goes after it
                        elif immutable(e) and all(_reads_after_copy(bb, x) for bb in (s[2], s[3])):
                            before.append((x, e))          # read only after the copy: it goes before the if
                    if common or before:
                        names = {x for x, _ in common} | {x for x, _ in before}

                        def strip(bb):
                            return [st for st in bb if not (st[0] == 'assign' and st[1][0] == 'var'
                                                            and st[1][1] in names)]
                        out.extend(('assign', ('var', x), e) for x, e in before)
                        s = ('if', s[1], strip(s[2]), strip(s[3]))
                        out.append(s)
                        out.extend(('assign', ('var', x), e) for x, e in common)
                        continue
            elif t == 'while':
                s = ('while', s[1], rec(s[2]))
            else:
                s = opt.map_block([s], lambda x: ('func', x[1], rec(list(x[2])), x[3]) if x[0] == 'func' else x)[0]
            out.append(s)
        return out
    return rec(list(root))


# ------------------------------------------------------------------ parallel moves through a temporary table
def _const_pos(k, n):
    return k[0] == 'lit' and isinstance(k[1], (int, float)) and not isinstance(k[1], bool)         and float(k[1]).is_integer() and 1 <= int(k[1]) <= n


def _shared_names(root):
    """Names that occur in more than one function (an upvalue): a call may change them."""
    fids = {}
    counter = [0]

    def blk(b, fid):
        for st in b:
            for n_ in _assigned_names([st]):
                fids.setdefault(n_, set()).add(fid)

            def f(e, fid=fid):
                if e[0] == 'var':
                    fids.setdefault(e[1], set()).add(fid)
            opt.walk_b_shallow([st], f) if hasattr(opt, 'walk_b_shallow') else _walk_shallow([st], f, fid)

    def _walk_shallow(b, f, fid):
        def ex(e):
            if not isinstance(e, tuple) or not e:
                return
            if e[0] == 'func':
                counter[0] += 1
                nf = counter[0]
                for p_ in e[1]:
                    fids.setdefault(p_, set()).add(nf)
                blk(list(e[2]), nf)
                return
            f(e)
            for x in e[1:]:
                if isinstance(x, tuple):
                    ex(x)
                elif isinstance(x, list):
                    for y in x:
                        if isinstance(y, tuple):
                            ex(y)
        for st in b:
            t = st[0]
            if t in ('callres', 'local', 'multi'):
                ex(st[2])
            elif t == 'assign':
                ex(st[1]) if st[1][0] != 'var' else None
                ex(st[2])
            elif t == 'callstmt':
                ex(st[1])
            elif t == 'if':
                ex(st[1])
                _walk_shallow(st[2], f, fid)
                _walk_shallow(st[3], f, fid)
            elif t == 'while':
                c = st[1]
                if c[0] == 'forin':
                    for x in c[2]:
                        ex(x)
                else:
                    ex(c)
                _walk_shallow(st[2], f, fid)
            elif t == 'return':
                for x in st[1]:
                    ex(x)
    blk(list(root), 0)
    return {n_ for n_, s_ in fids.items() if len(s_) > 1}


def _uses_in_funcs(node, name):
    found = []

    def f(e):
        if e[0] == 'func' and _count_uses(list(e[2]), name):
            found.append(1)
    opt.walk_b(node, f) if isinstance(node, list) else opt.walk_e(node, f)
    return bool(found)


def scalarize_tables(root):
    """`T = {a, b}; x = T[1]; y = T[2]` (a table only read at constant positions, right after it is built, while
    its items keep their values) -> `x = a; y = b`.  The VM performs parallel register moves through such a
    temporary table."""
    defs, uses = opt.collect(root)
    bound = opt.bound_names(root)
    done = set()

    def try_block(b):
        b = list(b)
        i = 0
        while i < len(b):
            s = b[i]
            name = s[1] if s[0] in ('local', 'callres') else (s[1][1] if s[0] == 'assign' and s[1][0] == 'var' else None)
            if name is None or name in done or len(defs.get(name, [])) != 1 or name in bound or s[2][0] != 'table':
                i += 1
                continue
            items = s[2][1]
            if not items or any(it[0] == 'kv' or it[0] not in ('var', 'lit') for it in items):
                i += 1
                continue
            total = uses.get(name, 0)
            if total == 0:
                i += 1
                continue
            # all uses: T[k] in the following statements of this block, outside closures
            seen = 0
            last = None
            bad = False
            for j in range(i + 1, len(b)):
                c = _count_uses([b[j]], name)
                if not c:
                    continue
                if _uses_in_funcs([b[j]], name):
                    bad = True
                    break
                cnt = []

                def f(e):
                    if e[0] == 'index' and e[1] == ('var', name) and _const_pos(e[2], len(items)):
                        cnt.append(1)
                opt.walk_b([b[j]], f)
                if len(cnt) != c:
                    bad = True
                    break
                seen += c
                last = j
                if seen == total:
                    break
            if bad or seen != total or last is None:
                i += 1
                continue
            # the items keep their values until the last read
            vars_ = {it[1] for it in items if it[0] == 'var'}
            for j in range(i + 1, last + 1):
                st = b[j]
                if vars_ & set(_assigned_names([st])):
                    # an assignment in the reading statement itself happens after its reads only for `x = T[k]`
                    if j == last and st[0] == 'assign' and st[1][0] == 'var' and not (vars_ & set(_assigned_names(b[i + 1:j]))):
                        continue
                    bad = True
                    break
                if j < last and st[0] not in ('assign', 'local', 'callres'):
                    bad = True             # only straight-line moves between the build and the reads
                    break
            if bad:
                i += 1
                continue

            def fix(e, name=name, items=items):
                if e[0] == 'index' and e[1] == ('var', name) and _const_pos(e[2], len(items)):
                    return items[int(e[2][1]) - 1]
                return e
            b[i + 1:last + 1] = opt.map_block(b[i + 1:last + 1], fix)
            del b[i]
            done.add(name)
        return b

    def rec(b):
        out = []
        for s in b:
            t = s[0]
            if t == 'if':
                s = ('if', s[1], rec(s[2]), rec(s[3]))
            elif t == 'while':
                s = ('while', s[1], rec(s[2]))
            else:
                s = opt.map_block([s], lambda x: ('func', x[1], rec(list(x[2])), x[3]) if x[0] == 'func' else x)[0]
            out.append(s)
        return try_block(out)
    return rec(list(root))


# ------------------------------------------------------------------ per-iteration copies of a fused VM loop
def _def_name(s):
    if s[0] in ('local', 'callres'):
        return s[1]
    if s[0] == 'assign' and s[1][0] == 'var':
        return s[1][1]
    return None


def coalesce_loop_copies(root):
    """Inside a loop body: `a = X; ...uses of a...; X = f(a)` where a is a single-definition copy of X, X is not
    written between the two statements and a is not read after the second one -> the copy is dropped and a is
    X (`X = a` becomes a no-op).  The VM's fused loops snapshot their registers this way on every iteration."""
    defs, uses = opt.collect(root)
    bound = opt.bound_names(root)

    in_closures = _shared_names(root)        # upvalues: a call may change them

    def body_fix(b):
        b = list(b)
        changed = True
        while changed:
            changed = False
            for i, s in enumerate(b):
                a = _def_name(s)
                if a is None or len(defs.get(a, [])) != 1 or a in bound or s[2][0] != 'var':
                    continue
                X = s[2][1]
                if X == a or X in in_closures:
                    continue                 # (a call could change X behind our back)
                ident = ('assign', ('var', X), ('var', a))
                # the region where X == a: up to the next write of X that is not `X = a` (a top-level
                # `X = f(a)` belongs to it: its right side is evaluated before X changes)
                end = len(b)
                for k in range(i + 1, len(b)):
                    if b[k] == ident:
                        continue
                    if X in _assigned_names([b[k]]):
                        end = k + 1 if (b[k][0] == 'assign' and _def_name(b[k]) == X) else k
                        break
                region = b[i + 1:end]
                if not region or _count_uses(region, a) != uses.get(a, 0) or a in _assigned_names(region):
                    continue
                if _uses_in_funcs(region, a):
                    # a closure captures a (one fresh variable per iteration): X must never change -- its other
                    # definitions are only `X = a` copies plus one outside the region
                    others = [d for d in defs.get(X, []) if d != ident]
                    if len(others) != 1 or X in bound or any(st == others[0] for st in region):
                        continue
                renamed = _rename_var(region, a, X)
                renamed = [st for st in renamed if st != ('assign', ('var', X), ('var', X))]
                b = b[:i] + renamed + b[end:]
                changed = True
                break
        return b


    def rec(b, in_loop):
        out = []
        for s in b:
            t = s[0]
            if t == 'if':
                s = ('if', s[1], rec(s[2], in_loop), rec(s[3], in_loop))
            elif t == 'while':
                s = ('while', s[1], rec(s[2], True))
            else:
                s = opt.map_block([s], lambda x: ('func', x[1], rec(list(x[2]), False), x[3]) if x[0] == 'func' else x)[0]
            out.append(s)
        # (valid in any block: a is X from its copy to X's next write)
        out = body_fix(out)
        return [s for s in out if not (s[0] == 'assign' and s[1][0] == 'var' and s[2] == s[1])]   # `x = x`
    return rec(list(root), False)
