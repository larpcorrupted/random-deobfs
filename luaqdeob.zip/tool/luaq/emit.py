"""Translate a structured CFG into Lua source.

Pipeline per function:
  1. lower every CFG node into IR statements (registers become variables rN)
  2. liveness over the CFG removes dead register definitions
  3. temporaries used once are inlined into their use
  4. the structured tree is rendered as Lua with idiomatic names
"""
import re
import collections

from . import cfg, structure, luaparse as lp

IDENT = re.compile(r'^[A-Za-z_][A-Za-z_0-9]*$')
KEYWORDS = lp.KEYWORDS | {'continue'}


# ------------------------------------------------------------------ IR exprs
# ('lit', v) ('var', name) ('glob', name) ('upv', n) ('index', o, k)
# ('call', f, [args]) ('mcall', o, name, [args]) ('bin', op, a, b) ('un', op, a)
# ('table', [items]) ('closure', childidx, caps) ('unpack', e) ('vararg',) ('raw', text)

def fmt_num(v):
    if isinstance(v, float):
        if v != v:
            return '(0/0)'
        if v in (float('inf'), float('-inf')):
            return 'math.huge' if v > 0 else '-math.huge'
        if v == int(v) and abs(v) < 1e15:
            return str(int(v))
        r = repr(v)
        return r
    return str(v)


def fmt_str(s):
    return lp.lua_quote(s)


_PRI = {'or': 1, 'and': 2, '<': 3, '>': 3, '<=': 3, '>=': 3, '~=': 3, '==': 3,
        '..': 8, '+': 10, '-': 10, '*': 11, '/': 11, '//': 11, '%': 11, '^': 13}


def is_ident(s):
    return isinstance(s, str) and IDENT.match(s) and s not in KEYWORDS


class Ctx:
    """Rendering context for one function."""

    def __init__(self, emitter, pm, nodes):
        self.em = emitter
        self.pm = pm
        self.nodes = nodes
        self.uses = collections.Counter()
        self.names = {}

    def child_name(self, idx):
        ch = self.pm.children
        if 0 < idx <= len(ch):
            return ch[idx - 1]
        return None


def render_expr(e, parent=0, r=None):
    t = e[0]
    if t == 'lit':
        v = e[1]
        if v is None:
            return 'nil'
        if v is True:
            return 'true'
        if v is False:
            return 'false'
        if isinstance(v, str):
            return fmt_str(v)
        return fmt_num(v)
    if t in ('var', 'glob'):
        return e[1]
    if t == 'upv':
        return e[1] if isinstance(e[1], str) else 'upvalue%d' % e[1]
    if t == 'vararg':
        return '...'
    if t == 'raw':
        return e[1]
    if t == 'index':
        o, k = e[1], e[2]
        os_ = render_expr(o, 99, r)
        if o[0] in ('lit', 'table', 'bin', 'un', 'closure', 'func'):
            os_ = '(' + os_ + ')'
        if k[0] == 'lit' and is_ident(k[1]):
            return os_ + '.' + k[1]
        return os_ + '[' + render_expr(k, 0, r) + ']'
    if t == 'call':
        f = e[1]
        fs = render_expr(f, 99, r)
        if f[0] in ('lit', 'table', 'bin', 'un', 'closure', 'func'):
            fs = '(' + fs + ')'
        return fs + '(' + ', '.join(render_expr(a, 0, r) for a in e[2]) + ')'
    if t == 'mcall':
        o = e[1]
        os_ = render_expr(o, 99, r)
        if o[0] in ('lit', 'table', 'bin', 'un', 'closure', 'func'):
            os_ = '(' + os_ + ')'
        return os_ + ':' + e[2] + '(' + ', '.join(render_expr(a, 0, r) for a in e[3]) + ')'
    if t == 'bin':
        p = _PRI.get(e[1], 5)
        s = render_expr(e[2], p, r) + ' ' + e[1] + ' ' + render_expr(e[3], p + 1, r)
        return '(' + s + ')' if p < parent else s
    if t == 'un':
        inner = render_expr(e[2], 12, r)
        s = (e[1] + ' ' if e[1] == 'not' else e[1]) + inner
        return '(' + s + ')' if parent > 12 else s
    if t == 'table':
        items = []
        for it in e[1]:
            if it[0] == 'kv':
                k = it[1]
                if k[0] == 'lit' and is_ident(k[1]):
                    items.append('%s = %s' % (k[1], render_expr(it[2], 0, r)))
                else:
                    items.append('[%s] = %s' % (render_expr(k, 0, r), render_expr(it[2], 0, r)))
            else:
                items.append(render_expr(it, 0, r))
        one = '{' + ', '.join(items) + '}'
        nkv = sum(1 for it in e[1] if it[0] == 'kv')
        if any(chr(10) in x for x in items) or len(one) > 100 or (nkv >= 3 and len(one) > 60):
            # one field per line (the statement renderer indents the following lines)
            nl = chr(10)
            return '{' + nl + ''.join('  ' + x.replace(nl, nl + '  ') + ',' + nl for x in items) + '}'
        return one
    if t == 'unpack':
        return 'table.unpack(' + render_expr(e[1], 0, r) + ')'
    if t == 'paren':
        return '(' + render_expr(e[1], 0, r) + ')'
    if t == 'func':
        from .render import render_block
        out = []
        render_block(e[2], 1, r, out)
        if not out:
            return 'function(%s) end' % ', '.join(e[1])
        return 'function(%s)\n%s\nend' % (', '.join(e[1]), '\n'.join(out))
    if t == 'unknown':
        return '(nil --[[unresolved:' + re.sub(r'[^A-Za-z0-9_:/ .]', '', str(e[1])) + ']])'
    raise ValueError('render_expr: ' + repr(e))


def negate(e):
    """Logical negation with simple simplifications."""
    if e[0] == 'un' and e[1] == 'not':
        return e[2]
    if e[0] == 'bin' and e[1] in ('==', '~=', '<', '<=', '>', '>='):
        opp = {'==': '~=', '~=': '==', '<': '>=', '>=': '<', '<=': '>', '>': '<='}[e[1]]
        # note: NaN semantics ignored; comparisons of < > only flip for numbers
        if e[1] in ('==', '~='):
            return ('bin', opp, e[2], e[3])
    return ('un', 'not', e)


# =============================================================== lowering
def sym_regs(e, out):
    """Collect register numbers read (entry values) by a symbolic expression."""
    t = e[0]
    if t == 'reg':
        out.add(e[1])
    elif t in ('idx',):
        sym_regs(e[1], out)
        sym_regs(e[2], out)
    elif t == 'bin':
        sym_regs(e[2], out)
        sym_regs(e[3], out)
    elif t == 'un':
        sym_regs(e[2], out)
    elif t == 'tbl':
        for x in e[1]:
            sym_regs(x, out)
        for k_, v_ in (e[2] if len(e) > 2 else []):
            sym_regs(k_, out)
            sym_regs(v_, out)
        if len(e) > 4:
            sym_regs(e[4], out)
    elif t == 'glob':
        sym_regs(e[1], out)
    elif t == 'unpack':
        sym_regs(e[1], out)
    elif t == 'mnth':
        sym_regs(e[1], out)
    elif t == 'closure':
        caps = e[2]
        if caps and caps[0] == 'tbl':
            sym_regs(caps, out)
    elif t == 'upvslot':
        pass


def node_uses_defs(nd):
    uses = set()
    for op in nd.ops:
        _op_exprs(op, lambda ex: sym_regs(ex, uses))
    for r, ex in nd.defs.items():
        sym_regs(ex, uses)
    if nd.cond:
        sym_regs(nd.cond[0], uses)
    for ext in nd.exits:
        if ext.kind == 'ret':
            for ex in ext.val:
                sym_regs(ex, uses)
    return uses, set(nd.defs) | set(nd.loopdefs)


def _op_exprs(op, f):
    t = op[0]
    if t == 'call':
        f(op[1])
        for a in op[2]:
            f(a)
    elif t == 'setidx':
        f(op[1]); f(op[2]); f(op[3])
    elif t == 'setglob':
        f(op[1]); f(op[2])
    elif t == 'setupv':
        f(op[2])
    elif t == 'settail':
        f(op[1]); f(op[3])
    elif t == 'read':
        f(op[2])
    elif t == 'forin':
        f(op[1])
        for sub in op[4]:
            _op_exprs(sub, f)
        for ex in op[5].values():
            f(ex)
    elif t == 'whileloop':
        f(op[1])
        for sub in op[3]:
            _op_exprs(sub, f)
        for ex in op[4].values():
            f(ex)
    elif t == 'cond':
        for c, _ in op[1]:
            f(c)
        _op_exprs(op[2], f)
    elif t == 'condset':
        for c, _ in op[1]:
            f(c)
        f(op[3])


def liveness(g, nodes):
    uses, defs = {}, {}
    for y, nd in nodes.items():
        uses[y], defs[y] = node_uses_defs(nd)
    live_in = {y: set() for y in nodes}
    live_out = {y: set() for y in nodes}
    changed = True
    while changed:
        changed = False
        for y in reversed(g.order):
            lo = set()
            for s in g.succ.get(y, []):
                lo |= live_in[s]
            lo = lo | (uses[y] & nodes[y].loopdefs)       # loop-carried registers
            li = uses[y] | (lo - defs[y])
            if lo != live_out[y] or li != live_in[y]:
                live_out[y], live_in[y] = lo, li
                changed = True
    return live_in, live_out, uses, defs
