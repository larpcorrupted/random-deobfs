"""Declaration placement and text rendering of the cleaned IR."""
import collections

from .emit import render_expr
from .post import stmt_exprs, sub_blocks
from . import opt


class _B:
    def __init__(self, stmts, parent, pidx):
        self.stmts = stmts
        self.parent = parent
        self.pidx = pidx          # index of owning statement in parent
        self.depth = 0 if parent is None else parent.depth + 1


def _build_blocks(stmts, parent, pidx, allb):
    b = _B(stmts, parent, pidx)
    allb.append(b)
    for i, s in enumerate(stmts):
        for sb in sub_blocks(s):
            _build_blocks(sb, b, i, allb)
    return b


def _assigned_deep(block, out):
    """Names assigned anywhere in a block, including inside nested closures."""
    for s in block:
        t = s[0]
        if t in ('callres', 'local'):
            out.add(s[1])
            exprs = [s[2]]
        elif t == 'assign':
            if s[1][0] == 'var':
                out.add(s[1][1])
            exprs = [s[2]] + ([s[1]] if s[1][0] != 'var' else [])
        elif t == 'multi':
            out.update(s[1])
            exprs = [s[2]]
        elif t == 'callstmt':
            exprs = [s[1]]
        elif t in ('if', 'while'):
            exprs = [s[1]]
            _assigned_deep(s[2], out)
            if t == 'if':
                _assigned_deep(s[3], out)
        elif t == 'return':
            exprs = list(s[1])
        else:
            exprs = []
        for e in exprs:
            def vis(x):
                if x[0] == 'func':
                    _assigned_deep(x[2], out)
            opt.walk_e(e, vis)


def _direct_vars(s):
    names = set()
    for e in stmt_exprs(s):
        opt.walk_e(e, lambda x: names.add(x[1]) if x[0] == 'var' else None)
        # assignments to captured variables inside closures are occurrences too
        def vis(x):
            if x[0] == 'func':
                _assigned_deep(x[2], names)
        opt.walk_e(e, vis)
    if s[0] in ('callres', 'local'):
        names.add(s[1])
    elif s[0] == 'multi':
        names.update(n for n in s[1] if n != '_')
    return names


def _own_defs(block, out):
    """Names assigned directly in this function (not inside nested closures)."""
    for s in block:
        t = s[0]
        if t in ('callres', 'local'):
            out.add(s[1])
        elif t == 'multi':
            out.update(n for n in s[1] if n != '_')
        elif t == 'assign' and s[1][0] == 'var':
            out.add(s[1][1])
        elif t == 'if':
            _own_defs(s[2], out)
            _own_defs(s[3], out)
        elif t == 'while':
            _own_defs(s[2], out)


def declare_vars(block, params=(), outer=frozenset()):
    """Turn first assignments into `local` declarations, hoisting when needed.

    ``outer`` = variables owned by enclosing functions: assigning them from a closure is an
    upvalue write, never a new local."""
    mine = set()
    _own_defs(block, mine)
    mine -= set(outer)
    inner_outer = frozenset(set(outer) | mine | set(params))

    # nested closures first (their bodies are separate scopes)
    def decl_func(x):
        if x[0] == 'func':
            body = declare_vars(list(x[2]), set(x[1]), inner_outer)
            return ('func', x[1], body, x[3])
        return x
    block = _map_top_funcs(block, decl_func)
    allb = []
    _build_blocks(block, None, None, allb)
    occ = collections.defaultdict(list)       # name -> [(block, idx)]
    for b in allb:
        for i, s in enumerate(b.stmts):
            for nme in _direct_vars(s):
                if nme in mine:
                    occ[nme].append((b, i))
    declared_at = {}
    for nme, places in occ.items():
        if nme in params:
            continue
        lca = places[0][0]
        for (b, _) in places[1:]:
            x, y = lca, b
            while x.depth > y.depth:
                x = x.parent
            while y.depth > x.depth:
                y = y.parent
            while x is not y:
                x, y = x.parent, y.parent
            lca = x
        first = None
        for (b, i) in places:
            cur, idx = b, i
            while cur is not lca:
                idx = cur.pidx
                cur = cur.parent
            if first is None or idx < first:
                first = idx
        declared_at[nme] = (lca, first)
    inserts = collections.defaultdict(list)
    converted = set()
    for nme, (b, i) in declared_at.items():
        s = b.stmts[i]
        if s[0] == 'assign' and s[1] == ('var', nme):
            reads = []
            opt.walk_e(s[2], lambda x: reads.append(1) if x == ('var', nme) else None)
            if not reads:
                converted.add((id(b), i, nme))
                continue
        if s[0] in ('callres', 'local') and s[1] == nme:
            continue
        if s[0] == 'multi' and nme in s[1]:
            continue                  # declared by the multi-assignment itself (checked below)
        inserts[(id(b), i)].append(nme)
    # multi-assignments whose names are not all declared by the statement itself become plain
    # assignments (their names are declared earlier, where every use can see them)
    massign = set()
    for b in allb:
        for i, s in enumerate(b.stmts):
            if s[0] != 'multi':
                continue
            inline = [n for n in s[1] if n != '_' and n in declared_at and declared_at[n][0] is b
                      and declared_at[n][1] == i]
            others = [n for n in s[1] if n != '_' and n not in inline]
            if others:
                massign.add((id(b), i))
                inserts[(id(b), i)].extend(inline)
                if '_' in s[1]:
                    inserts[(id(b), i)].append('_')
    for b in allb:
        new = []
        for i, s in enumerate(b.stmts):
            names = inserts.get((id(b), i))
            if names:
                new.append(('decl', sorted(set(names))))
            if s[0] == 'assign' and s[1][0] == 'var' and (id(b), i, s[1][1]) in converted:
                new.append(('local', s[1][1], s[2]))
            elif s[0] == 'multi' and (id(b), i) in massign:
                new.append(('massign', s[1], s[2]))
            else:
                new.append(s)
        b.stmts[:] = new
    return block


def _map_top_funcs(block, fn):
    """Apply fn to every 'func' expression of this function level (not recursing
    into the closures themselves)."""
    def rec(e):
        if not isinstance(e, tuple) or not e:
            return e
        t = e[0]
        if t == 'func':
            return fn(e)
        if t == 'index':
            return ('index', rec(e[1]), rec(e[2]))
        if t == 'call':
            return ('call', rec(e[1]), [rec(a) for a in e[2]])
        if t == 'mcall':
            return ('mcall', rec(e[1]), e[2], [rec(a) for a in e[3]])
        if t == 'bin':
            return ('bin', e[1], rec(e[2]), rec(e[3]))
        if t == 'un':
            return ('un', e[1], rec(e[2]))
        if t == 'table':
            return ('table', [('kv', rec(i[1]), rec(i[2])) if i[0] == 'kv' else rec(i) for i in e[1]])
        if t == 'unpack':
            return ('unpack', rec(e[1]))
        if t == 'paren':
            return ('paren', rec(e[1]))
        if t == 'forin':
            return e[:2] + ([rec(x) for x in e[2]],) + tuple(e[3:])
        return e

    def blk(b):
        out = []
        for s in b:
            t = s[0]
            if t in ('callres', 'local', 'multi'):
                out.append((t, s[1], rec(s[2])))
            elif t == 'assign':
                out.append(('assign', rec(s[1]) if s[1][0] != 'var' else s[1], rec(s[2])))
            elif t == 'callstmt':
                out.append(('callstmt', rec(s[1])))
            elif t == 'if':
                out.append(('if', rec(s[1]), blk(s[2]), blk(s[3])))
            elif t == 'while':
                out.append(('while', rec(s[1]), blk(s[2])))
            elif t == 'return':
                out.append(('return', [rec(v) for v in s[1]]))
            else:
                out.append(s)
        return out
    return blk(block)


def _emit(out, pad, text):
    lines = text.split('\n')
    if lines[0].startswith('('):
        # a line starting with `(` would continue the previous statement's call:
        # terminate that statement with ';' (a leading ';' is illegal in Luau)
        k = len(out) - 1
        while k >= 0 and out[k].lstrip().startswith('--'):
            k -= 1
        if k >= 0:
            prev = out[k].rstrip()
            if not prev.endswith((' then', ' do', 'else', 'repeat', '{', '(', ',', ';')) and prev.strip() != 'do':
                out[k] = prev + ';'
    out.append(pad + lines[0])
    for ln in lines[1:]:
        out.append(pad + ln)


def _wrapped(e, r, pad):
    """render_expr, but a long `a or b or c ...` / `a and b ...` chain is laid out one operand per line."""
    one = render_expr(e, 0, r)
    first_line = one.split(chr(10))[0]
    if e[0] != 'bin' or e[1] not in ('or', 'and') or (len(pad) + len(first_line) <= 110 and chr(10) not in one):
        return one
    op = e[1]
    ops = []
    cur = e
    while cur[0] == 'bin' and cur[1] == op:
        ops.insert(0, cur[3])
        cur = cur[2]
    ops.insert(0, cur)
    pri = _PRI_OP[op]
    parts = [render_expr(x, pri + (1 if i else 0), r) for i, x in enumerate(ops)]
    # (an operand spanning several lines keeps its own relative indentation under the `or`/`and` column)
    parts = [p.replace(chr(10), chr(10) + '    ') for p in parts]
    return (chr(10) + '    ').join([parts[0]] + ['%s %s' % (op, p) for p in parts[1:]])


_PRI_OP = {'or': 1, 'and': 2}


def render_block(stmts, ind, r, out):
    pad = '  ' * ind
    n = len(stmts)
    for si, s in enumerate(stmts):
        t = s[0]
        if t == 'return' and si != n - 1:
            # a return must be the last statement of a block
            _emit(out, pad, 'do')
            render_block([s], ind + 1, r, out)
            _emit(out, pad, 'end')
            continue
        if t in ('local', 'callres'):
            if s[2] == ('lit', None):
                _emit(out, pad, 'local %s' % s[1])
            elif s[2][0] == 'func':
                # `local function name(...)`: also right when the body calls itself (that is what it meant)
                txt = render_expr(s[2], 0, r)
                _emit(out, pad, 'local function %s%s' % (s[1], txt[len('function'):]))
            else:
                _emit(out, pad, 'local %s = %s' % (s[1], _wrapped(s[2], r, pad)))
        elif t == 'multi':
            _emit(out, pad, 'local %s = %s' % (', '.join(s[1]), render_expr(s[2], 0, r)))
        elif t == 'massign':
            _emit(out, pad, '%s = %s' % (', '.join(s[1]), render_expr(s[2], 0, r)))
        elif t == 'decl':
            _emit(out, pad, 'local ' + ', '.join(s[1]))
        elif t == 'assign':
            _emit(out, pad, '%s = %s' % (render_expr(s[1], 0, r), _wrapped(s[2], r, pad)))
        elif t == 'callstmt':
            _emit(out, pad, render_expr(s[1], 0, r))
        elif t == 'if':
            _render_if(s, ind, r, out, 'if')
        elif t == 'while':
            c = s[1]
            if c[0] == 'forin' and len(c) > 3 and c[3] == 'num':
                parts = [render_expr(c[2][0], 0, r), render_expr(c[2][1], 0, r)]
                if c[2][2] != ('lit', 1):
                    parts.append(render_expr(c[2][2], 0, r))
                head = 'for %s = %s do' % (c[1][0], ', '.join(parts))
            elif c[0] == 'forin':
                head = 'for %s in %s do' % (', '.join(c[1]), ', '.join(render_expr(x, 0, r) for x in c[2]))
            else:
                head = 'while true do' if c == ('lit', True) else 'while %s do' % render_expr(c, 0, r)
            _emit(out, pad, head)
            render_block(s[2], ind + 1, r, out)
            _emit(out, pad, 'end')
        elif t == 'return':
            _emit(out, pad, 'return' + (' ' + ', '.join(render_expr(v, 0, r) for v in s[1]) if s[1] else ''))
        elif t == 'break':
            _emit(out, pad, 'break')
        elif t == 'continue':
            _emit(out, pad, 'continue')
        elif t == 'comment':
            _emit(out, pad, '-- ' + str(s[1]))
        else:
            _emit(out, pad, '-- ?? ' + str(s)[:80])


def _render_if(s, ind, r, out, kw):
    pad = '  ' * ind
    _emit(out, pad, '%s %s then' % (kw, _wrapped(s[1], r, pad)))
    render_block(s[2], ind + 1, r, out)
    els = s[3]
    if els:
        if len(els) == 1 and els[0][0] == 'if':
            _render_if(els[0], ind, r, out, 'elseif')
            return
        _emit(out, pad, 'else')
        render_block(els, ind + 1, r, out)
    _emit(out, pad, 'end')
