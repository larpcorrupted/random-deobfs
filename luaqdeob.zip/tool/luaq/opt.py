"""Whole-program IR optimisation passes (closures are ('func', params, body, _))."""
import collections

from .emit import negate, render_expr


# ------------------------------------------------------------- traversal
def map_expr(e, f):
    """Bottom-up rewrite of an expression (descends into closure bodies)."""
    if not isinstance(e, tuple) or not e:
        return e
    t = e[0]
    if t == 'index':
        e = ('index', map_expr(e[1], f), map_expr(e[2], f))
    elif t == 'call':
        e = ('call', map_expr(e[1], f), [map_expr(a, f) for a in e[2]])
    elif t == 'mcall':
        e = ('mcall', map_expr(e[1], f), e[2], [map_expr(a, f) for a in e[3]])
    elif t == 'bin':
        e = ('bin', e[1], map_expr(e[2], f), map_expr(e[3], f))
    elif t == 'un':
        e = ('un', e[1], map_expr(e[2], f))
    elif t == 'table':
        items = []
        for it in e[1]:
            if it[0] == 'kv':
                items.append(('kv', map_expr(it[1], f), map_expr(it[2], f)))
            else:
                items.append(map_expr(it, f))
        e = ('table', items)
    elif t == 'unpack':
        e = ('unpack', map_expr(e[1], f))
    elif t == 'paren':
        e = ('paren', map_expr(e[1], f))
    elif t == 'forin':
        e = ('forin', e[1], [map_expr(x, f) for x in e[2]]) + tuple(e[3:])
    elif t == 'func':
        e = ('func', e[1], map_block(e[2], f), e[3])
    return f(e)


def map_block(block, f):
    out = []
    for s in block:
        t = s[0]
        if t in ('callres', 'local'):
            out.append((t, s[1], map_expr(s[2], f)))
        elif t == 'assign':
            lhs = s[1]
            lhs = map_expr(lhs, f) if lhs[0] != 'var' else lhs
            out.append(('assign', lhs, map_expr(s[2], f)))
        elif t == 'callstmt':
            out.append(('callstmt', map_expr(s[1], f)))
        elif t == 'multi':
            out.append(('multi', s[1], map_expr(s[2], f)))
        elif t == 'if':
            out.append(('if', map_expr(s[1], f), map_block(s[2], f), map_block(s[3], f)))
        elif t == 'while':
            out.append(('while', map_expr(s[1], f), map_block(s[2], f)))
        elif t == 'return':
            out.append(('return', [map_expr(v, f) for v in s[1]]))
        else:
            out.append(s)
    return out


def walk_e(e, f):
    f(e)
    t = e[0]
    if t == 'index':
        walk_e(e[1], f); walk_e(e[2], f)
    elif t == 'call':
        walk_e(e[1], f)
        for a in e[2]:
            walk_e(a, f)
    elif t == 'mcall':
        walk_e(e[1], f)
        for a in e[3]:
            walk_e(a, f)
    elif t == 'bin':
        walk_e(e[2], f); walk_e(e[3], f)
    elif t == 'un':
        walk_e(e[2], f)
    elif t == 'table':
        for it in e[1]:
            if it[0] == 'kv':
                walk_e(it[1], f); walk_e(it[2], f)
            else:
                walk_e(it, f)
    elif t == 'unpack':
        walk_e(e[1], f)
    elif t == 'paren':
        walk_e(e[1], f)
    elif t == 'forin':
        for x in e[2]:
            walk_e(x, f)
    elif t == 'func':
        walk_b(e[2], f)


def walk_b(block, f, defs=None):
    for s in block:
        t = s[0]
        if t in ('callres', 'local'):
            if defs is not None:
                defs.append((s[1], s))
            walk_e(s[2], f)
        elif t == 'assign':
            if s[1][0] == 'var':
                if defs is not None:
                    defs.append((s[1][1], s))
            else:
                walk_e(s[1], f)
            walk_e(s[2], f)
        elif t == 'callstmt':
            walk_e(s[1], f)
        elif t == 'multi':
            if defs is not None:
                for n_ in s[1]:
                    defs.append((n_, s))
            walk_e(s[2], f)
        elif t == 'if':
            walk_e(s[1], f)
            walk_b(s[2], f, defs)
            walk_b(s[3], f, defs)
        elif t == 'while':
            walk_e(s[1], f)
            walk_b(s[2], f, defs)
        elif t == 'return':
            for v in s[1]:
                walk_e(v, f)


def bound_names(block):
    """Function parameters and loop variables: names that get a value without an assignment statement (a single
    assignment to such a name is not its only definition)."""
    out = set()

    def f(e):
        if e[0] == 'func':
            out.update(n for n in e[1] if n != '...')
        elif e[0] == 'forin':
            out.update(e[1])
    walk_b(block, f)
    return out


def collect(block):
    """Return (defs: name->[stmt], uses: Counter) over the whole program."""
    defs_l = []
    uses = collections.Counter()

    def f(e):
        if e[0] == 'var':
            uses[e[1]] += 1
    walk_b_defs(block, f, defs_l)
    defs = collections.defaultdict(list)
    for n, s in defs_l:
        defs[n].append(s)
    return defs, uses


def walk_b_defs(block, f, defs_l):
    """Like walk_b but also records definitions found inside closure bodies."""
    def fe(e):
        f(e)
        if e[0] == 'func':
            walk_b_defs(e[2], f, defs_l)
    # walk_e already descends into func via walk_b (without defs); handle defs here
    for s in block:
        t = s[0]
        if t in ('callres', 'local'):
            defs_l.append((s[1], s))
            _walk_e_defs(s[2], f, defs_l)
        elif t == 'assign':
            if s[1][0] == 'var':
                defs_l.append((s[1][1], s))
            else:
                _walk_e_defs(s[1], f, defs_l)
            _walk_e_defs(s[2], f, defs_l)
        elif t == 'callstmt':
            _walk_e_defs(s[1], f, defs_l)
        elif t == 'multi':
            for n_ in s[1]:
                defs_l.append((n_, s))
            _walk_e_defs(s[2], f, defs_l)
        elif t == 'if':
            _walk_e_defs(s[1], f, defs_l)
            walk_b_defs(s[2], f, defs_l)
            walk_b_defs(s[3], f, defs_l)
        elif t == 'while':
            _walk_e_defs(s[1], f, defs_l)
            walk_b_defs(s[2], f, defs_l)
        elif t == 'return':
            for v in s[1]:
                _walk_e_defs(v, f, defs_l)


def _walk_e_defs(e, f, defs_l):
    f(e)
    t = e[0]
    if t == 'index':
        _walk_e_defs(e[1], f, defs_l); _walk_e_defs(e[2], f, defs_l)
    elif t == 'call':
        _walk_e_defs(e[1], f, defs_l)
        for a in e[2]:
            _walk_e_defs(a, f, defs_l)
    elif t == 'mcall':
        _walk_e_defs(e[1], f, defs_l)
        for a in e[3]:
            _walk_e_defs(a, f, defs_l)
    elif t == 'bin':
        _walk_e_defs(e[2], f, defs_l); _walk_e_defs(e[3], f, defs_l)
    elif t == 'un':
        _walk_e_defs(e[2], f, defs_l)
    elif t == 'table':
        for it in e[1]:
            if it[0] == 'kv':
                _walk_e_defs(it[1], f, defs_l); _walk_e_defs(it[2], f, defs_l)
            else:
                _walk_e_defs(it, f, defs_l)
    elif t == 'unpack':
        _walk_e_defs(e[1], f, defs_l)
    elif t == 'paren':
        _walk_e_defs(e[1], f, defs_l)
    elif t == 'forin':
        for x in e[2]:
            _walk_e_defs(x, f, defs_l)
    elif t == 'func':
        walk_b_defs(e[2], f, defs_l)


# ------------------------------------------------------------------ unbox
def unbox(block):
    """Registers holding a one-slot table that is only ever indexed with [1] are
    ordinary captured variables: drop the box."""
    changed = True
    while changed:
        changed = False
        defs, uses = collect(block)
        # occurrences of box[1]
        idx1 = collections.Counter()

        def f(e):
            if e[0] == 'index' and e[1][0] == 'var' and e[2] == ('lit', 1):
                idx1[e[1][1]] += 1
        walk_b(block, f)
        cands = set()
        for v, dl in defs.items():
            if not dl:
                continue
            ok = True
            for s in dl:
                rhs = s[2]
                if not (rhs[0] == 'table' and len(rhs[1]) == 1 and rhs[1][0][0] != 'kv'):
                    ok = False
                    break
            # assignments of the box through "box[1] = x" are not var-defs, fine
            if ok and uses[v] == idx1[v]:
                cands.add(v)
        if not cands:
            break

        def fix(e):
            if e[0] == 'index' and e[1][0] == 'var' and e[1][1] in cands and e[2] == ('lit', 1):
                return ('var', e[1][1])
            return e

        # rewrite definitions  v = {x}  ->  v = x  BEFORE `v[1]` becomes `v`: a store into the box (`v[1] = {...}`)
        # would otherwise look like a box creation
        def unwrap(b):
            out = []
            for s in b:
                t = s[0]
                if t in ('callres', 'local') and s[1] in cands and s[2][0] == 'table':
                    out.append((t, s[1], _unwrap_e(s[2][1][0])))      # (the boxed value may hold closures)
                elif t == 'assign' and s[1][0] == 'var' and s[1][1] in cands and s[2][0] == 'table':
                    out.append(('assign', s[1], _unwrap_e(s[2][1][0])))
                elif t == 'if':
                    out.append(('if', _unwrap_e(s[1]), unwrap(s[2]), unwrap(s[3])))
                elif t == 'while':
                    out.append(('while', s[1], unwrap(s[2])))
                else:
                    out.append(_unwrap_stmt(s))
            return out

        def _unwrap_e(e):
            return map_expr(e, lambda x: ('func', x[1], unwrap(x[2]), x[3]) if x[0] == 'func' else x)

        def _unwrap_stmt(s):
            return map_block([s], lambda x: ('func', x[1], unwrap(x[2]), x[3]) if x[0] == 'func' else x)[0]
        block = unwrap(block)
        block = map_block(block, fix)
        changed = True
    return block


# --------------------------------------------------------- propagation
def propagate(block):
    """Replace single-definition variables bound to literals / other single-def
    variables, and drop the definition."""
    for _ in range(6):
        defs, uses = collect(block)
        params = set()

        def gp(e):
            if e[0] == 'func':
                params.update(e[1])
            elif e[0] == 'forin':
                params.update(e[1])          # loop variables: fixed for the whole iteration
        walk_b(block, gp)
        repl = {}
        for v, dl in defs.items():
            if len(dl) != 1 or v in params:
                continue
            s = dl[0]
            if s[0] == 'assign' or s[0] == 'local' or s[0] == 'callres':
                rhs = s[2]
                if rhs[0] == 'lit' and rhs[1] is not None:
                    repl[v] = rhs
                elif rhs[0] == 'var' and rhs[1] != v and (len(defs.get(rhs[1], [])) == 1
                                                          or (rhs[1] in params and not defs.get(rhs[1]))):
                    repl[v] = rhs
                elif rhs[0] == 'glob' and rhs[1] in ('game', 'workspace') and False:
                    repl[v] = rhs
        if not repl:
            break
        # resolve chains v -> w -> lit
        for v in list(repl):
            seen = {v}
            cur = repl[v]
            while cur[0] == 'var' and cur[1] in repl and cur[1] not in seen:
                seen.add(cur[1])
                cur = repl[cur[1]]
            repl[v] = cur

        def f(e):
            if e[0] == 'var' and e[1] in repl:
                return repl[e[1]]
            return e
        block = map_block(block, f)

        def drop(b):
            out = []
            for s in b:
                t = s[0]
                if t in ('callres', 'local') and s[1] in repl:
                    continue
                if t == 'assign' and s[1][0] == 'var' and s[1][1] in repl:
                    continue
                if t == 'if':
                    out.append(('if', s[1], drop(s[2]), drop(s[3])))
                elif t == 'while':
                    out.append(('while', s[1], drop(s[2])))
                else:
                    out.append(_drop_funcs(s))
            return out

        def _drop_funcs(s):
            return map_block([s], lambda x: ('func', x[1], drop(x[2]), x[3]) if x[0] == 'func' else x)[0]
        block = drop(block)
    return block


def method_calls(block):
    """call(index(obj, name), obj, ...) -> obj:name(...) also when the first argument
    is a single-definition variable that merely caches obj."""
    defs, uses = collect(block)

    def f(e):
        if e[0] == 'call' and e[1][0] == 'index' and e[1][2][0] == 'lit'                 and isinstance(e[1][2][1], str) and e[2]:
            from .emit import is_ident
            if not is_ident(e[1][2][1]):
                return e
            obj, a0 = e[1][1], e[2][0]
            same = a0 == obj
            if not same and a0[0] == 'var':
                dl = defs.get(a0[1], [])
                if len(dl) == 1 and dl[0][0] in ('assign', 'local', 'callres') and dl[0][2] == obj:
                    same = True
            if same:
                return ('mcall', obj, e[1][2][1], e[2][1:])
        return e
    return map_block(block, f)


def simplify_packs(block):
    """`p = table.pack(CALL)` whose uses are all constant indexes p[k] becomes
    `local p1, p2 = CALL` (or just `local p1 = CALL` when only p[1] is used)."""
    defs, uses = collect(block)
    cands = {}
    for v, dl in defs.items():
        if len(dl) != 1:
            continue
        s = dl[0]
        if s[0] in ('callres', 'assign', 'local'):
            rhs = s[2]
            if rhs[0] == 'call' and rhs[1] == ('index', ('glob', 'table'), ('lit', 'pack')) and len(rhs[2]) == 1:
                cands[v] = rhs[2][0]
    if not cands:
        return block
    ks = collections.defaultdict(set)
    bad = set()
    idxuse = collections.Counter()

    def scan(e):
        if e[0] == 'index' and e[1][0] == 'var' and e[1][1] in cands:
            k = e[2]
            if k[0] == 'lit' and isinstance(k[1], int) and not isinstance(k[1], bool) and k[1] >= 1:
                ks[e[1][1]].add(k[1])
                idxuse[e[1][1]] += 1
            else:
                bad.add(e[1][1])
    walk_b(block, scan)
    ok = {v for v in cands if v not in bad and idxuse[v] == uses[v] and ks[v]}
    # variables used both inside and ... keep it simple: need every use to be an index
    if not ok:
        return block
    names = {v: {k: '%s_%d' % (v, k) for k in ks[v]} for v in ok}
    # a derived name must not be the name of an existing variable (a pack from an earlier round can be called
    # `<pack>_2`): the rewrite would then treat the new variable as a pack of its own
    existing = set(defs) | set(uses) | set(cands)
    for v_ in sorted(ok):
        for k_ in sorted(names[v_]):
            nm_ = names[v_][k_]
            while nm_ in existing:
                nm_ += '9'                      # (stays a generated name the renamer knows)
            existing.add(nm_)
            names[v_][k_] = nm_

    # (the walk above and the rewrite below must see the same uses: a use the walk missed, for example one
    # inside a nested function, with another key keeps the pack as it is)
    viol = set()

    def probe(e):
        if e[0] == 'index' and e[1][0] == 'var' and e[1][1] in ok:
            k = e[2]
            if not (k[0] == 'lit' and k[1] in names[e[1][1]]):
                viol.add(e[1][1])
        return e
    map_block(block, probe)
    if viol:
        ok = ok - viol
        if not ok:
            return block
        names = {v: names[v] for v in ok}

    def fix(e):
        if e[0] == 'index' and e[1][0] == 'var' and e[1][1] in ok:
            return ('var', names[e[1][1]][e[2][1]])
        return e
    block = map_block(block, fix)

    def conv(b):
        out = []
        for s in b:
            t = s[0]
            if t in ('callres', 'assign', 'local') and ((t == 'assign' and s[1][0] == 'var' and s[1][1] in ok)
                                                          or (t != 'assign' and s[1] in ok)):
                v = s[1][1] if t == 'assign' else s[1]
                # (the current statement, not the one the candidates were collected from: the uses inside its
                # own arguments -- closures holding further packs -- have been rewritten in the meantime)
                call = s[2][2][0] if (s[2][0] == 'call' and len(s[2][2]) == 1) else cands[v]
                call = map_expr(call, lambda x: ('func', x[1], conv(x[2]), x[3]) if x[0] == 'func' else x)
                kmax = max(ks[v])
                if kmax == 1:
                    out.append(('callres', names[v][1], call))
                else:
                    lst = [names[v].get(k, '_') for k in range(1, kmax + 1)]
                    out.append(('multi', lst, call))
            elif t == 'if':
                out.append(('if', s[1], conv(s[2]), conv(s[3])))
            elif t == 'while':
                out.append(('while', s[1], conv(s[2])))
            else:
                out.append(map_block([s], lambda x: ('func', x[1], conv(x[2]), x[3]) if x[0] == 'func' else x)[0])
        return out
    return conv(block)


def short_circuit(block):
    """Recover `and` / `or` from the compiled branch patterns.

    value form:  v = X ; if not X then v = Y end   ->  v = X or Y
                 v = X ; if X then v = Y end       ->  v = X and Y
    branch form: if C1 then (if C2 then A else B) else B end -> if C1 and C2 then A else B end
                 if C1 then A else (if C2 then A else B) end -> if C1 or C2 then A else B end
    """
    from .emit import negate as _neg

    def sub(b):
        return short_circuit(b)

    def fn(x):
        if x[0] == 'func':
            return ('func', x[1], short_circuit(list(x[2])), x[3])
        return x
    # recurse
    res = []
    for s in block:
        t = s[0]
        if t == 'if':
            s = ('if', s[1], sub(s[2]), sub(s[3]))
        elif t == 'while':
            s = ('while', s[1], sub(s[2]))
        else:
            s = map_block([s], fn)[0]
        res.append(s)
    changed = True
    while changed:
        changed = False
        # branch form
        for i, s in enumerate(res):
            if s[0] != 'if':
                continue
            c1, th, el = s[1], s[2], s[3]
            if len(th) == 1 and th[0][0] == 'if' and th[0][3] == el:
                inner = th[0]
                res[i] = ('if', ('bin', 'and', c1, inner[1]), inner[2], el)
                changed = True
                break
            if len(el) == 1 and el[0][0] == 'if' and el[0][2] == th and th:
                inner = el[0]
                res[i] = ('if', ('bin', 'or', c1, inner[1]), th, inner[3])
                changed = True
                break
        if changed:
            continue
        # value form
        for i in range(len(res) - 1):
            a, b = res[i], res[i + 1]
            if b[0] != 'if' or b[3] or len(b[2]) != 1:
                continue
            if a[0] == 'assign' and a[1][0] == 'var':
                v, X, kind = a[1], a[2], 'assign'
            elif a[0] == 'callres':
                v, X, kind = ('var', a[1]), a[2], 'callres'
            else:
                continue
            asg = b[2][0]
            if not (asg[0] == 'assign' and asg[1] == v):
                continue
            Y = asg[2]
            usev = []
            walk_e(Y, lambda x: usev.append(1) if x == v else None)
            if usev:
                continue
            cond = b[1]
            if cond == _neg(X) or cond == ('un', 'not', v) or (X[0] == 'var' and cond == ('un', 'not', X)):
                new = ('bin', 'or', X, Y)
            elif cond == X or cond == v:
                new = ('bin', 'and', X, Y)
            else:
                continue
            res[i] = (a[0], a[1], new) if kind == 'assign' else ('callres', a[1], new)
            del res[i + 1]
            changed = True
            break
        if changed:
            continue
        # two-branch value form: if C then v = Y else v = C end -> v = C and Y   (C a variable)
        for i, s in enumerate(res):
            if s[0] != 'if' or len(s[2]) != 1 or len(s[3]) != 1:
                continue
            p, q = s[2][0], s[3][0]
            if not (p[0] == 'assign' and q[0] == 'assign' and p[1][0] == 'var' and p[1] == q[1]):
                continue
            c = s[1]
            neg = c[0] == 'un' and c[1] == 'not'
            C = c[2] if neg else c
            if C[0] != 'var' or C == p[1]:
                continue
            new = None
            if q[2] == C and p[2] != C:
                new = ('bin', 'or' if neg else 'and', C, p[2])
            elif p[2] == C and q[2] != C:
                new = ('bin', 'and' if neg else 'or', C, q[2])
            if new is None:
                continue
            usev = []
            walk_e(new[3], lambda x: usev.append(1) if x == p[1] else None)
            if usev:
                continue
            res[i] = ('assign', p[1], new)
            changed = True
            break
    return res



def unpack_pack(block):
    """table.unpack(table.pack(X)) -> X (last argument / for header) or (X) elsewhere."""
    PACK = ('index', ('glob', 'table'), ('lit', 'pack'))

    def is_packcall(e):
        return e[0] == 'unpack' and e[1][0] == 'call' and e[1][1] == PACK and len(e[1][2]) == 1             and e[1][2][0][0] in ('call', 'mcall')

    def fix_args(args):
        out = []
        if args and args[-1][0] == 'unpack' and args[-1][1][0] == 'table'                 and all(it[0] != 'kv' for it in args[-1][1][1]) and args[-1][1][1]:
            # f(a, unpack({x, y, g()})) == f(a, x, y, g()): the last item expands exactly like the VM's pack
            args = list(args[:-1]) + list(args[-1][1][1])
        for i, a in enumerate(args):
            if is_packcall(a):
                x = a[1][2][0]
                out.append(x if i == len(args) - 1 else ('paren', x))
            else:
                out.append(a)
        return out

    def f(e):
        if e[0] == 'unpack' and e[1][0] == 'table' and len(e[1][1]) == 1 and e[1][1][0][0] == 'unpack':
            return e[1][1][0]                 # unpack({unpack(x)}) -> unpack(x)
        if e[0] == 'call':
            return ('call', e[1], fix_args(e[2]))
        if e[0] == 'mcall':
            return ('mcall', e[1], e[2], fix_args(e[3]))
        if e[0] == 'forin' and len(e[2]) == 1 and is_packcall(e[2][0]):
            return ('forin', e[1], [e[2][0][1][2][0]])
        if e[0] == 'forin' and len(e) == 3 and len(e[2]) == 1 and e[2][0][0] == 'unpack'                 and e[2][0][1][0] == 'table' and e[2][0][1][1] and all(it[0] != 'kv' for it in e[2][0][1][1]):
            return ('forin', e[1], list(e[2][0][1][1]))      # for .. in unpack({f(x)}) -> for .. in f(x)
        if e[0] == 'index' and e[2] == ('lit', 1) and e[1][0] == 'call' and e[1][1] == PACK                 and len(e[1][2]) == 1 and e[1][2][0][0] in ('call', 'mcall'):
            return ('paren', e[1][2][0])                  # table.pack(f(...))[1] -> (f(...))
        if e[0] == 'table' and e[1] and is_packcall(e[1][-1]):
            return ('table', list(e[1][:-1]) + [e[1][-1][1][2][0]])      # {a, unpack(pack(f()))} -> {a, f()}
        return e
    return map_block(block, f)



def walk_e_shallow(e, f):
    """Like walk_e but stops at 'func' nodes (the callback is responsible for their bodies)."""
    f(e)
    t = e[0]
    if t == 'index':
        walk_e_shallow(e[1], f); walk_e_shallow(e[2], f)
    elif t == 'call':
        walk_e_shallow(e[1], f)
        for a in e[2]:
            walk_e_shallow(a, f)
    elif t == 'mcall':
        walk_e_shallow(e[1], f)
        for a in e[3]:
            walk_e_shallow(a, f)
    elif t == 'bin':
        walk_e_shallow(e[2], f); walk_e_shallow(e[3], f)
    elif t == 'un':
        walk_e_shallow(e[2], f)
    elif t == 'table':
        for it in e[1]:
            if it[0] == 'kv':
                walk_e_shallow(it[1], f); walk_e_shallow(it[2], f)
            else:
                walk_e_shallow(it, f)
    elif t in ('unpack', 'paren'):
        walk_e_shallow(e[1], f)
    elif t == 'forin':
        for x in e[2]:
            walk_e_shallow(x, f)



def _count_var(node, name):
    n = [0]

    def f(e):
        if e == ('var', name):
            n[0] += 1
    if isinstance(node, list):
        walk_b(node, f)
    else:
        walk_e(node, f)
    return n[0]


def numeric_for(block):
    """`v = a; while (s>0 and v<=L) or (not(s>0) and v>=L) do ...; v = v + s end` -> for v = a, L, s."""
    def rec(b):
        out = []
        b = [(_nf_stmt(s)) for s in b]
        i = 0
        while i < len(b):
            s = b[i]
            if i + 1 < len(b) and b[i + 1][0] == 'while' and s[0] in ('assign', 'callres'):
                v = s[1][1] if s[0] == 'assign' and s[1][0] == 'var' else (s[1] if s[0] == 'callres' else None)
                w = b[i + 1]
                m = _match_numfor(v, w) if v else None
                if m is not None:
                    start = s[2]
                    limit, step, body = m
                    total = _count_var(block, v)
                    inside = _count_var(w[1], v) + _count_var(w[2], v)
                    # init target + occurrences within the loop only
                    if total == inside + 0 and not _count_var(start, v):
                        out.append(('while', ('forin', [v], [start, limit, step], 'num'), body))
                        i += 2
                        continue
            out.append(s)
            i += 1
        return out

    def _nf_stmt(s):
        t = s[0]
        if t == 'if':
            return ('if', s[1], rec(s[2]), rec(s[3]))
        if t == 'while':
            return ('while', s[1], rec(s[2]))
        return map_block([s], lambda x: ('func', x[1], rec(list(x[2])), x[3]) if x[0] == 'func' else x)[0]
    return rec(list(block))


def _match_numfor(v, w):
    cond, body = w[1], w[2]
    if cond[0] != 'bin' or cond[1] != 'or' or not body:
        return None
    a, b = cond[2], cond[3]
    if not (a[0] == 'bin' and a[1] == 'and' and b[0] == 'bin' and b[1] == 'and'):
        return None
    pos, le = a[2], a[3]
    npos, ge = b[2], b[3]
    if not (pos[0] == 'bin' and pos[1] == '>' and pos[3] == ('lit', 0) and pos[2][0] == 'lit'):
        return None
    step = pos[2]
    if not (npos == ('un', 'not', pos)):
        return None
    if not (le[0] == 'bin' and le[1] == '<=' and le[2] == ('var', v)):
        return None
    if not (ge[0] == 'bin' and ge[1] == '>=' and ge[2] == ('var', v) and ge[3] == le[3]):
        return None
    limit = le[3]
    last = body[-1]
    if not (last[0] == 'assign' and last[1] == ('var', v) and last[2] == ('bin', '+', ('var', v), step)):
        return None
    inner = body[:-1]
    if _count_var(inner, v) and any(st[0] == 'assign' and st[1] == ('var', v) for st in inner):
        return None
    if _count_var(limit, v) or _count_var(step, v):
        return None
    return limit, step, inner


# ------------------------------------------------ generic-for recovered from its record protocol
def recover_forin(block):
    """The VM implements `for a, b in E do ... end` with an iterator record R = {E...} and a step
    that calls R[1](R[2], R[3]) and stores the first result in R[3]; the loop ends on a nil first
    result.  When R is used for nothing else the statements are folded back into the `for`."""
    PACK = ('index', ('glob', 'table'), ('lit', 'pack'))
    root = block

    def explist_of(v):
        # R = {table.unpack(table.pack(E))}  |  R = table.pack(E)
        if v[0] == 'table' and len(v[1]) == 1 and v[1][0][0] == 'unpack':
            v = v[1][0][1]
        if v[0] == 'call' and v[1] == PACK and len(v[2]) == 1:
            return v[2][0]
        if v[0] == 'table' and len(v[1]) == 1 and v[1][0][0] in ('call', 'mcall'):
            return v[1][0]                    # R = {pairs(t)}: the three results of the call
        return None

    def try_fold(b, i):
        s = b[i]
        if i + 1 >= len(b) or b[i + 1][0] != 'while':
            return None
        if s[0] in ('callres', 'local'):
            r, init = s[1], s[2]
        elif s[0] == 'assign' and s[1][0] == 'var':
            r, init = s[1][1], s[2]
        else:
            return None
        e = explist_of(init)
        w = b[i + 1]
        if e is None or w[1] != ('lit', True) or len(w[2]) != 3:
            return None
        head, store, test = w[2]
        R = ('var', r)
        step = ('call', ('index', R, ('lit', 1)), [('index', R, ('lit', 2)), ('index', R, ('lit', 3))])
        if head[0] == 'multi' and head[2] == step:
            names = list(head[1])
        elif head[0] in ('callres', 'local') and head[2] == step:
            names = [head[1]]
        else:
            return None
        if store != ('assign', ('index', R, ('lit', 3)), ('var', names[0])) or test[0] != 'if':
            return None
        cond, thn, els = test[1], test[2], test[3]
        if cond == ('bin', '==', ('var', names[0]), ('lit', None)) and thn == [('break',)]:
            body = els
        elif cond == ('bin', '~=', ('var', names[0]), ('lit', None)) and els == [('break',)]:
            body = thn
        else:
            return None
        if body and body[-1] == ('continue',):
            body = body[:-1]
        if _count_var(root, r) != 4:
            return None
        return ('while', ('forin', names, [e]), body)

    def rec(b):
        out = []
        b = [_rf_stmt(s) for s in b]
        i = 0
        while i < len(b):
            new = try_fold(b, i)
            if new is not None:
                out.append(new)
                i += 2
                continue
            out.append(b[i])
            i += 1
        return out

    def _rf_stmt(s):
        t = s[0]
        if t == 'if':
            return ('if', s[1], rec(s[2]), rec(s[3]))
        if t == 'while':
            return ('while', s[1], rec(s[2]))
        return map_block([s], lambda x: ('func', x[1], rec(list(x[2])), x[3]) if x[0] == 'func' else x)[0]
    return rec(list(block))


# ------------------------------------------------ table constructors rebuilt from SETLIST ops
def fold_setlist(block):
    """`T = {a, b}; table.move(P, 1, P.n, 3, T)` -> `T = {a, b, table.unpack(P)}` (open tail), and
    `T = {E}` used once as `T[1]` -> `(E)`.  Both are how the VM spells `{a, b, f()}` / `({f()})[1]`."""
    MOVE = ('index', ('glob', 'table'), ('lit', 'move'))
    defs, uses = collect(block)

    def mentions(stmt, name):
        found = []
        walk_b([stmt], lambda x: found.append(1) if x == ('var', name) else None)
        return bool(found) or (stmt[0] in ('assign', 'callres', 'local', 'multi')
                               and (stmt[1] == name or stmt[1] == ('var', name)))

    def sink_defs(b):
        # `T = {}; <statements not touching T>; table.move(P, 1, P.n, 1, T)`: build T at the move
        b = list(b)
        j = 0
        while j < len(b):
            sj = b[j]
            if sj[0] == 'callstmt' and sj[1][0] == 'call' and sj[1][1] == MOVE and len(sj[1][2]) == 5                     and sj[1][2][4][0] == 'var':
                tname = sj[1][2][4][1]
                for i in range(j - 1, -1, -1):
                    si = b[i]
                    nm = si[1][1] if (si[0] == 'assign' and si[1][0] == 'var') else (si[1] if si[0] in ('local', 'callres') else None)
                    if nm == tname:
                        if si[2][0] == 'table' and all(it[0] == 'lit' for it in si[2][1])                                 and sj[1][2][3] == ('lit', len(si[2][1]) + 1)                                 and not any(mentions(b[k], tname) for k in range(i + 1, j)):
                            kind = si[0]
                            b[j] = (kind, si[1], si[2])           # re-declare at the move, then fold below
                            b.insert(j + 1, sj)
                            del b[i]
                            j -= 0
                        break
                    if mentions(si, tname):
                        break
            j += 1
        return b

    PACKF = ('index', ('glob', 'table'), ('lit', 'pack'))

    def fold_stores(b):
        # `T = {}; T[1] = A; T[2] = B; P = table.pack(E); table.move(P, 1, P.n, 3, T)`  ->  `T = {A, B, E}`
        b = list(b)
        j = 0
        while j < len(b):
            sj = b[j]
            ok = False
            if sj[0] == 'callstmt' and sj[1][0] == 'call' and sj[1][1] == MOVE and len(sj[1][2]) == 5                     and sj[1][2][4][0] == 'var' and sj[1][2][0][0] == 'var' and j >= 1                     and isinstance(sj[1][2][3], tuple) and sj[1][2][3][0] == 'lit' and isinstance(sj[1][2][3][1], int):
                pname, tname, start = sj[1][2][0][1], sj[1][2][4][1], sj[1][2][3][1]
                pd = b[j - 1]
                pn = pd[1] if pd[0] in ('callres', 'local') else (pd[1][1] if pd[0] == 'assign' and pd[1][0] == 'var' else None)
                if pn == pname and pd[2][0] == 'call' and pd[2][1] == PACKF and len(pd[2][2]) == 1                         and sj[1][2][1] == ('lit', 1) and sj[1][2][2] == ('index', ('var', pname), ('lit', 'n'))                         and uses.get(pname, 0) == 2 and start >= 1:
                    m = start - 1
                    lo = j - 1 - m
                    stores = b[lo:j - 1] if lo >= 0 else None
                    if stores is not None and all(
                            st[0] == 'assign' and st[1][0] == 'index' and st[1][1] == ('var', tname)
                            and st[1][2] == ('lit', k + 1) for k, st in enumerate(stores)):
                        # the table definition: an earlier `T = {}` nothing touches until the first store
                        d = None
                        for i in range(lo - 1, -1, -1):
                            si = b[i]
                            nm = si[1][1] if (si[0] == 'assign' and si[1][0] == 'var') else (si[1] if si[0] in ('local', 'callres') else None)
                            if nm == tname:
                                if si[2] == ('table', []):
                                    d = i
                                break
                            if mentions(si, tname):
                                break
                        if d is not None:
                            items = [st[2] for st in stores] + [pd[2][2][0]]
                            kind = b[d][0]
                            b[j - 1 - m:j + 1] = [(kind, b[d][1], ('table', items))]
                            del b[d]
                            ok = True
            if not ok:
                j += 1
        return b

    def rec(b):
        out = []
        b = fold_stores([_fs_stmt(s) for s in b])
        b = sink_defs(b)
        i = 0
        while i < len(b):
            s = b[i]
            if i + 1 < len(b) and s[0] in ('assign', 'local', 'callres') and b[i + 1][0] == 'callstmt':
                name = s[1][1] if (s[0] == 'assign' and s[1][0] == 'var') else (s[1] if s[0] != 'assign' else None)
                init = s[2]
                nxt = b[i + 1][1]
                if name and init[0] == 'table' and all(it[0] != 'kv' for it in init[1]) \
                        and not (init[1] and init[1][-1][0] == 'unpack') \
                        and nxt[0] == 'call' and nxt[1] == MOVE and len(nxt[2]) == 5 \
                        and nxt[2][4] == ('var', name) and nxt[2][1] == ('lit', 1) \
                        and nxt[2][3] == ('lit', len(init[1]) + 1) \
                        and nxt[2][2] == ('index', nxt[2][0], ('lit', 'n')):
                    merged = ('table', list(init[1]) + [('unpack', nxt[2][0])])
                    out.append((s[0], s[1], merged))
                    i += 2
                    continue
            out.append(s)
            i += 1
        return out

    def _fs_stmt(s):
        t = s[0]
        if t == 'if':
            return ('if', s[1], rec(s[2]), rec(s[3]))
        if t == 'while':
            return ('while', s[1], rec(s[2]))
        return map_block([s], lambda x: ('func', x[1], rec(list(x[2])), x[3]) if x[0] == 'func' else x)[0]
    block = rec(list(block))

    # T = {E}  (one item, call or unpack) used only as T[1]
    defs, uses = collect(block)
    cands = {}
    for v, dl in defs.items():
        if len(dl) == 1 and dl[0][0] in ('assign', 'local', 'callres'):
            init = dl[0][2]
            if init[0] == 'table' and len(init[1]) == 1 and init[1][0][0] in ('call', 'mcall', 'unpack'):
                cands[v] = init[1][0]
    if not cands:
        return block
    n1 = collections.Counter()

    def scan(e):
        if e[0] == 'index' and e[1][0] == 'var' and e[1][1] in cands and e[2] == ('lit', 1):
            n1[e[1][1]] += 1
    walk_b(block, scan)
    ok = {v for v in cands if n1[v] == 1 and uses[v] == 1}
    if not ok:
        return block

    def fix(e):
        if e[0] == 'index' and e[1][0] == 'var' and e[1][1] in ok and e[2] == ('lit', 1):
            item = cands[e[1][1]]
            if item[0] == 'unpack':
                x = item[1]
                if x[0] == 'call' and x[1] == ('index', ('glob', 'table'), ('lit', 'pack')) and len(x[2]) == 1 \
                        and x[2][0][0] in ('call', 'mcall'):
                    return ('paren', x[2][0])         # ({unpack(pack(f()))})[1] == (f())
                return ('index', x, ('lit', 1))       # ({unpack(P)})[1] == P[1]
            return ('paren', item)
        return e
    block = map_block(block, fix)

    def drop(b):
        out = []
        for s in b:
            t = s[0]
            nm = s[1][1] if (t == 'assign' and s[1][0] == 'var') else (s[1] if t in ('callres', 'local') else None)
            if nm in ok:
                continue
            if t == 'if':
                out.append(('if', s[1], drop(s[2]), drop(s[3])))
            elif t == 'while':
                out.append(('while', s[1], drop(s[2])))
            else:
                out.append(map_block([s], lambda x: ('func', x[1], drop(x[2]), x[3]) if x[0] == 'func' else x)[0])
        return out
    return drop(block)


# ------------------------------------------------ split variables that only share a name
def split_vars(block):
    """The structurer may emit the same CFG node in several branches, so one register web becomes one
    name with several definitions although every copy is an independent straight-line live range.
    Every definition whose uses are all reached by exactly that definition gets its own name;
    names used across a join (phi) or loop-carried are left alone."""
    def one(body):
        return _split_one(list(body))

    def f(e):
        if e[0] == 'func':
            return ('func', e[1], one(e[2]), e[3])
        return e
    block = map_block(block, f)
    return _split_one(block)


def _terminates(blk):
    if not blk:
        return False
    last = blk[-1]
    if last[0] in ('return', 'break', 'continue'):
        return True
    if last[0] == 'if':
        return _terminates(last[2]) and _terminates(last[3])
    return False


SPLIT_DEBUG = []


def _split_one(block):
    defs, uses = collect(block)
    cand0 = {v for v, dl in defs.items() if len(dl) > 1}
    if not cand0:
        return block
    captured = set()

    def cap(e):
        if e[0] == 'func':
            fd, fu = collect(e[2])
            captured.update(fd)
            captured.update(fu)
        elif e[0] == 'forin':
            captured.update(e[1])
    walk_b(block, cap)
    cand = cand0 - captured
    if not cand:
        return block
    POISON = -1
    st = {'n': 0, 'unsafe': set(), 'newname': {}, 'tokvar': {}}

    def ren(e, env, rewrite):
        def g(x):
            if x[0] == 'var' and x[1] in cand:
                tok = env.get(x[1])
                if tok is None or tok == POISON:
                    st['unsafe'].add(x[1])
                    return x
                nm = st['newname'].get(tok) if rewrite else None
                if nm:
                    return ('var', nm)
            return x
        return map_expr(e, g)

    def newdef(var, env, rewrite):
        st['n'] += 1
        tok = st['n']
        env[var] = tok
        st['tokvar'][tok] = var
        return (st['newname'].get(tok) or var) if rewrite else var

    def proc(b, env, rewrite):
        out = []
        for s in b:
            t = s[0]
            if t in ('callres', 'local'):
                e2 = ren(s[2], env, rewrite)
                name = newdef(s[1], env, rewrite) if s[1] in cand else s[1]
                out.append((t, name, e2))
            elif t == 'assign':
                if s[1][0] == 'var':
                    e2 = ren(s[2], env, rewrite)
                    name = newdef(s[1][1], env, rewrite) if s[1][1] in cand else s[1][1]
                    out.append(('assign', ('var', name), e2))
                else:
                    out.append(('assign', ren(s[1], env, rewrite), ren(s[2], env, rewrite)))
            elif t == 'multi':
                e2 = ren(s[2], env, rewrite)
                names = [newdef(n_, env, rewrite) if n_ in cand else n_ for n_ in s[1]]
                out.append(('multi', names, e2))
            elif t == 'callstmt':
                out.append(('callstmt', ren(s[1], env, rewrite)))
            elif t == 'return':
                out.append(('return', [ren(v, env, rewrite) for v in s[1]]))
            elif t == 'if':
                c = ren(s[1], env, rewrite)
                e1, e2 = dict(env), dict(env)
                a = proc(s[2], e1, rewrite)
                bb = proc(s[3], e2, rewrite)
                t1, t2 = _terminates(s[2]), _terminates(s[3])
                if not (t1 and t2):
                    for v in cand:
                        o, x1, x2 = env.get(v), e1.get(v), e2.get(v)
                        if t1:
                            new = x2
                        elif t2:
                            new = x1
                        elif x1 == o and x2 == o:
                            new = o
                        elif x1 == x2:
                            new = x1
                        else:
                            new = POISON
                        if new != o:
                            env[v] = new
                out.append(('if', c, a, bb))
            elif t == 'while':
                bd, _bu = collect(s[2])
                for v in bd:
                    if v in cand:
                        env[v] = POISON        # loop-carried unless redefined before use in the body
                c = ren(s[1], env, rewrite)
                body = proc(s[2], dict(env), rewrite)
                out.append(('while', c, body))
            else:
                out.append(s)
        return out

    proc(block, {}, False)
    SPLIT_DEBUG.append((len(cand), sorted(st['unsafe'])))
    # names: the first definition keeps the original name, later ones get fresh names
    seen = collections.Counter()
    for tok in sorted(st['tokvar']):
        v = st['tokvar'][tok]
        if v in st['unsafe']:
            continue
        seen[v] += 1
        if seen[v] > 1:
            st['newname'][tok] = '%s_%d' % (v, seen[v])
    if not st['newname']:
        return block
    st['n'] = 0
    return proc(block, {}, True)


def redundant_conds(block):
    """`if C then if C then A else B end ... else E end` -> `if C then A ... else E end`: the condition
    of a branch is already known on entry (a node duplicated by the structurer re-tests it)."""
    from .emit import negate as _neg

    def pure(c):
        return not has_call_expr(c)

    def simple_cond(c):
        # variables, literals and boolean/comparison operators only (no table reads, no calls)
        ok = [True]

        def v(x):
            if x[0] not in ('var', 'lit', 'bin', 'un'):
                ok[0] = False
        walk_e(c, v)
        return ok[0]

    def cond_vars(c):
        names = set()
        walk_e(c, lambda x: names.add(x[1]) if x[0] == 'var' else None)
        return names

    def assigns(st, names):
        d, _u = collect([st])
        return any(n in d for n in names)

    def simplify_first(blk, cond, truth):
        """In ``blk`` (executed when cond == truth) replace a later `if cond` / `if not cond` by the branch
        that is taken, as long as nothing before it assigns a variable of the condition."""
        names = cond_vars(cond) if simple_cond(cond) else None
        blk = list(blk)
        k = 0
        while k < len(blk):
            st = blk[k]
            if st[0] == 'if':
                inner = st
                taken = None
                if inner[1] == cond:
                    taken = inner[2] if truth else inner[3]
                elif inner[1] == _neg(cond) or inner[1] == ('un', 'not', cond):
                    taken = inner[3] if truth else inner[2]
                if taken is not None:
                    blk[k:k + 1] = list(taken)
                    continue
            if names is None or k > 6 or assigns(st, names) or st[0] in ('return', 'break', 'continue'):
                break
            k += 1
        return blk

    def rec(b):
        out = []
        for s in b:
            t = s[0]
            if t == 'if':
                c = s[1]
                th, el = rec(s[2]), rec(s[3])
                if pure(c):
                    th = simplify_first(th, c, True)
                    el = simplify_first(el, c, False)
                out.append(('if', c, th, el))
            elif t == 'while':
                out.append(('while', s[1], rec(s[2])))
            else:
                out.append(map_block([s], lambda x: ('func', x[1], rec(list(x[2])), x[3]) if x[0] == 'func' else x)[0])
        return out
    return rec(list(block))


def has_call_expr(e):
    found = []
    walk_e(e, lambda x: found.append(1) if x[0] in ('call', 'mcall', 'func') else None)
    return bool(found)


def drop_nil_inits(block):
    """`v = nil` (left by the boxing of a captured local) followed by the real `v = <expr>` before any
    other mention of v: the initialisation is dead."""
    def mentions(stmt, name):
        found = []
        walk_b([stmt], lambda x: found.append(1) if x == ('var', name) else None)
        if stmt[0] in ('assign',) and stmt[1] == ('var', name):
            found.append(1)
        if stmt[0] in ('callres', 'local') and stmt[1] == name:
            found.append(1)
        if stmt[0] == 'multi' and name in stmt[1]:
            found.append(1)
        return bool(found)

    def rec(b):
        b = [(_dn_stmt(s)) for s in b]
        out = []
        for i, s in enumerate(b):
            if s[0] == 'assign' and s[1][0] == 'var' and s[2] == ('lit', None):
                v = s[1][1]
                nxt = None
                for t in b[i + 1:]:
                    if mentions(t, v):
                        nxt = t
                        break
                if nxt is not None and nxt[0] == 'assign' and nxt[1] == ('var', v):
                    uses_v = []
                    walk_e(nxt[2], lambda x: uses_v.append(1) if x == ('var', v) else None)
                    if not uses_v:
                        continue
            out.append(s)
        return out

    def _dn_stmt(s):
        t = s[0]
        if t == 'if':
            return ('if', s[1], rec(s[2]), rec(s[3]))
        if t == 'while':
            return ('while', s[1], rec(s[2]))
        return map_block([s], lambda x: ('func', x[1], rec(list(x[2])), x[3]) if x[0] == 'func' else x)[0]
    return rec(list(block))


def clean_conditions(block):
    """`if not not x then` -> `if x then`  (a condition is only tested for truthiness)."""
    def strip(c):
        while c[0] == 'un' and c[1] == 'not' and c[2][0] == 'un' and c[2][1] == 'not':
            c = c[2][2]
        return cond_simplify(c)

    def rec(b):
        out = []
        for s in b:
            t = s[0]
            if t == 'if':
                out.append(('if', strip(s[1]), rec(s[2]), rec(s[3])))
            elif t == 'while':
                out.append(('while', s[1] if s[1][0] == 'forin' else strip(s[1]), rec(s[2])))
            else:
                out.append(map_block([s], lambda x: ('func', x[1], rec(list(x[2])), x[3]) if x[0] == 'func' else x)[0])
        return out
    return rec(list(block))


def strip_tail_return(block):
    """A bare `return` in tail position of a function (or of the chunk) does nothing."""
    def tail(b):
        b = list(b)
        if b and b[-1] == ('return', []):
            return b[:-1]
        if b and b[-1][0] == 'if':
            last = b[-1]
            b[-1] = ('if', last[1], tail(last[2]), tail(last[3]))
        return b

    def fn(x):
        if x[0] == 'func':
            return ('func', x[1], tail(x[2]), x[3])
        return x
    return tail(map_block(block, fn))


def flatten_guards(block):
    """`if C then return .. else E end` -> `if C then return .. end; E` (guard clauses instead of
    pyramids of `else`); the symmetric `if C then T else return .. end` becomes `if not C then
    return .. end; T`."""
    from .emit import negate as _neg

    def rec(b):
        out = []
        for s in b:
            t = s[0]
            if t == 'if':
                c, th, el = s[1], rec(s[2]), rec(s[3])
                if el and _terminates(th):
                    out.append(('if', c, th, []))
                    out.extend(el)
                elif el and th and _terminates(el) and len(th) >= len(el):
                    out.append(('if', _neg(c), el, []))
                    out.extend(th)
                else:
                    out.append(('if', c, th, el))
            elif t == 'while':
                out.append(('while', s[1], rec(s[2])))
            else:
                out.append(map_block([s], lambda x: ('func', x[1], rec(list(x[2])), x[3]) if x[0] == 'func' else x)[0])
        return out
    return rec(list(block))


def _try_neg(x):
    """The negation of x without a `not` in front, if x has such a form (else None)."""
    if x[0] == 'un' and x[1] == 'not':
        return x[2]
    if x[0] == 'bin' and x[1] == '==':
        return ('bin', '~=', x[2], x[3])
    if x[0] == 'bin' and x[1] == '~=':
        return ('bin', '==', x[2], x[3])
    if x[0] == 'bin' and x[1] in ('or', 'and'):
        a, b = _try_neg(x[2]), _try_neg(x[3])
        if a is not None and b is not None:
            return ('bin', 'and' if x[1] == 'or' else 'or', a, b)
    return None


def cond_simplify(c):
    """Truthiness-only simplification of a condition: De Morgan when every operand loses its `not`."""
    t = c[0]
    if t == 'un' and c[1] == 'not' and c[2][0] == 'bin' and c[2][1] in ('or', 'and'):
        n = _try_neg(c[2])
        if n is not None:
            return cond_simplify(n)
    if t == 'bin' and c[1] in ('or', 'and'):
        return ('bin', c[1], cond_simplify(c[2]), cond_simplify(c[3]))
    if t == 'un' and c[1] == 'not':
        return ('un', 'not', cond_simplify(c[2]))
    return c


def flip_comparisons(block):
    """`not (a == b)` -> `a ~= b`, `not (a ~= b)` -> `a == b` (exact in every context)."""
    swap = {'<': '>', '<=': '>=', '>': '<', '>=': '<=', '==': '==', '~=': '~='}

    def f(e):
        if e[0] == 'un' and e[1] == 'not' and e[2][0] == 'bin' and e[2][1] in ('==', '~='):
            return _try_neg(e[2])
        # `0 < n` -> `n > 0`: the constant goes right (Lua evaluates `b > a` as `a < b`: same metamethod, same order
        # of the observable operand)
        if e[0] == 'bin' and e[1] in swap and e[2][0] == 'lit' and e[3][0] != 'lit':
            return ('bin', swap[e[1]], e[3], e[2])
        return e
    return map_block(block, f)


def strip_tail_continue(block):
    """A `continue` that ends a loop body (also at the end of the branches of a trailing `if`) is implicit."""
    def tail(b):
        b = list(b)
        if b and b[-1] == ('continue',):
            return b[:-1]
        if b and b[-1][0] == 'if':
            last = b[-1]
            b[-1] = ('if', last[1], tail(last[2]), tail(last[3]))
        return b

    def rec(b):
        out = []
        for s in b:
            t = s[0]
            if t == 'if':
                out.append(('if', s[1], rec(s[2]), rec(s[3])))
            elif t == 'while':
                out.append(('while', s[1], tail(rec(s[2]))))
            else:
                out.append(map_block([s], lambda x: ('func', x[1], rec(list(x[2])), x[3]) if x[0] == 'func' else x)[0])
        return out
    return rec(list(block))


def mask_unresolved(block):
    """A statement whose operands include a constant that was never decoded cannot be shown faithfully:
    a store or a bare call is replaced by an explicit comment instead of `x[nil] = (nil)[nil]` noise."""
    def has_unknown(e):
        found = []
        walk_e_shallow(e, lambda x: found.append(1) if x[0] == 'unknown' else None)    # not inside closures
        return bool(found)

    def rec(b):
        out = []
        for s in b:
            t = s[0]
            if t == 'callstmt' and has_unknown(s[1]):
                out.append(('comment', 'unresolved call: its constants were never decoded (code not executed)'))
            elif t == 'assign' and s[1][0] != 'var' and (has_unknown(s[1]) or has_unknown(s[2])):
                out.append(('comment', 'unresolved store: its constants were never decoded (code not executed)'))
            elif t == 'if':
                out.append(('if', s[1], rec(s[2]), rec(s[3])))
            elif t == 'while':
                out.append(('while', s[1], rec(s[2])))
            else:
                out.append(map_block([s], lambda x: ('func', x[1], rec(list(x[2])), x[3]) if x[0] == 'func' else x)[0])
        return out
    return rec(list(block))
