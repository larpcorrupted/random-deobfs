"""Variant detection and VM instrumentation for Luaq samples.

Everything here is *structural*: names of the dispatch variables are discovered
from the sample text (the obfuscator renames them per sample), nothing is keyed
on a particular sample.  The VM bytes are never edited before its self-check
runs; we only add calls to external hook functions at statement boundaries
that exist in every generated VM.
"""
import re

LOOP_RE = re.compile(
    r'while (\w+) do (?:do )?local (\w+)=\(?(\w+)([+\-])(\w+)\)?;')

PFORM_RE = re.compile(
    r'local (\w+)=\((?:'
    r'(\w+)\*(0x[0-9a-fA-F]+|\d+)([+\-])(0x[0-9a-fA-F]+|\d+)'
    r'|(0x[0-9a-fA-F]+|\d+)([+\-])(0x[0-9a-fA-F]+|\d+)\*(\w+)'
    r')\)\%(0x[0-9a-fA-F]+|\d+);')

METHOD_CALL_RE = re.compile(r'((?:\w+,)*\w+)=((?:\w+):(?:\w+)\()[^;)]*\);continue;')


class Unsupported(Exception):
    """Raised when the sample is not a recognised Luaq layout."""


def detect(src):
    """Return a dict describing the variant of the sample."""
    info = {'variant': None, 'reason': ''}
    if 'LUAQ' not in src and 'setmetatable' not in src:
        raise Unsupported('no Luaq markers (LUAQ magic / setmetatable wrapper)')
    from . import luaparse as lp_
    has_goto = ('kw', 'goto') in set(lp_.tokenize(src))
    info['has_goto'] = has_goto
    info['variant'] = 'A'
    info['reason'] = 'goto build (Lua 5.4 executor target)' if has_goto else 'standard build'
    return info


def find_loop(src):
    hits = list(LOOP_RE.finditer(src))
    if not hits:
        raise Unsupported('dispatch loop not found')
    best = None
    for m in hits:
        tail = src[m.end():m.end() + 400000]
        score = len(re.findall(r'if p==\d+ then', tail))
        score += len(re.findall(r'\);continue;', tail))
        if best is None or score > best[0]:
            best = (score, m)
    return best[1]


def pretty(tree):
    t = tree.replace(';', ';\n')
    t = re.sub(r'then\b', 'then\n', t)
    t = re.sub(r'\bdo\b', '\ndo\n', t)
    t = re.sub(r'(?<!else)\belse\b', '\nelse ', t)
    return t


def discover_names(tree):
    """Find the register table (u), operand table (a), env (x), pc (y), opcode (M)."""
    u_name = a_name = x_name = y_name = M_name = None
    for fm in PFORM_RE.finditer(tree):
        win = tree[fm.end():fm.end() + 20000]
        mu = re.search(r'(\w+)\[(\w+)\[\d+\]\]', win)
        if not mu:
            continue
        M_name = fm.group(2) or fm.group(9)
        u_name, a_name = mu.group(1), mu.group(2)
        mx = re.search(r'\w+\((\w+),\w+\[\d+\],', win)
        if mx:
            x_name = mx.group(1)
        my = re.search(r'(\w+)=\1\+\d+', win)
        if my:
            y_name = my.group(1)
        if u_name and a_name and x_name and y_name:
            break
    return dict(u=u_name, a=a_name, x=x_name, y=y_name, M=M_name)


_ARGSPREAD_RE = re.compile(r'\[\s*\(?\s*(\w+)\s*\)?\s*\[\s*1\s*\]\s*\)?\s*\]\s*=\s*\.\.\.')


def find_param_field(src):
    """Name of the proto field listing the parameter registers.

    The call wrapper of the VM copies the call arguments into registers with
    ``regs[P[1]] = ...`` where ``local P = proto.<field>``; the field name is renamed per
    sample, the shape is not.  Returns None when the wrapper has another shape (the data-shape
    fallback in trace.guess_param_field is used then)."""
    m = _ARGSPREAD_RE.search(src)
    if not m:
        return None
    head = src[max(0, m.start() - 1500):m.start()]
    cands = re.findall(r'local\s+%s\s*=\s*\(?\s*\w+\s*\)?\s*(?:\.(\w+)|\[\s*"(\w+)"\s*\])\s*;' % re.escape(m.group(1)), head)
    if not cands:
        return None
    return cands[-1][0] or cands[-1][1]


_OPEN_KW = ('function', 'if', 'do', 'repeat')


def _match_end(toks, i):
    """Index of the `end` closing the `function` keyword at token index i (None if unbalanced)."""
    depth = 0
    for t in range(i, len(toks)):
        k, v = toks[t]
        if k != 'kw':
            continue
        if v in _OPEN_KW:
            depth += 1
        elif v in ('end', 'until'):
            depth -= 1
            if depth == 0:
                return t
    return None


def find_closure_factory(src, lp):
    """Insertion points for `__ENTER(f)` (first statement of every user-closure wrapper) and
    `__NEWCL(f)` (before the wrapper is returned by its factory).

    The wrapper is the vararg function that copies its arguments into registers
    (`regs[P[1]] = ...`); it is bound to a local `f` which the factory returns.  Returns
    (enter_offset, newcl_offset, name) or None."""
    m = _ARGSPREAD_RE.search(src)
    if not m:
        return None
    offs = []
    toks = lp.tokenize(src, offs)
    idx = None
    for t, (a, b) in enumerate(offs):
        if a >= m.start():
            idx = t
            break
    if idx is None:
        return None
    pend = 0
    found = None
    for t in range(idx, -1, -1):
        k, v = toks[t]
        if k != 'kw':
            continue
        if v in ('end', 'until'):
            pend += 1
        elif v in _OPEN_KW:
            if pend > 0:
                pend -= 1
            elif v == 'function':
                found = t
                break
    if found is None or found < 2 or found + 3 >= len(toks):
        return None
    if not (toks[found + 1] == ('op', '(') and toks[found + 2][1] == '...' and toks[found + 3] == ('op', ')')):
        return None
    if not (toks[found - 1] == ('op', '=') and toks[found - 2][0] == 'name'):
        return None
    name = toks[found - 2][1]
    end = _match_end(toks, found)
    if end is None:
        return None
    depth = 0
    ret = None
    for t in range(end + 1, len(toks)):
        k, v = toks[t]
        if k == 'kw' and v in _OPEN_KW:
            depth += 1
        elif k == 'kw' and v in ('end', 'until'):
            depth -= 1
            if depth < 0:
                break
        elif k == 'kw' and v == 'return' and t + 1 < len(toks) and toks[t + 1] == ('name', name):
            ret = t
            break
    if ret is None:
        return None
    # the factory around the wrapper: function(child, ..., creator_proto, child_index, ...) -- the wrapper decodes its
    # body lazily with `body = decoder(creator_proto, child_index, ...)`; those two names give the exact link
    # between a closure and the child proto it runs
    cp_name = ci_name = None
    try:
        pend2 = 0
        enc = None
        for t in range(found - 1, -1, -1):
            k, v = toks[t]
            if k != 'kw':
                continue
            if v in ('end', 'until'):
                pend2 += 1
            elif v in _OPEN_KW:
                if pend2 > 0:
                    pend2 -= 1
                elif v == 'function':
                    enc = t
                    break
        if enc is not None and toks[enc + 1] == ('op', '('):
            params = []
            t = enc + 2
            while t < len(toks) and toks[t] != ('op', ')'):
                if toks[t][0] == 'name':
                    params.append(toks[t][1])
                t += 1
            if len(params) >= 5:
                body = src[offs[found][0]:offs[end][1]]
                import re as _re
                if _re.search(r'=\w+\(%s,%s[,)]' % (params[3], params[4]), body):
                    cp_name, ci_name = params[3], params[4]
    except Exception:
        cp_name = ci_name = None
    # `body = decoder(creator_proto, child_index, ...)` inside the wrapper: the point right after it knows the exact
    # child proto the closure runs (a closure whose body produces no trace row cannot be linked by position)
    child_ins = None
    if cp_name:
        for t in range(found, end - 6):
            if (toks[t][0] == 'name' and toks[t + 1] == ('op', '=') and toks[t + 2][0] == 'name'
                    and toks[t + 3] == ('op', '(') and toks[t + 4] == ('name', cp_name)
                    and toks[t + 5] == ('op', ',') and toks[t + 6] == ('name', ci_name)):
                depth_p = 0
                for u in range(t + 3, end):
                    if toks[u] == ('op', '('):
                        depth_p += 1
                    elif toks[u] == ('op', ')'):
                        depth_p -= 1
                        if depth_p == 0:
                            child_ins = (offs[u][1], toks[t][1])
                            break
                break
    return offs[found + 3][1], offs[ret][0], name, cp_name, ci_name, child_ins


def instrument(src, sweep=False):
    """AST-driven instrumentation of a Luaq VM (dispatch-tree family).

    A probe ``__OPANY(proto, pc, M, regs, leafid, operands)`` is inserted at the start of
    every exec-leaf handler, using the variable names *that handler* uses for these roles
    (the VM permutes the variables between decode paths).  Pc-moving conditions are wrapped
    in ``__BR(...)`` so a replay can invert them.
    """
    from . import luaparse as lp, vmmodel, symexec, gotos
    prelude = ''
    goto_edits = 0
    if ('kw', 'goto') in set(lp.tokenize(src)):
        # Lua 5.4 executor build: forward gotos closing a loop body become `continue`
        src, goto_edits = gotos.goto_to_continue(src)
        prelude = '__FORCE54ENV = true\n'
    ast, offs = lp.parse(src, True)
    vm = vmmodel.VMModel(ast)
    vm.param_field = find_param_field(src)
    if vm.v25:
        return _instrument25(src, offs, vm, sweep, prelude, goto_edits)
    inserts = []
    nbr = 0
    ncf = 0
    cf_done = set()
    missing = 0
    hooked = 0
    for gid, lf in vm.leaves.items():
        found = []
        lp.walk(lf.formula[0], lambda n: found.append(n[1]) if n[0] == 'Name' else None)
        mname = found[0] if found else None
        if mname is None:
            raise Unsupported('opcode variable of leaf %s not found' % gid)
        roles_l = [vm.roles_of(b) for b in lf.cases.values()]
        roles_l = [r for r in roles_l if r is not None]
        if not roles_l:
            raise Unsupported('no register accesses found in the handlers of leaf %s' % gid)

        def major(attr):
            from collections import Counter
            c = Counter(getattr(r, attr) for r in roles_l if getattr(r, attr))
            return c.most_common(1)[0][0] if c else None
        fb = dict(pc=major('pc'), x=major('x'))
        for pcase, body in lf.cases.items():
            hr = vm.roles_of(body)
            bs = offs.bstarts.get(id(body))
            if hr is None or bs is None:
                # no register/operand pair recognisable in this handler (e.g. a fused micro-op
                # block): the loop-head probe still records it; its branch decisions are hooked
                # with the pc name of the leaf so that exploration can flip them
                missing += 1
                pcname = fb['pc']
            else:
                pcname = hr.pc or fb['pc']
                xname = hr.x or fb['x'] or 'nil'
                call = '__OPANY(%s,%s,%s);' % (xname, hr.u, hr.a)
                inserts.append((offs[bs][0], call))
                hooked += 1
            if pcname is None:
                continue

            def moves_pc(blk, pcn=pcname):
                for st in blk:
                    if st[0] == 'Assign' and len(st[1]) == 1 and st[1][0] == ('Name', pcn):
                        return True
                    if st[0] == 'CAssign' and st[2] == ('Name', pcn):
                        return True
                return False

            xname_ = (hr.x if hr is not None else None) or fb['x']

            def visit(nd, moves_pc=moves_pc, pcname=pcname, xname_=xname_):
                nonlocal nbr, ncf
                # constant fetch `helper(proto, index, state)`: logged, so that a constant that is absent
                # from the pool after it was fetched can be told from one that was never decoded (nil)
                if (nd[0] == 'Call' and xname_ and len(nd[2]) == 3 and nd[2][0] == ('Name', xname_)
                        and nd[2][1][0] == 'Name' and offs.cranges and id(nd) in offs.cranges
                        and id(nd) not in cf_done):
                    cf_done.add(id(nd))
                    c0, c1 = offs.cranges[id(nd)]
                    inserts.append((offs[c0][0], '__CF('))
                    inserts.append((offs[c1 - 1][1], ',%s,%s)' % (xname_, nd[2][1][1])))
                    ncf += 1
                if sweep and nd[0] in ('Assign', 'CAssign'):
                    tgt = nd[1][0] if nd[0] == 'Assign' and len(nd[1]) == 1 else (nd[2] if nd[0] == 'CAssign' else None)
                    rng_ = offs.sranges.get(id(nd)) if offs.sranges else None
                    if tgt == ('Name', pcname) and rng_ is not None:
                        # after every pc assignment the sweep may redirect the pc; an absolute target
                        # (hashed jump) is reported, a relative one is known from the effects
                        rel = nd[0] == 'CAssign'
                        if nd[0] == 'Assign':
                            lp.walk(nd[2], lambda n_: None)
                            found_ = []
                            lp.walk(nd[2], lambda n_: found_.append(1) if n_ == ('Name', pcname) else None)
                            rel = bool(found_)
                        inserts.append((offs[rng_[1] - 1][1], ';%s=%s(%s)' % (pcname, '__PCWR' if rel else '__PCWA', pcname)))
                if nd[0] == 'If' and len(nd) > 3:
                    for (cond, blk), (a0, a1) in zip(nd[1], nd[3]):
                        if moves_pc(blk):
                            inserts.append((offs[a0][0], ' __BR('))
                            inserts.append((offs[a1 - 1][1], ')'))
                            nbr += 1
            lp.walk(body, visit)
    if hooked == 0:
        raise Unsupported('no handler could be instrumented')
    # loop-head probe: stable variable names (pc, opcode word, dispatch state) of the dispatch loop
    first = vm.loop[2][0]
    if first[0] == 'Do':
        first = first[1][0]
    rng = first[3]
    end_off = offs[rng[1] - 1][1]
    mnames = []
    for lf in vm.leaves.values():
        found = []
        lp.walk(lf.formula[0], lambda n: found.append(n[1]) if n[0] == 'Name' else None)
        if found:
            mnames.append(found[0])
    from collections import Counter as _C
    mname_g = _C(mnames).most_common(1)[0][0]
    pc_g = vm._majority_pc()
    if not pc_g:
        raise Unsupported('program counter variable not found')
    cases_all = [c for l in vm.leaves.values() for c in list(l.cases.values())[:40]]
    groles = symexec.discover_roles(vm, cases_all)
    call = '__OPH(%s,%s,%s,%s,%s,%s);' % (pc_g, mname_g, vm.gname, groles.x or 'nil', groles.u, groles.a)
    if src[end_off:end_off + 1] == ';':
        end_off += 1
    else:
        call = ';' + call
    inserts.append((end_off, call))
    prelude += '__LEAVES = {%s}' % ','.join('[%d]=true' % g for g in vm.leaves) + chr(10)
    # closure registry (replay-time exercising of closures that the program never calls)
    cf = None
    try:
        cf = find_closure_factory(src, lp)
    except Exception:
        cf = None
    if cf:
        inserts.append((cf[0], '__ENTER(%s);' % cf[2]))
        newcl_txt = ('__NEWCL(%s,%s,%s);' % (cf[2], cf[3], cf[4])) if cf[3] else ('__NEWCL(%s);' % cf[2])
        if sweep:
            # the closure the program receives contains the errors of its body while the sweep drives a call: one
            # callee that raises on a dummy value would otherwise end its caller's call and hide the code behind it
            newcl_txt += 'do return __SAFECL(%s) end;' % cf[2]
        inserts.append((cf[1], newcl_txt))
        if cf[5]:
            inserts.append((cf[5][0], ';__CHILD(%s,%s)' % (cf[2], cf[5][1])))
    # apply from the end of the file towards the start; at equal offsets a closing paren
    # must go in before an opening call so nesting stays correct
    inserts.sort(key=lambda t: (t[0], 1 if t[1] == ')' else 0), reverse=True)
    out = src
    for off, txt in inserts:
        out = out[:off] + txt + out[off:]
    out = 'local __OPANY,__OPH,__BR,__ENTER,__NEWCL,__CF,__CHILD,__SAFECL=__OPANY,__OPH,__BR,__ENTER,__NEWCL,__CF,__CHILD,__SAFECL;' + chr(10) + out
    info = dict(prelude=prelude, goto_edits=goto_edits, branches=nbr, const_fetches=ncf, hooked=hooked, missing=missing,
                sweep=sweep,
                closure_hook=bool(cf),
                leaves=len(vm.leaves), steps=len(vm.steps),
                handlers=sorted(len(l.cases) for l in vm.leaves.values()))
    roles = groles
    return out, info, vm, roles


def _srange(st, offs):
    """(first token, token after the last) of a statement."""
    if st[0] in ('Local', 'While', 'Goto', 'Label') and len(st) > 0 and isinstance(st[-1], tuple) \
            and len(st[-1]) == 2 and isinstance(st[-1][0], int):
        return st[-1]
    return offs.sranges.get(id(st)) if offs.sranges else None


def _closure_inserts(src, lp, sweep, inserts):
    cf = None
    try:
        cf = find_closure_factory(src, lp)
    except Exception:
        cf = None
    if cf:
        inserts.append((cf[0], '__ENTER(%s);' % cf[2]))
        newcl_txt = ('__NEWCL(%s,%s,%s);' % (cf[2], cf[3], cf[4])) if cf[3] else ('__NEWCL(%s);' % cf[2])
        if sweep:
            newcl_txt += 'do return __SAFECL(%s) end;' % cf[2]
        inserts.append((cf[1], newcl_txt))
        if cf[5]:
            inserts.append((cf[5][0], ';__CHILD(%s,%s)' % (cf[2], cf[5][1])))
    return cf


def _apply(src, inserts):
    inserts.sort(key=lambda t: (t[0], 1 if t[1] == ')' else 0), reverse=True)
    out = src
    for off, txt in inserts:
        out = out[:off] + txt + out[off:]
    return out


def _crypt_prelude():
    import io as _io
    import os as _os
    p = _os.path.join(_os.path.dirname(_os.path.abspath(__file__)), 'runtime', 'crypt.lua')
    return _io.open(p, encoding='utf-8').read() + chr(10)


def _instrument25(src, offs, vm, sweep, prelude, goto_edits):
    """Luaq 2.5: one dispatch case per opcode.  Probes: loop head (pc, opcode word, state, proto, registers), the
    decoded operands right after each handler's decode prologue (`__OPV`), branch hooks on the conditions of the
    handler semantics that move the pc, constant fetches, closure registry."""
    from . import luaparse as lp, symexec
    inserts = []
    nbr = ncf = hooked = missing = 0
    pcn = vm.pcname
    if not (pcn and vm.protoname and vm.regname):
        raise Unsupported('2.5 VM roles not found (pc=%s proto=%s regs=%s)' % (pcn, vm.protoname, vm.regname))
    for gid, hb in vm.leaves.items():
        blk = hb.block
        sp = hb.split
        r = hb.roles
        if sp is not None:
            b = sp['boundary']
            if b < len(blk):
                rng = _srange(blk[b], offs)
                off = offs[rng[0]][0] if rng else None
            else:
                rng = _srange(blk[b - 1], offs)
                off = offs[rng[1] - 1][1] if rng else None
            if off is None:
                missing += 1
            else:
                tbl = r.a or 'nil'
                args = [tbl] + list(hb.oplocals)
                txt = '__OPV(%s);' % ','.join(args)
                if b >= len(blk):
                    txt = ';__OPV(%s)' % ','.join(args)
                inserts.append((off, txt))
                hooked += 1
        else:
            missing += 1

        def visit(nd, r=r):
            nonlocal nbr, ncf
            if nd[0] == 'Function':
                return False
            if (nd[0] == 'Call' and len(nd[2]) == 3 and nd[2][0] == ('Name', r.x) and offs.cranges
                    and id(nd) in offs.cranges and (nd[2][1][0] == 'Name' or (
                        nd[2][1][0] == 'Index' and nd[2][1][1][0] == 'Name' and nd[2][1][2][0] == 'Number'))):
                c0, c1 = offs.cranges[id(nd)]
                inserts.append((offs[c0][0], '__CF('))
                inserts.append((offs[c1 - 1][1], ',%s,%s)' % (r.x, lp.ue(nd[2][1]))))
                ncf += 1
            if sweep and nd[0] in ('Assign', 'CAssign'):
                tgt = nd[1][0] if nd[0] == 'Assign' and len(nd[1]) == 1 else (nd[2] if nd[0] == 'CAssign' else None)
                rng_ = offs.sranges.get(id(nd)) if offs.sranges else None
                if tgt == ('Name', r.pc) and rng_ is not None:
                    rel = nd[0] == 'CAssign'
                    if nd[0] == 'Assign':
                        found_ = []
                        lp.walk(nd[2], lambda n_: found_.append(1) if n_ == ('Name', r.pc) else None)
                        rel = bool(found_)
                    inserts.append((offs[rng_[1] - 1][1], ';%s=%s(%s)' % (r.pc, '__PCWR' if rel else '__PCWA', r.pc)))
            if nd[0] == 'If' and len(nd) > 3:
                for (cond, blk_), (a0, a1) in zip(nd[1], nd[3]):
                    if any((st[0] == 'Assign' and len(st[1]) == 1 and st[1][0] == ('Name', r.pc))
                           or (st[0] == 'CAssign' and st[2] == ('Name', r.pc)) for st in blk_):
                        inserts.append((offs[a0][0], ' __BR('))
                        inserts.append((offs[a1 - 1][1], ')'))
                        nbr += 1
        lp.walk(list(hb), visit)
    if hooked == 0:
        raise Unsupported('no 2.5 handler could be instrumented')
    # loop-head probe right after `local <state> = Q + g`
    first = vm.loop[2][0]
    if first[0] == 'Do':
        first = first[1][0]
    rng = first[3]
    end_off = offs[rng[1] - 1][1]
    call = '__OPH(%s,%s,%s,%s,%s,nil);' % (pcn, vm.opname, vm.gname, vm.protoname, vm.regname)
    if src[end_off:end_off + 1] == ';':
        end_off += 1
    else:
        call = ';' + call
    inserts.append((end_off, call))
    prelude = _crypt_prelude() + prelude
    prelude += '__LEAVES = {%s}' % ','.join('[%d]=true' % g for g in vm.leaves) + chr(10)
    # no remote session in 2.5: the program's own code starts with the first instruction
    prelude += '__V25 = true' + chr(10) + '__OPENED = true' + chr(10)
    cf = _closure_inserts(src, lp, sweep, inserts)
    out = _apply(src, inserts)
    out = ('local __OPANY,__OPH,__BR,__ENTER,__NEWCL,__CF,__CHILD,__SAFECL,__OPV=__OPANY,__OPH,__BR,__ENTER,__NEWCL,'
           '__CF,__CHILD,__SAFECL,__OPV;' + chr(10) + out)
    info = dict(prelude=prelude, goto_edits=goto_edits, branches=nbr, const_fetches=ncf, hooked=hooked, missing=missing,
                sweep=sweep, closure_hook=bool(cf), leaves=len(vm.leaves), steps=len(vm.steps), version='2.5',
                handlers=[len(vm.leaves)])
    roles = symexec.Roles(vm.regname, vm.opstable, vm.protoname, pcn, vm.flag)
    return out, info, vm, roles
