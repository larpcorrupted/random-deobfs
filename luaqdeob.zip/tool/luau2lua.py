"""luau2lua.py -- token-level Luau -> Lua 5.1 transform for machine-generated Luaq VM code.

Handles the three Luau-only constructs found in Luaq v2.4 output:
  1. compound assignment:   X += E        ->  X = X + E
  2. floor division:        A // B        ->  math.floor(A / B)
  3. `continue` statements  -> repeat/break loop-body wrapping

Everything else passes through untouched.
"""
import sys, re

# ---------------------------------------------------------------- tokenizer
TOKEN_RE = re.compile(r'''
    (?P<ws>\s+)
  | (?P<lstr>\[(=*)\[)
  | (?P<comment>--(?:\[(=*)\[.*?\]\5\]|.*?(?=\n|$)))
  | (?P<num>0[xX][0-9a-fA-F]+|\d+\.\d*([eE][+-]?\d+)?|\.\d+([eE][+-]?\d+)?|\d+([eE][+-]?\d+)?)
  | (?P<name>[A-Za-z_]\w*)
  | (?P<str>"(?:\\.|[^"\\])*"|'(?:\\.|[^'\\])*')
  | (?P<op>\+=|-=|\*=|/=|//=|%=|\^=|\.\.=|//|==|~=|<=|>=|\.\.\.|\.\.|->|::|.)
''', re.X | re.S)

def tokenize(src):
    toks = []
    i = 0
    n = len(src)
    while i < n:
        m = TOKEN_RE.match(src, i)
        if not m:
            raise SyntaxError(f"tokenize failed at {i}: {src[i:i+30]!r}")
        kind = m.lastgroup
        if kind == 'lstr':
            eq = m.group(0)[1:-1]  # the '=' run between the brackets
            closer = ']' + eq + ']'
            j = src.find(closer, m.end())
            if j < 0:
                raise SyntaxError("unterminated long string")
            toks.append(('str', src[i:j + len(closer)]))
            i = j + len(closer)
            continue
        if kind in ('ws',):
            i = m.end()
            continue
        if kind == 'comment':
            i = m.end()
            continue
        toks.append((kind if kind in ('name', 'num', 'str') else 'op', m.group(0)))
        i = m.end()
    return toks

# ------------------------------------------------------- block structure
BLOCK_OPEN = {'for', 'while', 'if', 'function', 'do', 'repeat'}
BLOCK_MID = {'else', 'elseif', 'until'}

def find_blocks(toks):
    """Yield (kw_index, do_index, end_index) for each for/while loop at any depth.
    Only `for`/`while` need wrapping (continue targets those)."""
    # build matching brace/paren/bracket spans to know where expressions end
    loops = []
    stack = []  # entries: ('for'|'while'|'if'|'function'|'do'|'repeat', start)
    i = 0
    n = len(toks)
    while i < n:
        t, v = toks[i]
        if t == 'name':
            if v in ('for', 'while'):
                stack.append((v, i))
            elif v == 'if':
                stack.append(('if', i))
            elif v == 'function':
                stack.append(('function', i))
            elif v == 'do':
                # closes for/while, or standalone do-block
                if stack and stack[-1][0] in ('for', 'while'):
                    loops.append((stack[-1][0], stack[-1][1], i))
                    stack[-1] = (stack[-1][0] + '-body', stack[-1][1], i)
                else:
                    stack.append(('do', i))
            elif v == 'repeat':
                stack.append(('repeat', i))
            elif v == 'until':
                if stack and stack[-1][0] == 'repeat':
                    stack.pop()
            elif v == 'end':
                if stack:
                    stack.pop()
        i += 1
    return loops, stack

def match_end(toks, start):
    """Given index of loop keyword (for/while), find its body `do` and matching `end`."""
    depth = 0
    i = start
    n = len(toks)
    do_i = None
    while i < n:
        t, v = toks[i]
        if t == 'name':
            if v in ('for', 'while', 'if', 'do', 'function', 'repeat'):
                # 'for'/'while' push but their 'do' comes later; standalone do pushes
                if v in ('for', 'while'):
                    pass
                depth += 1 if v in ('do', 'function', 'repeat', 'if', 'for', 'while') else 0
            elif v == 'end':
                depth -= 1
                if depth == 0:
                    return do_i, i
            elif v == 'do' and depth == 1 and do_i is None:
                do_i = i
        i += 1
    raise SyntaxError("no matching end")

# ------------------------------------------------------------ transforms

def transform_compound(toks):
    """X op= E  ->  X = X op E   (statement level; X is a suffixedexp)."""
    out = toks[:]
    changed = []
    i = 0
    n = len(out)
    while i < n:
        t, v = out[i]
        if v in ('+=', '-=', '*=', '/=', '^=', '%=', '..='):
            # LHS is a suffixedexp ending at i-1: walk back over name/.:/index/call chains
            k = i - 1
            tk, tv = out[k]
            if tv in (')', ']', '}'):
                closer = tv
                opener = {'}': '{', ']': '[', ')': '('}[closer]
                depth = 0
                while k >= 0:
                    tv2 = out[k][1]
                    if tv2 in (')', ']', '}'):
                        depth += 1
                    elif tv2 in ('(', '[', '{'):
                        depth -= 1
                        if depth == 0:
                            break
                    k -= 1
            elif tk == 'name':
                pass
            else:
                raise SyntaxError(f"bad compound-assign LHS near token {k}")
            while k > 0 and out[k-1][1] in ('.', ':'):
                k -= 2
            start = k
            # find end of RHS: up to ';' or end of block-ish at same depth
            depth = 0
            e = i + 1
            while e < n:
                tv = out[e][1]
                if tv in ('(', '[', '{'):
                    depth += 1
                elif tv in (')', ']', '}'):
                    if depth == 0:
                        break
                    depth -= 1
                elif depth == 0 and tv == ';':
                    break
                elif depth == 0 and tv in ('end', 'else', 'elseif', 'until'):
                    break
                e += 1
            lhs = out[start:i]
            rhs = out[i+1:e]
            op = v[:-1]
            if op == '..':
                op = '..'
            repl = lhs + [('op', '='), ('op', '(')] + lhs + [('op', op), ('op', '(')] + rhs + [('op', ')'), ('op', ')')]
            if e < n and out[e][1] == ';':
                repl = repl + [('op', ';')]
                e += 1
            out[start:e] = repl
            changed.append((start, e))
            n = len(out)
            i = start + len(repl)
            continue
        i += 1
    return out, changed

def transform_floordiv(toks):
    """A // B  ->  math.floor(A / B) where A,B are simple operands."""
    out = toks[:]
    i = 0
    n = len(out)
    while i < n:
        if out[i][1] == '//' and out[i][0] == 'op':
            # find left operand end = i-1; operand start: walk back over simple primary
            j = i - 1
            tk, tv = out[j]
            start = j
            if tv in (')', ']', '}'):
                depth = 0
                while j >= 0:
                    tv2 = out[j][1]
                    if tv2 in (')', ']', '}'):
                        depth += 1
                    elif tv2 in ('(', '[', '{'):
                        depth -= 1
                        if depth == 0:
                            break
                    j -= 1
                start = j
                # if this was a call: consume leading name/index chain
                while start > 0 and out[start-1][1] in ('.', ':'):
                    start -= 2
            elif tk in ('name', 'num', 'str'):
                start = j
                while start > 0 and out[start-1][1] in ('.', ':'):
                    start -= 2
            else:
                raise SyntaxError(f"unexpected // LHS at token {j}: {out[max(0,j-3):i+2]}")
            # right operand
            e = i + 1
            tk2, tv2 = out[e]
            if tv2 in ('(', '[', '{') or tk2 in ('name', 'num', 'str') or tv2 == '-':
                end = e
                # consume suffixes: calls, indexes, '.', ':'
                while end + 1 < n:
                    nxt = out[end+1]
                    if nxt[1] in ('(', '[', '{'):
                        # match forward
                        depth = 0
                        k = end + 1
                        while k < n:
                            tv3 = out[k][1]
                            if tv3 in ('(', '[', '{'):
                                depth += 1
                            elif tv3 in (')', ']', '}'):
                                depth -= 1
                                if depth == 0:
                                    break
                            k += 1
                        end = k
                    elif nxt[1] in ('.', ':'):
                        end += 2
                    else:
                        break
            else:
                raise SyntaxError(f"unexpected // RHS at {e}")
            repl = [('name', 'math'), ('op', '.'), ('name', 'floor'), ('op', '(')] + \
                   out[start:i] + [('op', '/')] + out[i+1:end+1] + [('op', ')')]
            out[start:end+1] = repl
            n = len(out)
            i = start + len(repl)
            continue
        i += 1
    return out

def transform_continue(toks):
    """Rewrite `continue` using the Lua 5.2 goto idiom (LuaJIT supports goto):
       loop body:  ... continue ...     ->  ... goto continue_lbl ...
       insert `::continue_lbl::` before the loop's closing `end`.
    """
    out = toks[:]
    label_n = 0
    for _ in range(200):
        loops = find_loops(out)
        target = None
        for kw_i, do_i, end_i in loops:
            body = out[do_i+1:end_i]
            if has_continue_at_level(body):
                target = (kw_i, do_i, end_i)
                break
        if target is None:
            break
        kw_i, do_i, end_i = target
        label_n += 1
        lbl = f'cont{label_n}'
        body = out[do_i+1:end_i]
        # rewrite loop-level continues -> goto; loop-level break must stay break
        new_body = []
        stack = []
        for t, v in body:
            if t == 'name':
                if v == 'continue' and _innermost_binding(stack) == 'blk':
                    new_body.append(('name', 'goto'))
                    new_body.append(('name', lbl))
                    continue
                _block_stack_step(stack, v)
            new_body.append((t, v))
        label_toks = [('op', '::'), ('name', lbl), ('op', '::'), ('op', ';')]
        out = out[:do_i+1] + new_body + label_toks + out[end_i:]
    else:
        raise SyntaxError("continue transform did not converge")
    return out

def find_loops(toks):
    """All for/while loops as (kw_i, do_i, end_i), with full block tracking."""
    res = []
    stack = []  # [kind, kw_index, do_index]
    i = 0
    n = len(toks)
    while i < n:
        t, v = toks[i]
        if t == 'name':
            if v in ('for', 'while'):
                stack.append([v + '-pending', i, None])
            elif v == 'do':
                if stack and stack[-1][0] in ('for-pending', 'while-pending'):
                    stack[-1][0] = stack[-1][0][:-8]
                    stack[-1][2] = i
                else:
                    stack.append(['do', i, None])
            elif v == 'repeat':
                stack.append(['repeat', i, None])
            elif v == 'until':
                if stack and stack[-1][0] == 'repeat':
                    stack.pop()
            elif v == 'if':
                stack.append(['if', i, None])
            elif v == 'function':
                stack.append(['func', i, None])
            elif v == 'end':
                if stack:
                    kind, s, d = stack.pop()
                    if kind in ('for', 'while'):
                        res.append((s, d, i))
        i += 1
    return res

def _block_stack_step(stack, v):
    """Update the block-kind stack for one NAME token value v."""
    if v in ('for', 'while'):
        stack.append('pending')
    elif v == 'do':
        if stack and stack[-1] == 'pending':
            stack[-1] = 'loop'
        else:
            stack.append('loop')
    elif v == 'repeat':
        stack.append('loop')
    elif v == 'until':
        if stack and stack[-1] == 'loop':
            stack.pop()
    elif v == 'if':
        stack.append('blk')
    elif v == 'function':
        stack.append('func')
    elif v == 'end':
        if stack:
            stack.pop()

def _innermost_binding(stack):
    """Return 'loop'/'func' if the innermost binding block is a loop/function,
    'blk' if only transparent if/do blocks enclose."""
    for k in reversed(stack):
        if k in ('loop', 'func', 'pending'):
            return k
    return 'blk'

def has_continue_at_level(toks):
    """True if a `continue` appears whose innermost enclosing construct is the
    loop being considered (if/do blocks are transparent)."""
    stack = []
    for t, v in toks:
        if t == 'name':
            if v == 'continue':
                if _innermost_binding(stack) == 'blk':
                    return True
            else:
                _block_stack_step(stack, v)
    return False

def wrap_loop(toks, loop):
    kw_i, do_i, end_i = loop
    body = toks[do_i+1:end_i]
    body2 = []
    # track nested blocks to only rewrite loop-level continue/break
    stack = []
    for idx, (t, v) in enumerate(body):
        if t == 'name':
            if v == 'continue' and _innermost_binding(stack) == 'blk':
                body2.append(('name', 'break'))
                continue
            if v == 'break' and _innermost_binding(stack) == 'blk':
                body2.append(('name', '__brk'))
                body2.append(('op', '='))
                body2.append(('name', 'true'))
                body2.append(('op', ';'))
                body2.append(('name', 'break'))
                continue
            _block_stack_step(stack, v)
        body2.append((t, v))
    pre = [('name', 'local'), ('name', '__brk'), ('op', '='), ('name', 'false'), ('op', ';'),
           ('name', 'repeat')]
    post = [('name', 'until'), ('name', 'true'), ('op', ';'),
            ('name', 'if'), ('name', '__brk'), ('name', 'then'), ('name', 'break'),
            ('name', 'end'), ('op', ';')]
    return toks[:do_i+1] + pre + body2 + post + toks[end_i:]

# ---------------------------------------------------------------- main

def detokenize(toks):
    parts = []
    for i, (t, v) in enumerate(toks):
        if t in ('name', 'num') and i > 0:
            pt, pv = toks[i-1]
            if pt in ('name', 'num') or (pt == 'op' and pv in (')', ']', '}')):
                parts.append(' ')
        parts.append(v)
    return ''.join(parts)

def transform(src):
    toks = tokenize(src)
    toks, _ = transform_compound(toks)
    toks = transform_floordiv(toks)
    toks = transform_continue(toks)
    return detokenize(toks)

if __name__ == '__main__':
    src = open(sys.argv[1], encoding='utf-8').read()
    out = transform(src)
    with open(sys.argv[2], 'w', encoding='utf-8', newline='\n') as fh:
        fh.write(out)
    print("ok", len(src), "->", len(out))
