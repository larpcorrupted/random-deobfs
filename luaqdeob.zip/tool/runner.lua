-- runner.lua : executes a Luaq-obfuscated file in a sandbox, hooking loadstring/load
-- usage: luajit tool/runner.lua "sample/luaq.obf (1).lua"
local f = assert(io.open(arg[1], "rb"))
local src = f:read("*a")
f:close()

local logs = {}
local function log(t, msg) logs[#logs+1] = tostring(msg) end

local function makeEnv(name)
  local env = {}
  setmetatable(env, {
    __index = function(_, k)
      log("G", name .. "." .. tostring(k))
      return _G[k]
    end,
    __newindex = function(_, k, v)
      log("S", name .. "." .. tostring(k) .. " = " .. tostring(v))
      rawset(env, k, v)
    end,
  })
  return env
end

local function dumpChunk(kind, source, chunkname)
  log(kind, "=== " .. tostring(kind) .. " chunkname=" .. tostring(chunkname) .. " len=" .. #tostring(source))
  log(kind, tostring(source):sub(1, 5000))
  local out = io.open("work/dumped_" .. kind .. ".lua", "wb")
  out:write(tostring(source))
  out:close()
  return loadstring(source, chunkname)
end

local sandboxG = makeEnv("G")
-- hooks that many VM obfuscators use for the final payload
sandboxG.loadstring = function(s, n) return dumpChunk("loadstring", s, n) end
sandboxG.load = function(s, n) return dumpChunk("load", s, n) end
sandboxG.print = function(...)
  local parts = {}
  for i = 1, select("#", ...) do parts[#parts+1] = tostring(select(i, ...)) end
  log("PRINT", "print: " .. table.concat(parts, "\t"))
end
sandboxG.error = function(...)
  log("ERROR", "error: " .. tostring(...))
  return error(...)
end

local chunk, err = loadstring(src, "@" .. arg[1])
if not chunk then
  print("COMPILE ERROR: " .. tostring(err))
  return 1
end

setfenv(chunk, sandboxG)
local ok, e = pcall(chunk)
print("RESULT: ok=" .. tostring(ok) .. " err=" .. tostring(e))
local out = io.open("work/runlog.txt", "wb")
for _, l in ipairs(logs) do out:write(l, "\n") end
out:close()
print("log lines: " .. #logs)
